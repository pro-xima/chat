<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$nocache = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);

$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$mood = mysql_result($q, 0, 'mood');

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Настроение\"><p align=\"left\">\n";

if(!isset($_GET['go']))
{
echo "Выберите ваше настроение:<br/>\n";
echo "<select name=\"mood$nocache\" value=\"$mood\">\n";
echo <<< END
<option value="0">[выключено]</option>
<option value="1">Бодрое</option>
<option value="2">Прекрасное</option>
<option value="3">Весёлое</option>
<option value="4">Ангельское</option>
<option value="5">Агрессивное</option>
<option value="6">Изумлённое</option>
<option value="7">Удивленное</option>
<option value="8">Злое</option>
<option value="9">Сердитое</option>
<option value="10">Сонное</option>
<option value="11">Озлобленное</option>
<option value="12">Скучающее</option>
<option value="13">Оживлённое</option>
<option value="14">Угрюмое</option>
<option value="15">Размышляющее</option>
<option value="16">Занятое</option>
<option value="17">Нахальное</option>
<option value="18">Холодное</option>
<option value="19">Смущённое</option>
<option value="20">Крутое</option>
<option value="21">Дерзкое</option>
<option value="22">Непонятное</option>
<option value="23">Дьявольское</option>
<option value="24">Сварливое</option>
<option value="25">Счастливое</option>
<option value="26">Горячее</option>
<option value="27">Влюблённое</option>
<option value="28">Невинное</option>
<option value="29">Вдохновлённое</option>
<option value="30">Одинокое</option>
<option value="31">Скрытое</option>
<option value="32">Пушистое</option>
<option value="33">Задумчивое</option>
<option value="34">Психоделическое</option>
<option value="35">Расслабленое</option>
<option value="36">Грустное</option>
<option value="37">Испуганное</option>
<option value="38">Шокированное</option>
<option value="39">Потрясенное</option>
<option value="40">Больное</option>
<option value="41">Хитрое</option>
<option value="42">Усталое</option>
<option value="43">Утомленное</option>
<option value="44">Изменчивое</option>
</select><br/>
END;
echo "<anchor>[Сменить]<go href=\"mood.php?id=$id&amp;password=$password&amp;rid=".intval($_GET['rid'])."&amp;ver=wml&amp;go=change&amp;nocache=$nocache\" method=\"post\">\n";
echo "<postfield name=\"mood\" value=\"$(mood$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$sql = mysql_query("UPDATE `chat_users` SET `mood` = '".intval($_POST['mood'])."' WHERE `id` = '".$id."';");
	if($sql)
	{
	echo "Настроение сохранено!<br/>\n";
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=".intval($_GET['rid'])."&amp;nocache=$nocache\">В чат</a><br/>\n";
	}
	else
	{
	echo "Произошла ошибка.<br/>\n";
	echo mysql_error()."<br/>\n";
	}
}

echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

$mood = mysql_result($q, 0, 'mood');

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Настроение</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }\n";
echo "div.form { background-color: $form_color }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

if(!isset($_GET['go']))
{
echo "Выберите ваше настроение:<br/>\n";
echo "<div class=\"form\">\n";
echo "<form action=\"mood.php?id=$id&amp;password=$password&amp;ver=html&amp;go=change\" method=\"post\">\n";
echo "<select name=\"mood\">\n";
for($i = 0;$i <= 44; $i++)
{
$mood_array = array("[выключено]", "Бодрое", "Прекрасное", "Весёлое", "Ангельское", "Агрессивное", "Изумлённое", "Удивленное", "Злое", "Сердитое", "Сонное", "Озлобленное", "Скучающее", "Оживлённое", "Угрюмое", "Размышляющее", "Занятое", "Нахальное", "Холодное", "Смущённое", "Крутое", "Дерзкое", "Непонятное", "Дьявольское", "Сварливое", "Счастливое", "Горячее", "Влюблённое", "Невинное", "Вдохновлённое", "Одинокое", "Скрытое", "Пушистое", "Задумчивое", "Психоделическое", "Расслабленое", "Грустное", "Испуганное", "Шокированное", "Потрясенное", "Больное", "Хитрое", "Усталое", "Утомленное", "Изменчивое");

echo "<option value=\"$i\"";
if($mood == $i) echo " selected=\"selected\" ";
echo ">".$mood_array[$i]."</option>\n";
}
echo "</select><br/>";
echo "<input type=\"submit\" value=\"Сменить\" /></form></div>\n";
}
else
{
$sql = mysql_query("UPDATE `chat_users` SET `mood` = '".intval($_POST['mood'])."' WHERE `id` = '".$id."';");
	if($sql)
	{
	echo "Настроение сохранено!<br/>\n";
	}
	else
	{
	echo "Произошла ошибка.<br/>\n";
	echo mysql_error()."<br/>\n";
	}
}

echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>