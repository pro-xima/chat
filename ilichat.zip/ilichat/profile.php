<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$ref = rand(1000, 9999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

$user = mysql_fetch_array($q);
$nickname = $user['nickname'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$from = $user['from'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$birthday = explode("-", $birthday);
$about = $user['about'];
$posts = $user['posts'];
$level = $user['level'];
$status = $user['status'];

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Профиль\"><p align=\"left\">\n";
if(!isset($_POST['action']))
{
if($level > 2)
{
echo "Ник:<br/>
<input type=\"text\" name=\"nickname$ref\" value=\"$nickname\" maxlength=\"15\"/><br/>\n";
}
echo "Пароль:<br/>
<input type=\"text\" name=\"pass$ref\" value=\"$password\" maxlength=\"20\"/><br/>\n";
if($level > 2)
{
echo "Статус:<br/>
<input type=\"text\" name=\"status$ref\" value=\"$status\" maxlength=\"15\"/><br/>\n";
}
echo "Имя:<br/>
<input type=\"text\" name=\"name$ref\" value=\"$name\" maxlength=\"20\"/><br/>
Пол:<br/>
<select name=\"sex$ref\" value=\"$sex\">
<option value=\"0\">Мужской</option>
<option value=\"1\">Женский</option>
<option value=\"2\">Неизвестно :)</option>
</select><br/>
Дата рождения:<br/>
<input size=\"2\" name=\"day$ref\" value=\"".$birthday[0]."\" maxlength=\"2\" format=\"*N\" emptyok=\"true\"/>
-
<input size=\"2\" name=\"month$ref\" value=\"".$birthday[1]."\" maxlength=\"2\" format=\"*N\" emptyok=\"true\"/>
-
<input size=\"4\" name=\"year$ref\" value=\"".$birthday[2]."\" maxlength=\"4\" format=\"*N\" emptyok=\"true\"/><br/>
Город:<br/>
<input type=\"text\" name=\"from$ref\" value=\"$from\" maxlength=\"20\"/><br/>
Модель мобильного телефона:<br/>
<input type=\"text\" name=\"mobile$ref\" value=\"$mobile\" maxlength=\"20\"/><br/>
eMail:<br/>
<input type=\"text\" name=\"email$ref\" value=\"$email\" maxlength=\"20\"/><br/>
Сайт:<br/>
<input type=\"text\" name=\"site$ref\" value=\"http://$site\"  maxlength=\"50\"/><br/>
О себе:<br/>
<input type=\"text\" name=\"about$ref\" value=\"$about\" maxlength=\"300\"/><br/>
<anchor>[Сохранить]<go href=\"profile.php?id=$id&amp;password=$password&amp;ref=$ref&amp;ver=wml\" method=\"post\">\n";
if($level > 2)
{
echo "<postfield name=\"nickname\" value=\"$(nickname$ref)\"/>\n";
echo "<postfield name=\"status\" value=\"$(status$ref)\"/>\n";
}
echo "<postfield name=\"pass\" value=\"$(pass$ref)\"/>
<postfield name=\"name\" value=\"$(name$ref)\"/>
<postfield name=\"sex\" value=\"$(sex$ref)\"/>
<postfield name=\"day\" value=\"$(day$ref)\"/>
<postfield name=\"month\" value=\"$(month$ref)\"/>
<postfield name=\"year\" value=\"$(year$ref)\"/>
<postfield name=\"from\" value=\"$(from$ref)\"/>
<postfield name=\"mobile\" value=\"$(mobile$ref)\"/>
<postfield name=\"email\" value=\"$(email$ref)\"/>
<postfield name=\"site\" value=\"$(site$ref)\"/>
<postfield name=\"about\" value=\"$(about$ref)\"/>
<postfield name=\"action\" value=\"$(save)\"/>
</go></anchor><br/>\n";
echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml\">Фотография</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
}
else
{
	if($level > 2)
	{
	$nickname = mysql_escape_string(htmlspecialchars(trim($_POST['nickname'])));
	$status = mysql_escape_string(htmlspecialchars(trim($_POST['status'])));
	}
	else
	{
	$query = mysql_query("SELECT `nickname`, `status` FROM `chat_users` WHERE `id` = '".$id."';");
	$nickname = mysql_result($query, 0, 'nickname');
	$status = mysql_result($query, 0, 'status');
	}
$pass = $_POST['pass'];
$name = mysql_escape_string(htmlspecialchars(trim($_POST['name'])));
	if($_POST['sex'] == 0 or $_POST['sex'] == 1 or $_POST['sex'] == 2)
	{
	$sex = intval($_POST['sex']);
	}
	else
	{
	$sex = 2;
	}
$day = intval($_POST['day']);
$day = substr($day, 0, 2);
$month = intval($_POST['month']);
$month = substr($month, 0, 2);
$year = intval($_POST['year']);
$year = substr($year, 0, 4);
$birthday = "$day-$month-$year";
$from = mysql_escape_string(htmlspecialchars(trim($_POST['from'])));
$mobile = mysql_escape_string(htmlspecialchars(trim($_POST['mobile'])));
$email = mysql_escape_string(htmlspecialchars(trim($_POST['email'])));
$site = strtolower(mysql_escape_string(htmlspecialchars(trim($_POST['site']))));
$site = str_replace('http://', '', $site);
$about = mysql_escape_string(htmlspecialchars(trim($_POST['about'])));

$error = "";

if(empty($nickname) && $level > 2) $error .= "Не введен ник!<br/>\n";
if(empty($pass)) $error .= "Не введен пароль!<br/>\n";
if(preg_match("/[^0-9a-zA-Z_]+/",$pass)) $error .= "В пароле есть запрещенные символы!<br/>\n";
if(empty($status) && $level > 2) $error .= "Не введен статус!<br/>\n";
if(strlen($mobile) > 40) $error .= "Слишком много информации в \"Модель мобильного телефона\"!<br/>\n";
if(strlen($email) > 40) $error .= "Слишком длинный e-mail!<br/>\n";
if(strlen($site) > 100) $error .= "Слишком длинный адрес сайта!<br/>\n";
if(strlen($about) > 600) $error .= "Слишком много информации в \"О себе\"!<br/>\n";

if(!empty($error))
{
echo $error;
echo "<a href=\"profile.php?id=$id&amp;password=$password&amp;ver=wml&amp;ref=$ref\">Назад</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</p></card></wml>";
exit();
}

$q = mysql_query("UPDATE `chat_users` SET `nickname` = '".$nickname."', `password` = '".$pass."', `name` = '".$name."', `sex` = '".$sex."', `status` = '".$status."', `birthday` = '".$birthday."', `from` = '".$from."', `mobile` = '".$mobile."', `email` = '".$email."', `site` = '".$site."', `about` = '".$about."' WHERE `id` = '".$id."';");

echo "Профиль успешно сохранен!<br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$pass&amp;ver=wml\">Меню чата</a><br/>\n";
}

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime, 5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

$user = mysql_fetch_array($q);
$nickname = $user['nickname'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$from = $user['from'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$birthday = explode("-", $birthday);
$about = $user['about'];
$posts = $user['posts'];
$level = $user['level'];
$status = $user['status'];

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Профиль</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body>";

if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"profile.php?id=$id&amp;password=$password&amp;ref=$ref&amp;ver=html\">\n";
if($level > 2)
{
echo "Ник:<br/>
<input type=\"text\" name=\"nickname\" value=\"$nickname\" maxlength=\"15\"/><br/>\n";
}
echo "Пароль:<br/>
<input type=\"text\" name=\"pass\" value=\"$password\" maxlength=\"20\"/><br/>\n";
if($level > 2)
{
echo "Статус:<br/>
<input type=\"text\" name=\"status\" value=\"$status\" maxlength=\"15\"/><br/>\n";
}
echo "Имя:<br/>
<input type=\"text\" name=\"name\" value=\"$name\" maxlength=\"20\"/><br/>
Пол:<br/>
<select name=\"sex\">\n";
if($sex == 0)
{
echo "<option value=\"0\" selected=\"selected\">Мужской</option>\n";
echo "<option value=\"1\">Женский</option>\n";
echo "<option value=\"2\">Неизвестно :)</option>\n";
echo "</select><br/>\n";
}
elseif($sex == 1)
{
echo "<option value=\"1\" selected=\"selected\">Женский</option>\n";
echo "<option value=\"0\">Мужской</option>\n";
echo "<option value=\"2\">Неизвестно :)</option>\n";
echo "</select><br/>\n";
}
else
{
echo "<option value=\"2\" selected=\"selected\">Неизвестно :)</option>\n";
echo "<option value=\"1\">Женский</option>\n";
echo "<option value=\"0\">Мужской</option>\n";
echo "</select><br/>\n";
}
echo "Дата рождения:<br/>
<input size=\"2\" name=\"day\" value=\"".$birthday[0]."\" maxlength=\"2\"/>
-
<input size=\"2\" name=\"month\" value=\"".$birthday[1]."\" maxlength=\"2\"/>
-
<input size=\"4\" name=\"year\" value=\"".$birthday[2]."\" maxlength=\"4\"/><br/>
Город:<br/>
<input type=\"text\" name=\"from\" value=\"$from\" maxlength=\"20\"/><br/>
Модель мобильного телефона:<br/>
<input type=\"text\" name=\"mobile\" value=\"$mobile\" maxlength=\"20\"/><br/>
eMail:<br/>
<input type=\"text\" name=\"email\" value=\"$email\" maxlength=\"20\"/><br/>
Сайт:<br/>
<input type=\"text\" name=\"site\" value=\"http://$site\"  maxlength=\"50\"/><br/>
О себе:<br/>
<input type=\"text\" name=\"about\" value=\"$about\" maxlength=\"300\"/><br/>";
echo "<input type=\"hidden\" name=\"action\" value=\"save\"/>\n";
echo "<input type=\"submit\" value=\"Сохранить\"/></form></div><br/>\n";
echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html\">Фотография</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
}
else
{
	if($level > 2)
	{
	$nickname = mysql_escape_string(htmlspecialchars(trim($_POST['nickname'])));
	$status = mysql_escape_string(htmlspecialchars(trim($_POST['status'])));
	}
	else
	{
	$query = mysql_query("SELECT `nickname`, `status` FROM `chat_users` WHERE `id` = '".$id."';");
	$nickname = mysql_result($query, 0, 'nickname');
	$status = mysql_result($query, 0, 'status');
	}
$pass = $_POST['pass'];
$name = mysql_escape_string(htmlspecialchars(trim($_POST['name'])));
	if($_POST['sex'] == 0 or $_POST['sex'] == 1 or $_POST['sex'] == 2)
	{
	$sex = intval($_POST['sex']);
	}
	else
	{
	$sex = 2;
	}
$day = intval($_POST['day']);
$day = substr($day, 0, 2);
$month = intval($_POST['month']);
$month = substr($month, 0, 2);
$year = intval($_POST['year']);
$year = substr($year, 0, 4);
$birthday = "$day-$month-$year";
$from = mysql_escape_string(htmlspecialchars(trim($_POST['from'])));
$mobile = mysql_escape_string(htmlspecialchars(trim($_POST['mobile'])));
$email = mysql_escape_string(htmlspecialchars(trim($_POST['email'])));
$site = strtolower(mysql_escape_string(htmlspecialchars(trim($_POST['site']))));
$site = str_replace('http://', '', $site);
$about = mysql_escape_string(htmlspecialchars(trim($_POST['about'])));

$error = "";

if(empty($nickname) && $level > 2) $error .= "Не введен ник!<br/>\n";
if(empty($pass)) $error .= "Не введен пароль!<br/>\n";
if(preg_match("/[^0-9a-zA-Z_]+/",$pass)) $error .= "В пароле есть запрещенные символы!<br/>\n";
if(empty($status) && $level > 2) $error .= "Не введен статус!<br/>\n";
if(strlen($mobile) > 40) $error .= "Слишком много информации в \"Модель мобильного телефона\"!<br/>\n";
if(strlen($email) > 40) $error .= "Слишком длинный e-mail!<br/>\n";
if(strlen($site) > 100) $error .= "Слишком длинный адрес сайта!<br/>\n";
if(strlen($about) > 600) $error .= "Слишком много информации в \"О себе\"!<br/>\n";

if(!empty($error))
{
echo $error;
echo "<a href=\"profile.php?id=$id&amp;password=$password&amp;ver=html&amp;ref=$ref\">Назад</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

$q = mysql_query("UPDATE `chat_users` SET `nickname` = '".$nickname."', `password` = '".$pass."', `name` = '".$name."', `sex` = '".$sex."', `status` = '".$status."', `birthday` = '".$birthday."', `from` = '".$from."', `mobile` = '".$mobile."', `email` = '".$email."', `site` = '".$site."', `about` = '".$about."' WHERE `id` = '".$id."';");

echo "Профиль успешно сохранен!<br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$pass&amp;ver=html\">Меню чата</a><br/>\n";
}
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
break;
}
?>