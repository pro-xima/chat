<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

if(isset($_GET['rid']))
{
$sql = mysql_query("SELECT `type` FROM `chat_rooms` WHERER `id` = '".intval($_GET['rid'])."';");
$type = mysql_result($sql, 0);
	if($type == 0)
	{
	$url = "room.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=wml&amp;rid=".intval($_GET['rid']);
	}
	else
	{
	$url = "mroom.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=wml&amp;rid=".intval($_GET['rid']);
	}
}
else
{
$key = $_GET['key'];
$url = "intim.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=wml&amp;key=$key";
}

$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".intval($_GET['uid'])."';");

if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card id=\"error\" title=\"Error\" ontimer=\"$url\"><timer value=\"10\"/><p align=\"left\">\n";
echo "Пользователь не найден в базе данных.<br/>\n";
}
else
{
$user = mysql_fetch_array($q);
$uid = $user['id'];
$nick = $user['nickname'];
$pass = $user['password'];
$ip = $user['ip'];
$ua = $user['ua'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$from = $user['from'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$about = $user['about'];
$posts = $user['posts'];
$lev = $user['level'];
$answers = $user['answers'];
$gbalans = $user['gbalans'];
$status = $user['status'];
$regdate = $user['regdate'];
$place = $user['place'];
$photo_type = $user['photo'];
$time = $user['time'];
$mood = $user['mood'];

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"$nick\"><p align=\"left\">\n";

if(file_exists("photos/".$uid.".$photo_type"))
{
echo "Ник: <a href=\"photos/".$uid.".$photo_type?".rand(10000, 99999)."\">".$nick."</a><br/>\n";
}
else
{
echo "Ник: ".$nick."<br/>\n";
}

echo "Имя: $name<br/>\n";
if($sex == 0)
{
echo "Пол: мужской<br/>\n";
}
elseif($sex == 1)
{
echo "Пол: женский<br/>\n";
}
else
{
echo "Неизвестно :)<br/>\n";
}

$mood_array = array("", "Бодрое", "Прекрасное", "Весёлое", "Ангельское", "Агрессивное", "Изумлённое", "Удивленное", "Злое", "Сердитое", "Сонное", "Озлобленное", "Скучающее", "Оживлённое", "Угрюмое", "Размышляющее", "Занятое", "Нахальное", "Холодное", "Смущённое", "Крутое", "Дерзкое", "Непонятное", "Дьявольское", "Сварливое", "Счастливое", "Горячее", "Влюблённое", "Невинное", "Вдохновлённое", "Одинокое", "Скрытое", "Пушистое", "Задумчивое", "Психоделическое", "Расслабленое", "Грустное", "Испуганное", "Шокированное", "Потрясенное", "Больное", "Хитрое", "Усталое", "Утомленное", "Изменчивое");

if($mood != 0) echo "Настроение: ".$mood_array[$mood]."<br/>\n";

echo "Дата рождения: $birthday<br/>\n";
echo "Статус: $status<br/>\n";
echo "Количество постов: $posts<br/>\n";
echo "Ответов в викторине: $answers<br/>\n";
echo "Игровой баланс: $gbalans<br/>\n";
echo "Откуда: $from<br/>\n";
echo "Модель мобильного телефона: $mobile<br/>\n";
echo "Сайт: <a href=\"http://$site\">$site</a><br/>\n";
echo "Email: $email<br/>\n";
echo "О себе: $about<br/>\n";
echo "Дата регистрации: $regdate<br/>\n";
$ltime = time() - ($time - 60);
if($ltime < 60 && $ltime >= 0)
{
$var = "sec.";
}
elseif($ltime < 3600 && $ltime > 60)
{
$new = $ltime;
$ltime = $new/60;
$var = "min.";
}
elseif($ltime < 86400 && $ltime > 3600)
{
$new = $ltime;
$ltime = $new/3600;
$var = "hours";
}
elseif($ltime > 86400)
{
$new = $ltime;
$ltime = $new/86400;
$var = "days";
}
$ltime = round($ltime, 2);
	if($ltime > 0)
	{
	echo "Время с последнего захода в чат: $ltime $var<br/>\n";
	}
	else
	{
	echo "Онлайн.<br/>\n";
	}

if($level == 4 && $uid != 1) echo "[Пароль]: ".$pass."<br/>\n";
if($level == 4 && $uid == 1) echo "[Пароль]: скрыто<br/>\n";
	if($level == 3 && $lev != 4)
	{
	echo "[IP]: ".$ip."<br/>\n";
	echo "[UserAgent]: ".$ua."<br/>\n";
	}
	elseif($level == 3)
	{
	echo "[IP]: скрыто<br/>\n";
	echo "[UserAgent]: скрыто<br/>\n";
	}
	if($level == 4)
	{
	echo "[IP]: ".$ip."<br/>\n";
	echo "[UserAgent]: ".$ua."<br/>\n";
	}
	if($level == 4)
	{
		if(time() < $kick)
		{
		echo "Данный пользователь заблокирован.<br/>\n";
		$tkick = $kick - time();
		if($tkick < 60 && $tkick > 0)
		{
		$var = "sec.";
		}
		elseif($tkick < 3600 && $tkick > 60)
		{
		$new = $tkick;
		$tkick = $new/60;
		$var = "min.";
		}
		elseif($tkick < 86400 && $tkick > 3600)
		{
		$new = $tkick;
		$tkick = $new/3600;
		$var = "hours";
		}
		elseif($tkick > 86400)
		{
		$new = $tkick;
		$tkick = $new/86400;
		$var = "days";
		}
		$tkick = round($tkick, 2);
		echo "Выпнут(а) модератором <u>".$moder."</u>.<br/>\n";
		echo "Разбан через <u>".$tkick." $var</u><br/>\n";
		echo "Причина: <u>".$reason."</u><br/>\n";
		}
	}

}

echo "<a href=\"$url\">В чат</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10-flat.dtd\">\n";
echo "<html><head>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }";
echo "</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

if(isset($_GET['rid']))
{
$sql = mysql_query("SELECT `type` FROM `chat_rooms` WHERER `id` = '".intval($_GET['rid'])."';");
$type = mysql_result($sql, 0);
	if($type == 0)
	{
	$url = "room.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=html&amp;rid=".intval($_GET['rid']);
	}
	else
	{
	$url = "mroom.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=html&amp;rid=".intval($_GET['rid']);
	}
}
else
{
$key = $_GET['key'];
$url = "intim.php?id=$id&amp;password=$password&amp;nocache=".rand(10000, 99999)."&amp;ver=html&amp;key=$key";
}

$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".intval($_GET['uid'])."';");

if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Error</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Пользователь не найден в базе данных.<br/>\n";
}
else
{
$user = mysql_fetch_array($q);
$uid = $user['id'];
$nick = $user['nickname'];
$pass = $user['password'];
$ip = $user['ip'];
$ua = $user['ua'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$from = $user['from'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$about = $user['about'];
$posts = $user['posts'];
$lev = $user['level'];
$answers = $user['answers'];
$gbalans = $user['gbalans'];
$status = $user['status'];
$regdate = $user['regdate'];
$place = $user['place'];
$photo_type = $user['photo'];
$time = $user['time'];
$mood = $user['mood'];

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$nick."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body>";

if(file_exists("photos/".$uid.".$photo_type"))
{
echo "Ник: <a href=\"photos/".$uid.".$photo_type?".rand(10000, 99999)."\">".$nick."</a><br/>\n";
}
else
{
echo "Ник: ".$nick."<br/>\n";
}

echo "Имя: $name<br/>\n";
if($sex == 0)
{
echo "Пол: мужской<br/>\n";
}
elseif($sex == 1)
{
echo "Пол: женский<br/>\n";
}
else
{
echo "Неизвестно :)<br/>\n";
}

$mood_array = array("", "Бодрое", "Прекрасное", "Весёлое", "Ангельское", "Агрессивное", "Изумлённое", "Удивленное", "Злое", "Сердитое", "Сонное", "Озлобленное", "Скучающее", "Оживлённое", "Угрюмое", "Размышляющее", "Занятое", "Нахальное", "Холодное", "Смущённое", "Крутое", "Дерзкое", "Непонятное", "Дьявольское", "Сварливое", "Счастливое", "Горячее", "Влюблённое", "Невинное", "Вдохновлённое", "Одинокое", "Скрытое", "Пушистое", "Задумчивое", "Психоделическое", "Расслабленое", "Грустное", "Испуганное", "Шокированное", "Потрясенное", "Больное", "Хитрое", "Усталое", "Утомленное", "Изменчивое");

if($mood != 0) echo "Настроение: ".$mood_array[$mood]."<br/>\n";

echo "Дата рождения: $birthday<br/>\n";
echo "Статус: $status<br/>\n";
echo "Количество постов: $posts<br/>\n";
echo "Ответов в викторине: $answers<br/>\n";
echo "Игровой баланс: $gbalans<br/>\n";
echo "Откуда: $from<br/>\n";
echo "Модель мобильного телефона: $mobile<br/>\n";
echo "Сайт: <a href=\"http://$site\">$site</a><br/>\n";
echo "Email: $email<br/>\n";
echo "О себе: $about<br/>\n";
echo "Дата регистрации: $regdate<br/>\n";
$ltime = time() - ($time - 60);
if($ltime < 60 && $ltime >= 0)
{
$var = "sec.";
}
elseif($ltime < 3600 && $ltime > 60)
{
$new = $ltime;
$ltime = $new/60;
$var = "min.";
}
elseif($ltime < 86400 && $ltime > 3600)
{
$new = $ltime;
$ltime = $new/3600;
$var = "hours";
}
elseif($ltime > 86400)
{
$new = $ltime;
$ltime = $new/86400;
$var = "days";
}
$ltime = round($ltime, 2);
	if($ltime > 0)
	{
	echo "Время с последнего захода в чат: $ltime $var<br/>\n";
	}
	else
	{
	echo "Онлайн.<br/>\n";
	}

if($level == 4 && $uid != 1) echo "[Пароль]: ".$pass."<br/>\n";
if($level == 4 && $uid == 1) echo "[Пароль]: скрыто<br/>\n";
	if($level == 3 && $lev != 4)
	{
	echo "[IP]: ".$ip."<br/>\n";
	echo "[UserAgent]: ".$ua."<br/>\n";
	}
	elseif($level == 3)
	{
	echo "[IP]: скрыто<br/>\n";
	echo "[UserAgent]: скрыто<br/>\n";
	}
	if($level == 4)
	{
	echo "[IP]: ".$ip."<br/>\n";
	echo "[UserAgent]: ".$ua."<br/>\n";
	}
	if($level == 4)
	{
		if(time() < $kick)
		{
		echo "Данный пользователь заблокирован.<br/>\n";
		$tkick = $kick - time();
		if($tkick < 60 && $tkick > 0)
		{
		$var = "sec.";
		}
		elseif($tkick < 3600 && $tkick > 60)
		{
		$new = $tkick;
		$tkick = $new/60;
		$var = "min.";
		}
		elseif($tkick < 86400 && $tkick > 3600)
		{
		$new = $tkick;
		$tkick = $new/3600;
		$var = "hours";
		}
		elseif($tkick > 86400)
		{
		$new = $tkick;
		$tkick = $new/86400;
		$var = "days";
		}
		$tkick = round($tkick, 2);
		echo "Выпнут(а) модератором <u>".$moder."</u>.<br/>\n";
		echo "Разбан через <u>".$tkick." $var</u><br/>\n";
		echo "Причина: <u>".$reason."</u><br/>\n";
		}
	}

}

echo "<a href=\"$url\">В чат</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</body></html>";
break;
}
?>