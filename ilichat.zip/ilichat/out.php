<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$url = htmlspecialchars($_GET['url']);

switch($ver)
{
case 'wml':
///////////////////////////////////////////////////////
//WML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo <<< REDIRECT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.3//EN" "http://www.wapforum.org/DTD/wml13.dtd">
<wml>
<head><meta http-equiv="Cache-Control" content="no-cache" forua="true"/></head>
<card id="redirect" title="Redirect" ontimer="$url">
<timer value="10" />
<p align="left">
Переадресация: <a href="$url">$url</a><br />
</p>
</card>
</wml>
REDIRECT;
break;

case 'html':
///////////////////////////////////////////////////////
//HTML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo <<< REDIRECT
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="1;url=$url" />
<link rel="shortcut icon" href="$favicon" />
<title>$title</title>
<style type="text/css">
body { font-weight: normal; font-size: normal; font-family: $font; color: $color; background-color: $background }
a:link, a:active, a:visited { text-decoration: underline; color : $links }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: $form_color }
</style>
</head>
<body>
Переадресация: <a href="$url">$url</a><br />
</body>
</html>
REDIRECT;
break;
}
?>