<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$nocache = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Загрузка фото\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'add':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(file_exists("photos/".$id.".$photo_type"))
{
echo "Удалите сначала текущую фотографию.<br/>\n";
break;
}

if(!isset($_POST['action']) && !isset($_GET['uid']))
{
echo "Адрес:<br/>\n";
echo "<input type=\"text\" name=\"url$nocache\" value=\"http://\" maxlength=\"200\"/><br/>\n";
echo "<anchor>[Добавить]<go href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache&amp;mod=add\" method=\"post\">\n";
echo "<postfield name=\"url\" value=\"$(url$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"load\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$photo_info = getimagesize($url);
	if(!$photo_info)
	{
	echo "Ошибка при загрузке фото. Возможно, вы неправильно написали URL фотографии.<br/>\n";
	break;
	}

	switch($photo_info[2])
	{
	default:
	echo "К закачке разрешены только JPEG, GIF, PNG.<br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml\">Фото</a><br/>\n";
	echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
	echo "</p></card></wml>";
	exit();
	break;
	
	//GIF
	
	case 1:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'gif' WHERE `id` = '".$id."';");
	$pd = imagecreatefromgif($url);
	imagegif($pd, "photos/".$id.".gif");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".gif?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;

	//JPEG
	
	case 2:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'jpg' WHERE `id` = '".$id."';");
	$pd = imagecreatefromjpeg($url);
	imagejpeg($pd, "photos/".$id.".jpg");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".jpg?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;

	//PNG
	
	case 3:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'png' WHERE `id` = '".$id."';");
	$pd = imagecreatefrompng($url);
	imagepng($pd, "photos/".$id.".png");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".png?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;
	}

}
break;

case 'del':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(!file_exists("photos/".$id.".$photo_type"))
{
echo "Фотографии не существует.<br/>\n";
break;
}

if(!isset($_GET['accept']))
{
echo "Вы уверены, что хотите удалить текущую фотографию?<br/>\n";
echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=del&amp;accept\">[Да]</a> <a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">[Нет]</a><br/>\n";
}
else
{
	if(unlink("photos/".$id.".$photo_type"))
	{
	echo "Фотография успешно удалена!<br/>\n";
	}
	else
	{
	echo "При удалении произошла ошибка...<br/>\n";
	}

}
break;

default:
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

echo "Загрузка фотографии через URL (адресу):<br/>\n";

	if(file_exists("photos/".$id.".$photo_type"))
	{
	echo "Для загрузки новой фотографии удалите текущую.<br/>\n";
	echo "Текущая фотография:<br/>\n";
	echo "<img src=\"photos/".$id.".$photo_type?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=del\">[Удалить]</a><br/>\n";
	}
	else
	{
	echo "Фотографии нет.<br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=add\">[Добавить]</a><br/>\n";
	}
}

if(!empty($mod)) echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=wml\">Фото</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Фото</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'add':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(file_exists("photos/".$id.".$photo_type"))
{
echo "Удалите сначала текущую фотографию.<br/>\n";
break;
}

if(!isset($_POST['action']) && !isset($_GET['uid']))
{
echo "<div class=\"form\">\n";
echo "<form action=\"photo.php?id=$id&amp;password=$password&amp;ver=html&amp;nocache=$nocache&amp;mod=add\" method=\"post\">\n";
echo "Адрес:<br/>\n";
echo "<input type=\"text\" name=\"url\" value=\"http://\" maxlength=\"200\" /><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"auth\" />\n";
echo "<input type=\"submit\" value=\"Закачать\" /></form></div>\n";
}
else
{
$photo_info = getimagesize($url);
	if(!$photo_info)
	{
	echo "Ошибка при загрузке фото. Возможно, вы неправильно написали URL фотографии.<br/>\n";
	break;
	}

	switch($photo_info[2])
	{
	default:
	echo "К закачке разрешены только JPEG, GIF, PNG.<br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html\">Фото</a><br/>\n";
	echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
	echo "</div></body></html>";
	exit();
	break;
	
	//GIF
	
	case 1:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'gif' WHERE `id` = '".$id."';");
	$pd = imagecreatefromgif($url);
	imagegif($pd, "photos/".$id.".gif");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".gif?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;

	//JPEG
	
	case 2:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'jpg' WHERE `id` = '".$id."';");
	$pd = imagecreatefromjpeg($url);
	imagejpeg($pd, "photos/".$id.".jpg");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".jpg?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;

	//PNG
	
	case 3:
	$sql = mysql_query("UPDATE `chat_users` SET `photo` = 'png' WHERE `id` = '".$id."';");
	$pd = imagecreatefrompng($url);
	imagepng($pd, "photos/".$id.".png");
	imagedestroy($pd);
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src=\"photos/".$id.".png?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	break;
	}

}
break;

case 'del':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(!file_exists("photos/".$id.".$photo_type"))
{
echo "Фотографии не существует.<br/>\n";
break;
}

if(!isset($_GET['accept']))
{
echo "Вы уверены, что хотите удалить текущую фотографию?<br/>\n";
echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=del&amp;accept\">[Да]</a> <a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">[Нет]</a><br/>\n";
}
else
{
	if(unlink("photos/".$id.".$photo_type"))
	{
	echo "Фотография успешно удалена!<br/>\n";
	}
	else
	{
	echo "При удалении произошла ошибка...<br/>\n";
	}

}
break;

default:
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

echo "Загрузка фотографии через URL (адресу):<br/>\n";

	if(file_exists("photos/".$id.".$photo_type"))
	{
	echo "Для загрузки новой фотографии удалите текущую.<br/>\n";
	echo "Текущая фотография:<br/>\n";
	echo "<img src=\"photos/".$id.".$photo_type?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=del\">[Удалить]</a><br/>\n";
	}
	else
	{
	echo "Фотографии нет.<br/>\n";
	echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=add\">[Добавить]</a><br/>\n";
	}

echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html\">[Загрузка через HTML-форму]</a><br/>\n";
}

if(!empty($mod)) echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html\">Фотография</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>