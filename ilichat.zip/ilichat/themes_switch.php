<?php
switch($_COOKIE['theme'])
{
case 'blue':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#003366";
$form_color = "#00468C";
break;

case 'violet':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#990099";
$form_color = "#660066";
break;

case 'gray':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#666666";
$form_color = "#333333";
break;

case 'black-and-white':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#000000";
$form_color = "#333333";
break;

case 'gold':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#999900";
$form_color = "#666600";
break;

case 'green':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#339900";
$form_color = "#336600";
break;

case 'red':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#FFFFFF";
$background = "#CC0000";
$form_color = "#990000";
break;

case 'matrix':
$font = "sans-serif";
$color = "#FFFFFF";
$links = "#00FF00";
$background = "#000000";
$form_color = "#006600";
break;

default:
$font = "sans-serif";
$color = "#000000";
$links = "blue";
$background = "#FFF68F";
$form_color = "#FFC125";
break;
}
?>