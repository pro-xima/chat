<?php
//ERROR REPORTING LEVEL
error_reporting(0);

//CONNECTION (MySQL)
include('config.php');
//IS USER BANNED?
include('./includes/'.$ver.'/banned');

//GET BOTS NAMES
$bots = file("bots/bots.dat");
$bots[0] = trim($bots[0]);
$bots[1] = trim($bots[1]);
$bots[2] = trim($bots[2]);
$bots[3] = trim($bots[3]); //SYSTEM

//CONFIGS
$configs = file('configs.dat');
$adv = $configs[1];
$computer = $configs[2];

//INTERVALS
$intervals = file('bots/intervals.dat');
$intervals[0] = intval($intervals[0]);
$intervals[1] = intval($intervals[1]);
$intervals[2] = intval($intervals[2]);

//VARIABLE FOR NO-CACHE PROTECTION
$nocache = rand(0, 999999999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header('Content-type:text/vnd.wap.wml; charset=utf-8');
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: no-cache, must-revalidate');

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
else
{
$user = mysql_fetch_array($q);
$nickname = $user['nickname'];
$smiles = $user['smiles'];
$translit  = $user['translit'];
$msgs  = $user['msgs'];
$refresh = $user['refresh'];
$fsize = $user['fsize'];
$security  = $user['security'];
$level = $user['level'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$refresh = $refresh * 10;
$emotions = $user['emotions'];
}
//END AUTH

if(((strpos($ua, "Opera") !== false) or (strpos($ua, "Mozilla") !== false) or (strpos($ua, "MSIE") !== false)  or (strpos($ua, "Netscape") !== false)) && $computer == 1 && $level == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"10\"/><p align=\"left\">\n";
echo "<small>Доступ с компьютера запрещен.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}

$rid = intval($_GET['rid']);

$sql = mysql_query("SELECT `topic`, `type` FROM `chat_rooms` WHERE `id` = '".$rid."';");

if(mysql_num_rows($sql) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"10\"/><p align=\"left\">\n";
echo "<small>Такой комнаты не существует.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
else
{
$topic = mysql_result($sql, 0, 'topic');
$type = mysql_result($sql, 0, 'type');
}

if($level == 0 && $type == 1)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"10\"/><p align=\"left\">\n";
echo "<small>Доступ запрещен.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}

if($kick > time() && (($rid != $wicked_quiz && $rid != $unlim) or $moder == $bots[3]))
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Ошибка\" ontimer=\"rules.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"50\"/><p align=\"left\">\n";
echo "<small>Вы временно заблокированы модератором <u>$moder</u> на <u>".($kick - time())."</u> сек.<br/>\n";
echo "Причина: $reason<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}

//ONLINE
$online = time() + 90;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = '".$rid."', `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

$sql = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `to` = '".$id."' AND `read` = 0 AND `id` = '".$id."';");
$inbox = mysql_result($sql, 0);

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"chat\" title=\"$topic\" ontimer=\"".$_SERVER['PHP_SELF']."?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache\">\n";
echo "<timer value=\"$refresh\"/>\n";
echo "<do type=\"options\" name=\"add\" label=\"Сказать\"><go href=\"#add\" method=\"get\"/></do>\n";
echo "<do type=\"options\" name=\"refresh\" label=\"Обновить\"><go href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache\" method=\"get\"/></do>\n";
echo "<do type=\"options\" name=\"online\" label=\"Кто где?\"><go href=\"online.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\" method=\"get\"/></do>\n";
echo "<do type=\"options\" name=\"mood\" label=\"Настроение\"><go href=\"mood.php?id=$id&amp;rid=$rid&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\" method=\"get\"/></do>\n";
echo "<do type=\"options\" name=\"letters\" label=\"Почта ($inbox)\"><go href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache&amp;mod=inbox\" method=\"get\"/></do>\n";
echo "<do type=\"options\" name=\"menu\" label=\"Прихожая\"><go href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\" method=\"get\"/></do>\n";
echo "<p align=\"left\">\n";

include "bots/joker.php";

if($rid == 1)
{
include "bots/bot.php";
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 1 WHERE `id` = 3;");
}

if($rid == 3)
{
include "bots/boor.php";
include "bots/second_bot.php";
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 3 WHERE `id` = 4;");
}

if($fsize == 0)
{
$open_tag = "<small>";
$close_tag = "</small>";
}
if($fsize == 1)
{
$open_tag = "";
$close_tag = "";
}
if($fsize == 2)
{
$open_tag = "<big>";
$close_tag = "</big>";
}

echo $open_tag;

echo "<a href=\"#add\">Сказать</a><br/>\n";
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache\">Обновить</a><br/>\n";

if(isset($_POST['msg']))
{
mysql_query("SELECT * FROM `chat".$rid."` WHERE `aid` = '".$id."' AND `seconds` > ".(time() - 20).";");
if(mysql_affected_rows() > 3)
{
$reason = "Вы были автоматически забанены системой за флуд (многократное повторение сообщений).";
mysql_query("UPDATE `chat_users` SET `kick` = ".(time() + 180).", `moder` = '".$bots[3]."', `reason` = '".$reason."' WHERE `id` = '".$id."';");
}

$msg = trim($_POST['msg']);

if(isset($_POST['uid']))
{
$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = ".intval($_POST['uid']).";");
$nick = mysql_result($sql, 0);
}
else
{
$nick = "";
}

$msg = stripslashes($msg);

	if($_POST['translit'] == "true")
	{
	$msg = str_replace("\"", "ъ", $msg);
	$msg = str_replace("'", "ь", $msg);

	$lat = array("CH", "ch", "SC", "sc", "YE", "ye", "YU", "yu", "YA", "ya", "YO", "yo");
	$rus = array("Ч", "ч", "Щ", "щ", "Э", "э", "Ю", "ю", "Я", "я", "Ё", "ё");
	$msg = str_replace($lat, $rus, $msg);

	$lat = array("A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "H", "h", "Z", "z", "W", "w", "X", "x", "Y", "y");
	$rus = array("А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з", "Ш", "ш", "Ы", "ы", "Й", "й");
	$msg = str_replace($lat, $rus, $msg);
	}

$msg = htmlspecialchars($msg);

//SMILES
include "smiles.php";
$msg = preg_replace($smiles_array, $smile, $msg, 2);

unset($smiles_array);
unset($smile);

if(!empty($nick))
{
$msg = "$nick, $msg";
}

$msg = iconv('utf-8', 'windows-1251', $msg);
$msg = substr($msg, 0, 1000);
$msg = iconv('windows-1251', 'utf-8', $msg);
$msg = str_replace("$", "$$", $msg);

$emotions = intval($_POST['emotions']);

switch($emotions)
{
case 1:
$msg = "[Радостно] $msg";
break;

case 2:
$msg = "[Печально] $msg";
break;

case 3:
$msg = "[Удивленно] $msg";
break;

case 4:
$msg = "[Ласково] $msg";
break;

case 5:
$msg = "[Смущенно] $msg";
break;

case 6:
$msg = "[Кокетливо] $msg";
break;

case 7:
$msg = "[Обиженно] $msg";
break;

case 8:
$msg = "[Настойчиво] $msg";
break;

case 9:
$msg = "[Шепотом] $msg";
break;

case 10:
$msg = "[Задумчиво] $msg";
break;

case 11:
$msg = "[Злобно] $msg";
break;
}

	if($level > 0)
	{
	$attributs = $_POST['attributs'];
	$post_fsize = (int)$_POST['fsize'];

	if(substr_count($attributs, "underline") != 0) $msg = "<u>$msg</u>";

		if($level > 2)
		{
		if(substr_count($attributs, "bold") != 0) $msg = "<b>$msg</b>";
		}

		if($level == 4)
		{
		if(substr_count($attributs, "italic") != 0) $msg = "<i>$msg</i>";
		if($post_fsize == 0) $msg = "<small>$msg</small>";
		if($post_fsize == 2) $msg = "<big>$msg</big>";
		}
	}

//ubiranie reklamy
if($adv == 1 && $level < 4)
{
$msg = eregi_replace("((([a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z;]{2,3}))|(([0-9]{1,3}\.){3}([0-9]{1,3})))((/|\?)[a-z0-9~#%&'_\+=:;\?\.-]*)*)", "censored", $msg);
}

if($level == 4) 
{
$msg = preg_replace("|\*\((.*)\)\*|isU", "<b>\\1</b>", $msg);
}

$msg = mysql_escape_string($msg);

$sql = mysql_query("SELECT `msg` FROM `chat".$rid."` WHERE `aid` = '".$id."' ORDER BY `id` DESC LIMIT 1;");
$last_msg = mysql_escape_string(mysql_result($sql, 0));

	if($last_msg != $msg && !empty($msg))
	{
	$to = (int)$_POST['to'];
	$sql = mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '".$id."', '".$nickname."', '".$msg."', '".$to."', '".date("H:i:s")."',".time().");");
		if(mysql_insert_id() > 4000000000)
		{
		mysql_query("TRUNCATE TABLE `chat".$rid."`;");
		$message = "Комната была очищена системой. Данная операция была важна для снятия нагрузки с базы данных.";
		$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");
			while($room_id = mysql_fetch_array($sql))
			{
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '5', '".$bots[3]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
			}
		}
		if(!$sql)
		{
		$sql = mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '".$id."', '".$nickname."', '".$msg."', '".$to."', '".date("H:i:s")."', ".time().");");
		}
	mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = '".$id."';");
	if($rid == 1) include "bots/answer.php";
	if($rid == 3) include "bots/second_answer.php";
	}
}

$sql = mysql_query("SELECT COUNT(*) FROM `chat".$rid."`;");
$all = mysql_result($sql, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;

$ignor = "";

$sql = mysql_query("SELECT * FROM `chat_ignor` WHERE `id` = '".$id."';");
while($ignor_arr = mysql_fetch_array($sql))
{
$ignor .= " `aid` != '".$ignor_arr['uid']."' AND ";
}

if($id != 1) $sql = mysql_query("SELECT * FROM `chat".$rid."` WHERE ".$ignor." (`to` = 0 OR `to` = '".$id."' OR `aid` = '".$id."') ORDER BY `id` DESC LIMIT $s, $msgs;");
else $sql = mysql_query("SELECT * FROM `chat".$rid."` WHERE ".$ignor." `aid` != 0 ORDER BY `id` DESC LIMIT $s, $msgs;");

while($post = mysql_fetch_array($sql))
{
if($post['to'] != 0) echo "<b>[P!]</b>";
echo "<a href=\"addto.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache&amp;uid=".$post['aid']."\">".$post['nickname']."</a> [".$post['time']."]<br/>\n";
$post['msg'] = stripslashes($post['msg']);
if($smiles == 0) $post['msg'] = preg_replace("|<img[^>]+>|isU", "*smile*", $post['msg']); 
echo $post['msg']."<br/>\n";
}

if ($all > $s + $msgs)  print "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache&amp;s=".($s + $msgs)."\">&gt;&gt;&gt;</a><br/>\n";
if ($s > 0)  print "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache&amp;s=".($s - $msgs)."\">&lt;&lt;&lt;</a><br/>\n";

echo "<a href=\"mood.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\">Настроение</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\">Прихожая</a><br/>\n";

echo $close_tag;

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec) - $headtime, 5)."] sec</small><br/>\n";
echo "</p></card><card id=\"add\" title=\"Сказать\"><p align=\"left\">";
echo "Сообщение:<br/>\n";
echo "<input type=\"text\" name=\"msg$nocache\" maxlength=\"300\" value=\"\"/><br/>\n";

if($translit == 1)
{
echo "Транслитировать:<br/>\n";
echo "<select name=\"translit$nocache\" value=\"true\">\n";
echo "<option value=\"true\">Да</option>\n";
echo "<option value=\"false\">Нет</option>\n";
echo "</select><br/>\n";
}

if($level > 0)
{
echo "Аттрибуты:<br/>\n";
echo "<select name=\"attributs$nocache\" multiple=\"true\">\n";
if($level > 2) echo "<option value=\"bold\">Жирный</option>\n";
echo "<option value=\"underline\">Подчеркнутый</option>\n";
if($level == 4)echo "<option value=\"italic\">Курсив</option>\n";
echo "</select><br/>\n";
}

if($level == 4)
{
echo "Размер:<br/>\n";
echo "<select name=\"fsize$nocache\" value=\"1\">\n";
echo "<option value=\"0\">Маленький</option>\n";
echo "<option value=\"1\">Нормальный</option>\n";
echo "<option value=\"2\">Большой</option>\n";
echo "</select><br/>\n";
}

if($emotions == 1)
{
echo "Эмоции:<br/>\n";
echo "<select name=\"emotions$nocache\" value=\"0\">\n";
echo "<option value=\"0\">Без эмоций</option>\n";
echo "<option value=\"1\">Радостно</option>\n";
echo "<option value=\"2\">Печально</option>\n";
echo "<option value=\"3\">Удивленно</option>\n";
echo "<option value=\"4\">Ласково</option>\n";
echo "<option value=\"5\">Смущенно</option>\n";
echo "<option value=\"6\">Кокетливо</option>\n";
echo "<option value=\"7\">Обиженно</option>\n";
echo "<option value=\"8\">Настойчиво</option>\n";
echo "<option value=\"9\">Шепотом</option>\n";
echo "<option value=\"10\">Задумчиво</option>\n";
echo "<option value=\"11\">Злобно</option>\n";
echo "</select><br/>\n";
}

echo "<anchor>[Сказать]<go href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache\" method=\"post\">\n";
echo "<postfield name=\"msg\" value=\"$(msg$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"attributs\" value=\"$(attributs$nocache)\"/>\n";
echo "<postfield name=\"fsize\" value=\"$(fsize$nocache)\"/>\n";
echo "<postfield name=\"emotions\" value=\"$(emotions$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=wml&amp;rid=$rid&amp;nocache=$nocache\">Назад</a><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
else
{
$user = mysql_fetch_array($q);
$nickname = $user['nickname'];
$smiles = $user['smiles'];
$translit  = $user['translit'];
$msgs  = $user['msgs'];
$refresh = $user['refresh'];
$fsize = $user['fsize'];
$security  = $user['security'];
$level = $user['level'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
}
//END AUTH

if(((strpos($ua, "Opera") !== false) or (strpos($ua, "Mozilla") !== false) or (strpos($ua, "MSIE") !== false)  or (strpos($ua, "Netscape") !== false)) && $computer == 1 && $level == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Доступ с компьютера запрещен.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

$rid = intval($_GET['rid']);

$sql = mysql_query("SELECT `topic`, `type` FROM `chat_rooms` WHERE `id` = '".$rid."';");

if(mysql_num_rows($sql) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Такой комнаты не существует.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
else
{
$topic = mysql_result($sql, 0, 'topic');
$type = mysql_result($sql, 0, 'type');
}

if($level == 0 && $type == 1)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Доступ запрещен.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

if($kick > time() && ($rid != $wicked_quiz && $rid != $unlim))
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Вы временно заблокированы модератором <u>$moder</u> на <u>".($kick - time())."</u> сек.<br/>\n";
echo "Причина: $reason<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

//ONLINE
$online = time() + 90;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = '".$rid."', `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

if($fsize == 0)
{
$fsize = "small";
}
if($fsize == 1)
{
$fsize = "normal";
}
if($fsize == 2)
{
$fsize = "large";
}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<meta http-equiv=\"refresh\" content=\"$refresh;url=".$_SERVER['PHP_SELF']."?id=$id&amp;password=$password&amp;ver=html&amp;rid=$rid&amp;nocache=$nocache\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$topic."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: ".$fsize."; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div.form { background-color: ".$form_color." }
</style></head><body>";

include "bots/joker.php";

if($rid == 1)
{
include "bots/bot.php";
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 1 WHERE `id` = 2;");
}

if($rid == 3)
{
include "bots/boor.php";
include "bots/second_bot.php";
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 3 WHERE `id` = 4;");
}

echo "<a href=\"add.php?id=$id&amp;password=$password&amp;ver=html&amp;rid=$rid&amp;nocache=$nocache\">Сказать</a><br/>\n";
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;ver=html&amp;rid=$rid&amp;nocache=$nocache\">Обновить</a><br/>\n";
echo "<a href=\"online.php?id=$id&amp;password=$password&amp;ver=html&amp;nocache=$nocache\">Кто где?</a><br/>\n";
if(isset($_POST['msg']))
{
mysql_query("SELECT * FROM `chat".$rid."` WHERE `aid` = '".$id."' AND `seconds` > ".(time() - 20).";");
if(mysql_affected_rows() > 3)
{
$reason = "Вы были автоматически забанены системой за флуд (многократное повторение сообщений).";
mysql_query("UPDATE `chat_users` SET `kick` = ".(time() + 180).", `moder` = '".$bots[3]."', `reason` = '".$reason."' WHERE `id` = '".$id."';");
}

$msg = trim($_POST['msg']);

if(isset($_POST['uid']))
{
$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = ".intval($_POST['uid']).";");
$nick = mysql_result($sql, 0);
}
else
{
$nick = "";
}

$msg = stripslashes($msg);

	if($_POST['translit'] == "true")
	{
	$msg = str_replace("\"\"", "Ъ", $msg);
	$msg = str_replace("\"", "ъ", $msg);
	$msg = str_replace("''", "Ь", $msg);
	$msg = str_replace("'", "ь", $msg);

	$lat = array("CH", "ch", "SC", "sc", "YE", "ye", "YU", "yu", "YA", "ya", "YO", "yo");
	$rus = array("Ч", "ч", "Щ", "щ", "Э", "э", "Ю", "ю", "Я", "я", "Ё", "ё");
	$msg = str_replace($lat, $rus, $msg);

	$lat = array("A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "H", "h", "Z", "z", "W", "w", "X", "x", "Y", "y");
	$rus = array("А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з", "Ш", "ш", "Ы", "ы", "Й", "й");
	$msg = str_replace($lat, $rus, $msg);
	}

$msg = htmlspecialchars($msg);

//SMILES
include "smiles.php";
$msg = preg_replace($smiles_array, $smile, $msg, 2);

if(!empty($nick))
{
$msg = "$nick, $msg";
}

$msg = iconv('utf-8', 'windows-1251', $msg);
$msg = substr($msg, 0, 1000);
$msg = iconv('windows-1251', 'utf-8', $msg);
$msg = str_replace("$", "$$", $msg);

$emotions = intval($_POST['emotions']);

switch($emotions)
{
case 1:
$msg = "[Радостно] $msg";
break;

case 2:
$msg = "[Печально] $msg";
break;

case 3:
$msg = "[Удивленно] $msg";
break;

case 4:
$msg = "[Ласково] $msg";
break;

case 5:
$msg = "[Смущенно] $msg";
break;

case 6:
$msg = "[Кокетливо] $msg";
break;

case 7:
$msg = "[Обиженно] $msg";
break;

case 8:
$msg = "[Настойчиво] $msg";
break;

case 9:
$msg = "[Шепотом] $msg";
break;

case 10:
$msg = "[Задумчиво] $msg";
break;

case 11:
$msg = "[Злобно] $msg";
break;
}

	if($level > 0)
	{
	$attributs = $_POST['attributs'];
	$post_fsize = (int)$_POST['fsize'];

	if(substr_count($attributs, "underline") != 0) $msg = "<u>$msg</u>";

		if($level > 2)
		{
		if(substr_count($attributs, "bold") != 0) $msg = "<b>$msg</b>";
		}

		if($level == 4)
		{
		if(substr_count($attributs, "italic") != 0) $msg = "<i>$msg</i>";
		if($post_fsize == 0) $msg = "<small>$msg</small>";
		if($post_fsize == 2) $msg = "<big>$msg</big>";
		}
	}


if($adv == 1 && $level < 4)
{
$msg = eregi_replace("((([a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z;]{2,3}))|(([0-9]{1,3}\.){3}([0-9]{1,3})))((/|\?)[a-z0-9~#%&'_\+=:;\?\.-]*)*)", "censored", $msg);
}

if($level == 4) 
{
$msg = preg_replace("|\*\((.*)\)\*|isU", "<b>\\1</b>", $msg);
}

$msg = mysql_escape_string($msg);

$sql = mysql_query("SELECT `msg` FROM `chat".$rid."` WHERE `aid` = '".$id."' ORDER BY `id` DESC LIMIT 1;");
$last_msg = mysql_escape_string(mysql_result($sql, 0));

	if($last_msg != $msg && !empty($msg))
	{
	$to = (int)$_POST['to'];
	$sql = mysql_query("INSERT INTO `chat` VALUES(0, '".$id."', '".$nickname."', '".$msg."', '".$rid."', '".$to."', '".date("H:i:s")."',".time().");");
		if(mysql_insert_id() > 4000000000)
		{
		mysql_query("TRUNCATE TABLE `chat".$rid."`;");
		$message = "Комната была очищена системой. Данная операция была важна для снятия нагрузки с базы данных.";
		$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");
			while($room_id = mysql_fetch_array($sql))
			{
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '5', '".$bots[3]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
			}
		}
		if(!$sql)
		{
		$sql = mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '".$id."', '".$nickname."', '".$msg."', '".$to."', '".date("H:i:s")."', ".time().");");
		}
	mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = '".$id."';");
	if($rid == 1) include "bots/answer.php";
	if($rid == 3) include "bots/second_answer.php";
	}
}

$sql = mysql_query("SELECT COUNT(*) FROM `chat".$rid."`;");
$all = mysql_result($sql, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;

$ignor = "";

$sql = mysql_query("SELECT * FROM `chat_ignor` WHERE `id` = '".$id."';");
while($ignor_arr = mysql_fetch_array($sql))
{
$ignor .= " `aid` != '".$ignor_arr['uid']."' AND ";
}

if($id != 1) $sql = mysql_query("SELECT * FROM `chat".$rid."` WHERE ".$ignor." (`to` = 0 OR `to` = '".$id."' OR `aid` = '".$id."') ORDER BY `id` DESC LIMIT $s, $msgs;");
else $sql = mysql_query("SELECT * FROM `chat".$rid."` WHERE ".$ignor." `aid` != 0 ORDER BY `id` DESC LIMIT $s, $msgs;");

$c = 0;

while($post = mysql_fetch_array($sql))
{
if($c == 0)
{
$div = "<div class=\"form\">\n";
$close = "</div>\n";
$c = 1;
}
else
{
$div = "";
$close = "";
$c = 0;
}
echo $div;
if($post['to'] != 0) echo "<b>[P!]</b>";
echo "<a href=\"addto.php?id=$id&amp;password=$password&amp;ver=html&amp;rid=$rid&amp;nocache=$nocache&amp;uid=".$post['aid']."\">".$post['nickname']."</a> [".$post['time']."]<br/>\n";
$post['msg'] = str_replace('$$', '$', $post['msg']);
$post['msg'] = stripslashes($post['msg']);
if($smiles == 0) $post['msg'] = preg_replace("|<img[^>]+>|isU", "*smile*", $post['msg']); 
echo $post['msg']."<br/>\n";
echo $close;
}

if ($all > $s + $msgs)  print '<a href="room.php?id='.$id.'&amp;password='.$password.'&amp;ver=html&amp;rid='.$rid.'&amp;nocache='.$nocache.'&amp;s='.($s + $msgs).'">&gt;&gt;&gt;</a><br/>';
if ($s > 0)  print '<a href="room.php?id='.$id.'&amp;password='.$password.'&amp;ver=html&amp;rid='.$rid.'&amp;nocache='.$nocache.'&amp;s='.($s - $msgs).'">&lt;&lt;&lt;</a><br/>';

echo '<a href="mood.php?id='.$id.'&amp;password='.$password.'&amp;ver=html&amp;nocache='.$nocache.'">Настроение</a><br/>';
echo '<a href="menu.php?id='.$id.'&amp;password='.$password.'&amp;ver=html&amp;nocache='.$nocache.'">Прихожая</a><br/>';
list($msec, $sec) = explode(chr(32), microtime());
echo '<br/><span style="font-size: small">['.round(($sec+$msec)-$headtime,5).'] sec</span><br/>';
echo '</body></html>';
break;
}
?>