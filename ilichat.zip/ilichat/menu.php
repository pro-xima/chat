<?php
error_reporting(0);

include("config.php");
include("./includes/constants/menu");
include("./includes/".$ver."/banned");

$old_msgs = 6; //HOURS

$fd = fopen("clear.dat", "r");
$clear_time = intval(fgets($fd));
fclose($fd);

if($clear_time < time())
{
$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");

	while($room = mysql_fetch_array($sql))
	{
	mysql_query("DELETE FROM `chat".$room['id']."` WHERE `seconds` < ".(time() - (3600 * $old_msgs)).";");
	mysql_query("DELETE FROM `chat_intim` WHERE `seconds` < ".(time() - (3600 * $old_msgs)).";");
	}

$fd = fopen("clear.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + 3600 * $old_msgs));
flock($fd, LOCK_UN);
fclose($fd);
}

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(10000, 99999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
if(isset($_POST['action']))
{
	if($_POST['translit'] == "yes")
	{
	$lat = array("''", "'", "\"\"", "\"", "CH", "ch", "SC", "sc", "YE", "ye", "YU", "yu", "YA", "ya", "YO", "yo", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "H", "h", "Z", "z", "W", "w", "X", "x", "Y", "y");
	$rus = array("Ь", "ь", "Ъ", "ъ", "Ч", "ч", "Щ", "щ", "Э", "э", "Ю", "ю", "Я", "я", "Ё", "ё", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з", "Ш", "ш", "Ы", "ы", "Й", "й");
	$_POST['nickname'] = str_replace($lat, $rus, $_POST['nickname']);
	}

$nickname = mysql_escape_string($_POST['nickname']);
$password = mysql_escape_string($_POST['password']);

$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."' AND `password` = '".$password."' LIMIT 1;");
	if(mysql_num_rows($q) == 0)
	{
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
	echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
	echo "<small>Ошибка авторизации!<br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
	echo "</small></p></card></wml>";
	exit();
	}
}
else
{
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
	if(mysql_num_rows($q) == 0)
	{
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
	echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
	echo "<small>Ошибка авторизации!<br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
	echo "</small></p></card></wml>";
	exit();
	}
}
//END AUTH

//USER DATA
$user = mysql_fetch_array($q);
$id = $user['id'];
$nickname = $user['nickname'];
$level = $user['level'];
$status = $user['status'];
$posts = $user['posts'];
$time = $user['time'];
$ip = $user['ip'];
$ua = $user['ua'];
$security = $user['security'];
$fsize = $user['fsize'];
//END USER DATA

//STATUS UPDATE
if($status == STATUS_NOVICE && $posts > 500 && $posts < 1000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_USER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_USER && $posts > 1000 && $posts < 3000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_ADVANCED."' WHERE `id` = '".$id."';");
}
if($status == STATUS_ADVANCED && $posts > 3000 && $posts < 5000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_CHATTER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_CHATTER && $posts > 5000 && $posts < 7000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_SUPER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_SUPER && $posts > 7000 && $posts < 10000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_MEGA."' WHERE `id` = '".$id."';");
}
//END STATUS UPDATE

if($fsize == 0)
{
$open_tag = "<small>";
$close_tag = "</small>";
}
if($fsize == 1)
{
$open_tag = "";
$close_tag = "";
}
if($fsize == 2)
{
$open_tag = "<big>";
$close_tag = "</big>";
}

if($security == 1 && ($ip != getenv('REMOTE_ADDR') OR $ua != htmlspecialchars(getenv('HTTP_USER_AGENT'))))
{
$bot = file("bots/bots.dat");
$system_bot = trim($bot[3]);

$message = "$nickname, ".SECURITY_MESSAGE."<br />\n";
$message .= "Зашли с IP: ".getenv('REMOTE_ADDR').", User-Agent (Browser): ".getenv('HTTP_USER_AGENT').". Рекомендуем срочно сменить пароль:<br />\n";
$message .= "<a href=\'profile.php?id=".$id."&amp;password=".$password."\'>[Изменить]</a>\n";

$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");
	while($rooms = mysql_fetch_array($sql))
	{
	mysql_query("INSERT INTO `chat".$rooms['id']."` VALUES(0, '5', '".$system_bot."', '".$message."', '".$id."', '".date("H:i:s")."', ".time().");");
	}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card id=\"security\" title=\"Внимание!\"><p align=\"center\">\n";
echo $open_tag;
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;ref=".rand(1, 100)."\">[Продолжить]</a><br/>";
echo "Ваши текущие данные не совпадают с данными, когда заходили под этим ником.<br/>\n";
echo "Возможно, под вашим ником заходил посторонний человек.<br/>\n";
echo "Если вы не заходили в чат с IP <u>$ip</u> и/или User-Agent (Browser) <u>$ua</u>, то советуем сменить пароль.<br/>\n";
echo "Отключить оповещение можно в настройках.<br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;ref=".rand(1, 100)."\">[Продолжить]</a><br/>";
echo $close_tag;
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</p></card></wml>";
$online = time() + 60;
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\">\n<wml>\n";
echo "<card title=\"".TITLE."\"><p align=\"center\">\n";
echo $open_tag;
if($level == 4) echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_ADMIN."</a><br/>\n---<br/>\n";
if($level == 3) echo "<a href=\"smoder.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_SMODER."</a><br/>---<br/>\n\n";
if($level == 2) echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_MODER."</a><br/>---<br/>\n";
if($level == 1) echo "<a href=\"vip.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_VIP."</a><br/>---<br/>\n";
if(time() > $time + 3600) echo "Привет, $nickname!<br/>";

//NEWS
$query = mysql_query("SELECT `id`, `name` FROM `chat_news` ORDER BY `id` DESC;");

while($news = @mysql_fetch_array($query))
{
$nid = $news['id'];
$name = $news['name'];
echo "<a href=\"news.php?id=$id&amp;password=$password&amp;nid=$nid&amp;ver=wml\">".$name."</a><br/>\n";
}
//END NEWS

//MEETS
$query = mysql_query("SELECT COUNT(*) FROM `chat_meets`;");
$meets = mysql_result($query, 0);
//END MEETS

//LETTERS
$query = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' AND `read` = 0;");
$newto = mysql_result($query, 0);

$query = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';");
$to = mysql_result($query, 0);
//END LETTERS

//ONLINE IN CHAT
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time().";");
$online = mysql_result($query, 0);
//END ONLINE

$in_embassies = 0;

$sql = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `type` = 2;");

while($array = mysql_fetch_array($sql))
{
$rid = $array['id'];

$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time()." AND `place` = '".$rid."';");
$in_embassies = $in_embassies + mysql_result($query, 0);
}

echo "<a href=\"meets.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_MEETS." ($meets)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_MAILBOX." ($newto/$to)</a><br/>\n";
echo "<a href=\"online.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_ONLINE." ($online)</a><br/>\n---<br/>\n";
echo "<a href=\"gallery.php?id=$id&amp;password=$password\">Галерея</a><br/>\n---<br/>\n";
echo "<a href=\"search.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_SEARCH."</a><br/>\n---<br/>\n";
echo "<a href=\"games/dice.php?id=$id&amp;password=$password&amp;ver=wml\">".GAMES_DICE."</a><br/>\n---<br/>\n";
echo "<a href=\"embassies.php?id=$id&amp;password=$password&amp;ver=wml\">".ROOMS_EMBASSIES." (".$in_embassies.")</a><br/>";

//PUBLIC ROOMS
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 0 ORDER BY `position` ASC;");

if(mysql_num_rows($q) == 0)
{
echo EMPTY_ROOMS_LIST."<br/>\n";
}

while($room = mysql_fetch_array($q))
{
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` >= ".time().";");
$inroom = mysql_result($query, 0);
	if($rid == $wicked_quiz or $rid == $unlim)
	{
	echo "<a href=\"unlim.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
	else
	{
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
}
//END ROOMS

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `intim` >= ".time().";");
$intim = mysql_result($sql, 0);
echo "<a href=\"key.php?id=$id&amp;password=$password&amp;ver=wml\">".ROOMS_INTIM." ($intim)</a><br/>\n";
echo "---<br/>\n";

//ROOMS FOR MODERATORS
if($level != 0)
{
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 1 ORDER BY `position` ASC;");

while($room = mysql_fetch_array($q))
{
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` >= ".time().";");
$inroom = mysql_result($query, 0);
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
}
	if(mysql_num_rows($q) != 0)
	{
	echo "---<br/>\n";
	}
}
//END ROOMS

echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_FAQ."</a><br/>\n";
echo "<a href=\"ignor.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_IGNOR."</a><br/>\n";
echo "<a href=\"profile.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_PROFILE."</a><br/>\n";
echo "<a href=\"settings.php?id=$id&amp;password=$password&amp;ver=wml\">".MENU_SETTINGS."</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">".VERSION_HTML."</a> | ".VERSION_WML."<br/>\n";
echo "<a href=\"http://ili.wab.ru\">Главная</a><br/>\n";

echo $close_tag;

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");
$inmenu = mysql_result($q, 0);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");

echo "<small>В меню: ".$inmenu."<br/>\n";
$c = 0;
while($nick = mysql_fetch_array($q))
{
echo $nick['nickname'];
$c++;
if($c != $inmenu) echo ", ";
}

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
if(isset($_POST['action']))
{
	if($_POST['translit'] == "yes")
	{
	$lat = array("''", "'", "\"\"", "\"", "CH", "ch", "SC", "sc", "YE", "ye", "YU", "yu", "YA", "ya", "YO", "yo", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "H", "h", "Z", "z", "W", "w", "X", "x", "Y", "y");
	$rus = array("Ь", "ь", "Ъ", "ъ", "Ч", "ч", "Щ", "щ", "Э", "э", "Ю", "ю", "Я", "я", "Ё", "ё", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з", "Ш", "ш", "Ы", "ы", "Й", "й");
	$_POST['nickname'] = str_replace($lat, $rus, $_POST['nickname']);
	}

$nickname = mysql_escape_string($_POST['nickname']);
$password = mysql_escape_string($_POST['password']);

$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."' AND `password` = '".$password."';");
	if(mysql_num_rows($q) == 0)
	{
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10-flat.dtd\">\n";
	echo "<html><head>\n";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
	echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
	echo "<style type=\"text/css\">";
	echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }";
	echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }";
	echo "</style></head><body>";
	echo "Ошибка авторизации!<br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
	echo "</body></html>";
	exit();
	}
}
else
{
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
	if(mysql_num_rows($q) == 0)
	{
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10-flat.dtd\">\n";
	echo "<html><head>\n";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
	echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
	echo "<style type=\"text/css\">";
	echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }";
	echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }";
	echo "</style></head><body>";
	echo "Ошибка авторизации!<br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
	echo "</body></html>";
	exit();
	}
}
//END AUTH

//USER DATA
$user = mysql_fetch_array($q);
$id = $user['id'];
$nickname = $user['nickname'];
$level = $user['level'];
$status = $user['status'];
$time = $user['time'];
$fsize = $user['fsize'];
$ip = $user['ip'];
$ua = $user['ua'];
$security = $user['security'];
//END USER DATA

if($fsize == 0)
{
$fsize = "small";
}
if($fsize == 1)
{
$fsize = "normal";
}
if($fsize == 2)
{
$fsize = "large";
}

//NORMAL'NYI VHOD
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".TITLE."</title>\n";
print "<div style=\"background-color:#EE0000;border:2px outset #FF0000;color:white;\" align=\"center\"><b>ILI.WAB.RU</b></div>";
print "<div style=\"background-color:$form_color;border:2px outset #EEB422;color:white;\" align=\"center\">Приятного общения!</div><br/>";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: $fsize; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body><div style=\"text-align: center\">";

//STATUS UPDATE
if($status == STATUS_NOVICE && $posts > 500 && $posts < 1000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_USER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_USER && $posts > 1000 && $posts < 3000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_ADVANCED."' WHERE `id` = '".$id."';");
}
if($status == STATUS_ADVANCED && $posts > 3000 && $posts < 5000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_CHATTER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_CHATTER && $posts > 5000 && $posts < 7000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_SUPER."' WHERE `id` = '".$id."';");
}
if($status == STATUS_SUPER && $posts > 7000 && $posts < 10000)
{
$query = mysql_query("UPDATE `chat_users` SET `status` = '".STATUS_MEGA."' WHERE `id` = '".$id."';");
}
//END STATUS UPDATE

if($security == 1 && ($ip != getenv('REMOTE_ADDR') OR $ua != htmlspecialchars(getenv('HTTP_USER_AGENT'))))
{
$bot = file("bots/bots.dat");
$system_bot = trim($bot[3]);

$message = "$nickname, С Вашего ника сейчас зашел пользователь с данными, не совпадающими с Вашими.<br />\n";
$message .= "Зашли с IP: ".getenv('REMOTE_ADDR').", User-Agent (Browser): ".getenv('HTTP_USER_AGENT').". Рекомендуем срочно сменить пароль:<br />\n";
$message .= "<a href=\'profile.php?id=".$id."&amp;password=".$password."\'>[Изменить]</a>\n";

$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");
	while($rooms = mysql_fetch_array($sql))
	{
	mysql_query("INSERT INTO `chat".$rooms['id']."` VALUES(0, '5', '".$system_bot."', '".$message."', '".$id."', '".date("H:i:s")."', ".time().");");
	}

echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">[Продолжить]</a><br/>";
echo "Ваши текущие данные не совпадают с данными, когда заходили под этим ником.<br/>\n";
echo "Возможно, под вашим ником заходил посторонний человек.<br/>\n";
echo "Если вы не заходили в чат с IP <u>$ip</u> и/или User-Agent (Browser) <u>$ua</u>, то советуем сменить пароль.<br/>\n";
echo "Отключить оповещение можно в настройках.<br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html&amp;ref=".rand(1, 100)."\">[Продолжить]</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>\n";
echo "<span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
$online = time() + 60;
mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE


if($level == 4) echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html\">Админка</a><br/>\n---<br/>\n";
if($level == 3) echo "<a href=\"smoder.php?id=$id&amp;password=$password&amp;ver=html\">С-модерка</a><br/>---<br/>\n\n";
if($level == 2) echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html\">Модерка</a><br/>---<br/>\n\n";
if($level == 1) echo "<a href=\"vip.php?id=$id&amp;password=$password&amp;ver=html\">VIP-меню</a><br/>---<br/>\n";
if(time() > $time + 3600) echo "Привет, $nickname!<br/>";

//NEWS
$query = mysql_query("SELECT `id`, `name` FROM `chat_news` ORDER BY `id` DESC;");

while($news = @mysql_fetch_array($query))
{
$nid = $news['id'];
$name = $news['name'];
echo "<a href=\"news.php?id=$id&amp;password=$password&amp;nid=$nid&amp;ver=html\">".$name."</a><br/>\n";
}
//END NEWS

//MEETS
$query = mysql_query("SELECT COUNT(*) FROM `chat_meets`;");
$meets = mysql_result($query, 0);
//END MEETS

//LETTERS
$query = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' AND `read` = 0;");
$newto = mysql_result($query, 0);

$query = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';");
$to = mysql_result($query, 0);
//END LETTERS

//ONLINE IN CHAT
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time().";");
$online = mysql_result($query, 0);
//END ONLINE

$in_embassies = 0;

$sql = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `type` = 2;");

while($array = mysql_fetch_array($sql))
{
$rid = $array['id'];

$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time()." AND `place` = '".$rid."';");
$in_embassies = $in_embassies + mysql_result($query, 0);
}

echo "<a href=\"meets.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_MEETS." ($meets)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_MAILBOX." ($newto/$to)</a><br/>\n";
echo "<a href=\"online.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_ONLINE." ($online)</a><br/>\n";
echo "<a href=\"search.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_SEARCH."</a><br/>\n---<br/>\n";
echo "<a href=\"games/dice.php?id=$id&amp;password=$password&amp;ver=html\">".GAMES_DICE."</a><br/>\n---<br/>\n";
echo "<a href=\"embassies.php?id=$id&amp;password=$password&amp;ver=html\">".ROOMS_EMBASSIES." (".$in_embassies.")</a><br/>";

//PUBLIC ROOMS
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 0 ORDER BY `position` ASC;");

if(mysql_num_rows($q) == 0)
{
echo EMPTY_ROOMS_LIST."<br/>\n";
}

while($room = mysql_fetch_array($q))
{
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` >= ".time().";");
$inroom = mysql_result($query, 0);
	if($rid == $wicked_quiz or $rid == $unlim)
	{
	echo "<a href=\"unlim.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html\">".$rname." (".$inroom.")</a><br/>\n";
	}
	else
	{
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html\">".$rname." (".$inroom.")</a><br/>\n";
	}
}
//END ROOMS

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `intim` >= ".time().";");
$intim = mysql_result($sql, 0);
echo "<a href=\"key.php?id=$id&amp;password=$password&amp;ver=html\">".ROOMS_INTIM." ($intim)</a><br/>\n";
echo "---<br/>\n";

//ROOMS FOR MODERATORS
if($level != 0)
{
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 1 ORDER BY `position` ASC;");

while($room = mysql_fetch_array($q))
{
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` >= ".time().";");
$inroom = mysql_result($query, 0);
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html\">".$rname." (".$inroom.")</a><br/>\n";
}
	if(mysql_num_rows($q) != 0)
	{
	echo "---<br/>\n";
	}
}
//END ROOMS

echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_FAQ."</a><br/>\n";
echo "<a href=\"ignor.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_IGNOR."</a><br/>\n";
echo "<a href=\"profile.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_PROFILE."</a><br/>\n";
echo "<a href=\"settings.php?id=$id&amp;password=$password&amp;ver=html\">".MENU_SETTINGS."</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html\">Темы</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">".VERSION_WML."</a> | ".VERSION_HTML."<br/>\n";
echo "<a href=\"http://ili.wab.ru\">Главная</a><br/>\n";

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");
$inmenu = mysql_result($q, 0);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");

echo "<span style=\"font-size: small\">В меню: ".$inmenu."</span><br/>\n";
$c = 0;
while($nick = mysql_fetch_array($q))
{
echo "<span style=\"font-size: small\">".$nick['nickname']."</span>";
$c++;
if($c != $inmenu) echo ", ";
}

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>\n</div>";
print "<br/><div style=\"background-color:$form_color;border:2px outset #EEB422;color:#8B1A1A;font-size:small;\" align=\"center\">[".round(($sec+$msec)-$headtime,5)."] sec</div><br/>";
echo "</body></html>";
break;
}
?>