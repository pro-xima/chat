<?php
$msg = preg_replace("/\[(.*)\] /", "", $msg);
$msg = str_replace($bots[2].", ", "", $msg);

$bnl = strlen($bots[2]);
$result = substr($msg, 0, $bnl);

if($result == $bots[2])
{
$sql = mysql_query("SELECT * FROM `chat_bad_answers` ORDER BY RAND() LIMIT 1;");
$bad_answer = mysql_result($sql, 0, 'answer');
$message = "$nickname, $bad_answer";
mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");
}
unset($result);

if($msg === "!question" or $msg === "!вопрос")
{
	if($buff_action != 0)
	{
	$fd = fopen("bots/second_bot/question.dat", "r");
	$question = fgets($fd);
	fclose($fd);
	$message = "$nickname, $question";
	mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
	mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");
	}
	else
	{
	$message = "$nickname, блять! Для тупых повторяю: время вышло! Жди следующего вопроса!";
	mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
	}
}

$result = substr($msg, 0, 5);

if($result == "stats" && strlen($msg) > 6)
{
$nick = mysql_escape_string(substr($msg, 6));
$sql = mysql_query("SELECT `answers` FROM `chat_users` WHERE `nickname` = '".$nick."';");
	if(mysql_num_rows($sql) == 0)
	{
	$message = "Ебоната $nick нет в базе данных!";
	mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
	mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");
	}
	else
	{
	$answers = mysql_result($sql, 0);
	$sql = mysql_query("SELECT `nickname` FROM `chat_users` ORDER BY `answers` DESC LIMIT 31;");

		$c = 0;

		while($users = mysql_fetch_array($sql))
		{
		$c++;
		if($users['nickname'] == $nick) break;
		}
		
		if($c != 31) $rating = "В рейтинге эта сука занимает $c место!";
		if($c == 31) $rating = "В рейтинге эта сука занимает место за пределами первых трех десятков хуюмников.";

	$message = "$nick хорошо отсосал(а) <u>$answers</u> раз. $rating";
	mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
	}
}

$result = substr($msg, 0, 3);

if($result == "fas")
{
$nick = mysql_escape_string(substr($msg, 4));

	if(empty($nick))
	{
	$message = "$nickname, ты не ввел ник, дебил!";
	mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."',".time().");");
	}
	else
	{
		if($level != 4)
		{
		$message = "$nickname, пошел на хуй! Не стану я юзера \"".$nick."\" доставать. Ты не админ!";
		mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
		}
		else
		{
			if($nick == $bots[2])
			{
			$message = "$nickname, а не охуел? Я сам на себя наезжать не собираюсь...";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
			elseif($nick == $bots[0])
			{
			$message = "$nickname, ты с ума сошел? Не тронь бота ".$bots[0]."!";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
			elseif($nick == $bots[1])
			{
			$message = "$nickname, вообще-то я на друзей не наезжаю!";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
			elseif($nick == $bots[3])
			{
			$message = "$nickname, ага. А потом мне влетит от системы...Не...Не буду...";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
			elseif($nick == "Unkind" || $nick == "SkarletOhara")
			{
			$message = "$nickname, иди в задницу, сука опущенная! Это создатель чата, мудила!";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
			else
			{
			$sql = mysql_query("SELECT * FROM `chat_bad_answers` ORDER BY RAND() LIMIT 1;");
			$bad_answer = mysql_result($sql, 0, 'answer');
			$message = "$nick, $bad_answer";
			mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
			}
		}
	}
}

//ANSWER
$fd = fopen("bots/second_bot/answer.dat", "r");
$answer = fgets($fd);
fclose($fd);

//TRAN ANSWER
$fd = fopen("bots/second_bot/translit.dat", "r");
$tran_answer = fgets($fd);
fclose($fd);

$up = array("А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "C", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "Ь", "Э", "Ю", "Я");
$down = array("а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "c", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я");

$msg = str_replace($up, $down, $msg);

if(($msg == $answer or $msg == $tran_answer) && $buff_action != 0)
{
$sql = mysql_query("SELECT `answers` FROM `chat_users` WHERE `id` = '".$id."';");
$answers = mysql_result($sql, 0);
$message = "Эта пять, $nickname! Придурки, ответ-то был: <b>$answer</b>. $nickname отсосал(а) ".(++$answers)." раз. Следующий вопрос задам через ".$intervals[1]." секунд, тупицы!";
mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
mysql_query("UPDATE `chat_users` SET `answers` = `answers` + 1 WHERE `id` = '".$id."';");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");

$fd = fopen("bots/second_bot/time.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + $intervals[1])); //NEXT QUESTION
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/action.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, "0");
flock($fd, LOCK_UN);
fclose($fd);
}
?>