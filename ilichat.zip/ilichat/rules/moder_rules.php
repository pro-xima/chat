<?php
error_reporting(0);

include("../config.php");
include("../includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo <<< END
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.3//EN" "http://www.wapforum.org/DTD/wml13.dtd"><wml>
<card title="Правила Модераторов"><p align="left">
<b>Модератор обязан:</b><br/>
1. Соблюдать общие правила чата.<br/>
2. Помогать разрешать конфликты между участниками чата.<br/>
3. Модератор должен быть беспристрастным.<br/>
4. Блокировать пользователей за нарушение правил:<br/>
4.1. За "легкий" мат блокировка должна быть не более чем на 3600 секунд (час). Если это было в первый раз, то необходимо просто сделать предупреждение.<br/>
4.2. В других случаях за ненормативную лексику блок не должен превышать 86400 секунд (сутки). Мат, прикрытый "звездочками" (*) не следует игнорировать.<br/>
4.3. За флуд следует блокировать пользователя максимум на 86400 секунд (сутки). В чате есть система ан�