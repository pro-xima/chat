<?
error_reporting(0);

list($msec, $sec) = explode(chr(32), microtime());
$headtime = $sec + $msec;

include "../config.php";

$questions = "questions.dat"; //QUESTIONS

$nocache = rand(10000, 99999);

header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card id=\"questions\" title=\"QUESTIONS DB\"><p>\n";

if(!file_exists($questions))
{
echo "Файл \"".htmlspecialchars($questions)."\" не существует.<br />\n";
echo "<a href=\"../\">Главная чата</a><br/><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
die();
}

if(!isset($_GET['action']))
{
echo "Установка базы данных вопросов для \"Викторины\":<br/>\n";
echo "<a href=\"index.php?action=go\">[OK]</a><br/>\n";
}
else
{
mysql_query("TRUNCATE TABLE `chat_questions`;");
$lat = array("Yi", "yi", "J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "&#39;", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Ы", "ы", "Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$file = file($questions);
$count = count($file);
$errors = false;
	for($i = 0; $i < $count; $i++)
	{
	$array = explode("::", $file[$i]);
	$array[1] = str_replace("\r\n", "\n", $array[1]);
	$array[1] = str_replace("\n", "", $array[1]);
	$translit = str_replace($rus, $lat, $array[1]);
	$array[0] = trim($array[0]);
	$array[1] = trim($array[1]);
	$sql = mysql_query("INSERT INTO `chat_questions` VALUES(0, '".$array[0]."', '".$array[1]."', '".$translit."');");
	$query = "INSERT INTO `chat_questions` VALUES(0, '".$array[0]."', '".$array[1]."', '".mysql_escape_string($translit)."');";
		if(!$sql)
		{
		echo "Ошибка. Не получилось добавить в базу вопрос. Строка: ".($i + 1)."<br/>\n";
		echo mysql_error()."<br/>\n";
		echo "Запрос: ".$query."<br/>\n";
		$errors = true;
		break;
		}
	}

	if($errors == false)
	{
	echo "Обновление базы вопросов: в базе теперь <u>".$count."</u> вопросов.<br/>\n";
	}
	else 
	{
	echo "При установке базы вопросов произошли ошибки.<br/>\n";
	echo "<a href=\"index.php?action=go\">[Переустановить]</a><br/>\n";
	}
}

echo "<a href=\"../\">Главная чата</a><br/><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
?>