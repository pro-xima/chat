<?php
list($msec, $sec) = explode(chr(32), microtime());
$headtime = $sec + $msec;

error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$nocache = rand(1000, 9999);

define("SITE", "ili.wab.ru");

switch($ver)
{
case 'wml':
///////////////////////////////////////////////////////
//WML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"index\" title=\"$title\"><p align=\"center\">\n";
echo "Переход на главную:<br/>\n";
echo "<a href=\"http://".SITE."\">".SITE."</a><br/>\n";
echo "<br />\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
break;

case 'html':
///////////////////////////////////////////////////////
//HTML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n";
echo "<link rel=\"shortcut icon\" href=\"$favicon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: $color; background-color: $background }\n";
echo "a:link, a:active, a:visited { text-decoration: underline; color : ".$links." }\n";
echo "div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }\n";
echo "div.form { background-color: $form_color }\n";
echo "</style></head>\n";
echo "<body><div style=\"text-align: center\">\n";
echo "Переход на главную:<br/>\n";
echo "<a href=\"http://".SITE."\">".SITE."</a><br/>\n";
echo "<br />\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
echo "</div></body></html>";
break;
}
?>