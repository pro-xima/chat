<?php
error_reporting(0);

include("config.php");
include("./includes/constants/letters");
include("./includes/".$ver."/banned");

$old_letters = 7; //DAYS

$fd = fopen("letters.dat", "r");
$clear_time = intval(fgets($fd));
fclose($fd);

if($clear_time < time())
{
$delete = mysql_query("DELETE FROM `chat_letters` WHERE `time` < '".(time() - (3600 * 24 * $old_letters))."';");

$fd = fopen("letters.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + 3600 * 24 * $old_letters));
flock($fd, LOCK_UN);
fclose($fd);
}

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$nocache = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
else
{
$nickname = mysql_result($q, 0, 'nickname');
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"".TITLE."\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'inbox':
echo INBOX.":<br />\n";
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';");
$all = mysql_result($q, 0);

if(isset($_GET['page']))
{
$page = intval($_GET['page']);
}
else
{
$page = 0;
}

if($page < 0) $page = 0;
if($page > intval($all/ONPAGE)) $page = intval($all/ONPAGE);

$limit = ($page * ONPAGE).", ".($page * ONPAGE + ONPAGE);

$q = mysql_query("SELECT `lid`, `subject`, `read` FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' ORDER BY `lid` DESC LIMIT ".$limit.";");

if(mysql_num_rows($q) == 0)
{
echo INBOX_IS_NOT."<br/>\n";
}

while($letter = mysql_fetch_array($q))
{
$lid = $letter['lid'];
$title = $letter['subject'];
$read = $letter['read'];
if($read == 0)
{
echo "[NEW] <a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}
else
{
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}
}

if($page > 0)
{
echo "<a href='letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;ver=wml&amp;page=".($page - 1)."'>".htmlspecialchars("<<<")."</a><br />\n";
}

if($all > $page * ONPAGE + ONPAGE)
{
echo "<a href='letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;ver=wml&amp;page=".($page + 1)."'>".htmlspecialchars(">>>")."</a><br />\n";
}
break;

case 'outbox':
echo OUTBOX.":<br />\n";
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."';");
$all = mysql_result($q, 0);

if(isset($_GET['page']))
{
$page = intval($_GET['page']);
}
else
{
$page = 0;
}

if($page < 0) $page = 0;
if($page > intval($all/ONPAGE)) $page = intval($all/ONPAGE);

$limit = ($page * ONPAGE).", ".($page * ONPAGE + ONPAGE);

$q = mysql_query("SELECT `lid`, `subject` FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."' ORDER BY `lid` DESC;");

if ($start > 10)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=0&amp;ver=wml\">&lt;&lt;&lt;&lt;</a><br/>";
if ($start > 0)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($start-10)."&amp;ver=wml\">&lt;&lt;&lt;</a><br/>";

if(mysql_num_rows($q) == 0)
{
echo OUTBOX_IS_NOT."<br/>\n";
}

while($letter = mysql_fetch_array($q))
{
$lid = $letter['lid'];
$title = $letter['subject'];
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}

if ($all > $start + 5)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($start + 5)."&amp;ver=wml\">&gt;&gt;&gt;</a><br/>";
if ($all - $start > 10)   print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($all - 5)."&amp;ver=wml\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'view':
$lid = intval($_GET['lid']);
$q = mysql_query("SELECT * FROM `chat_letters` WHERE `lid` = '".$lid."' AND `id` = '".$id."';");

if(mysql_num_rows($q) == 0)
{
echo LETTER_DOES_NOT_EXISTS."<br/>";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}

mysql_query("UPDATE `chat_letters` SET `read` = 1 WHERE `lid` = '".$lid."';");

$letter = mysql_fetch_array($q);
$lid = $letter['lid'];
$to = $letter['to'];
$from = $letter['from'];
$title = $letter['subject'];
$text = $letter['body'];
$date = $letter['date'];

if($to == $id)
{
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$from."';");
$nick = mysql_result($q, 0);
echo "<u>".LETTER_TITLE.":</u> $title<br/>\n";
echo "<u>".LETTER_FROM.":</u> $nick<br/>\n";
echo "<u>".LETTER_DATE.":</u> $date<br/>\n";
echo "<u>".LETTER_BODY.":</u> $text<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=send&amp;toid=$from&amp;nocache=$nocache\">Ответить</a><br/>\n";
}
else
{
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$to."';");
$nick = mysql_result($q, 0);
echo "<u>".LETTER_TITLE.":</u> $title<br/>\n";
echo "<u>".LETTER_TO.":</u> $nick<br/>\n";
echo "<u>".LETTER_DATE.":</u> $date<br/>\n";
echo "<u>".LETTER_BODY.":</u> $text<br/>\n";
}
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=delete&amp;lid=$lid&amp;nocache=$nocache\">Удалить</a><br/>\n";
break;

case 'send':
if(!isset($_POST['action']))
{

if(isset($_GET['toid']))
{
$toid = intval($_GET['toid']);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$toid."';");
$nick = mysql_result($q, 0);
}
else
{
$nick = "";
}
echo LETTER_TITLE.":<br/>\n";
echo "<input name=\"title$nocache\" maxlength=\"15\" title=\"title\"/><br/>\n";
echo LETTER_TO.":<br/>\n";
echo "<input name=\"nick$nocache\" value=\"$nick\" maxlength=\"15\" title=\"nick\"/><br/>\n";
echo LETTER_BODY.":<br/>\n";
echo "<input name=\"text$nocache\" value=\"\" maxlength=\"300\" title=\"text\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"true\" name=\"translit$nocache\">\n";
echo "<option value=\"tt\">Залоговок</option>\n";
echo "<option value=\"nt\">Кому</option>\n";
echo "<option value=\"text\">".LETTER_BODY."</option>\n";
echo "</select><br/>\n";
echo "<anchor>[Отправить]<go href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=send&amp;nocache=$nocache\" method=\"post\" sendreferer=\"true\">\n";
echo "<postfield name=\"title\" value=\"$(title$nocache)\"/>\n";
echo "<postfield name=\"nick\" value=\"$(nick$nocache)\"/>\n";
echo "<postfield name=\"text\" value=\"$(text$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"send\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$lat = array("Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$nick = htmlspecialchars(mysql_escape_string(trim($_POST['nick'])));
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));
$translit = $_POST['translit'];

if(substr_count($translit, "tt") != 0)
{
$title = str_replace($lat, $rus, $title);
}

if(substr_count($translit, "nt") != 0)
{
$nick = str_replace($lat, $rus, $nick);
}

if(substr_count($translit, "text") != 0)
{
$text = str_replace($lat, $rus, $text);
}

$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nick."';");

if(mysql_affected_rows() == 0)
{
echo USER_WAS_NOT_FOUND."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}
else
{
$user_data = mysql_fetch_array($q);
$toid = $user_data['id'];
$system = $user_data['system'];
$place = $user_data['place'];
$key = $user_data['key'];
$user_pass = $user_data['password'];
$time = $user_data['time'];
$place = $user_data['place'];
}

if(empty($title))
{
echo ERROR_TITLE_IS_EMPTY."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}

if(empty($text))
{
echo ERROR_BODY_IS_EMPTY."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}

$date = date("d-m-Y H:i:s");

$q = mysql_query("SELECT * FROM `chat_letters` WHERE `subject` = '".$title."' AND `body` = '".$text."' AND `to` = '".$toid."';");

if(mysql_num_rows($q) != 0)
{
echo ERROR_SPAM."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}

$query = mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$toid."', '".$toid."', '".$id."', '".$title."', '".$text."', '".$date."', '".time()."', 0);");
if($toid != $id)
{
$query = mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$id."', '".$toid."', '".$id."', '".$title."', '".$text."', '".$date."', '".time()."', 0);");
}

if($system == 1 && $time >= time())
{
$bot = file("bots/bots.dat");
$system_bot = trim($bot[3]);

$message = "$nick, Вам пришло новое письмо от пользователя \"".$nickname."\" с заголовком \"".$title."\".<br />\n";
$message .= "<a href=\'letters.php?id=".$toid."&amp;password=".$user_pass."&amp;mod=inbox\'>[Просмотреть]</a>\n";

mysql_query("INSERT INTO `chat".$place."` VALUES(0, '5', '".$system_bot."', '".$message."', '".$toid."', '".date("H:i:s")."', ".time().");");
}

if($query)
{
echo LETTER_SEND_SUCCESS."<br/>\n";
}
else
{
echo LETTER_SEND_ERROR."<br/>\n";
echo "<u>".mysql_error()."</u><br/>\n";
}

}
break;

case 'clear':
$q = mysql_query("DELETE FROM `chat_letters` WHERE `id` = '".$id."';");
if(mysql_affected_rows() != 0)
{
echo LETTERS_ARE_REMOVED."<br/>\n";
}
else
{
echo MAILBOX_IS_EMPTY."<br/>\n";
}
break;

case 'delete':
$lid = intval($_GET['lid']);
$q = mysql_query("DELETE FROM `chat_letters` WHERE `lid` = '".$lid."';");
if(mysql_affected_rows() != 0)
{
echo LETTER_ARE_REMOVED."<br/>\n";
}
else
{
echo LETTER_DOES_NOT_EXISTS."<br/>\n";
}
break;

default:
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' AND `read` = 0;"); 
$newto = mysql_result($q, 0);
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';"); 
$to = mysql_result($q, 0);
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."';"); 
$from = mysql_result($q, 0);

echo "Письма, которые находятся в базе данных больше недели - удаляются.<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=inbox\">".INBOX." ($newto/$to)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=outbox\">".OUTBOX." ($from)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=send\">Написать</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=clear\">Удалить все письма</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=wml\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
else
{
$nickname = mysql_result($q, 0, 'nickname');
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".TITLE."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body><div style=\"text-align: left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'inbox':
echo INBOX.":<br />\n";
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';");
$all = mysql_result($q, 0);

if(isset($_GET['start'])) $start = $_GET['start'];
else $start = 0;
if($start < 0) $start = 0;
if($start > $all) $start = 0;

$q = mysql_query("SELECT `lid`, `subject`, `read` FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' ORDER BY `lid` DESC LIMIT $start, 5;");

if ($start > 10)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;start=0&amp;ver=html\">&lt;&lt;&lt;&lt;</a><br/>";
if ($start > 0)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;start=".($start-5)."&amp;ver=html\">&lt;&lt;&lt;</a><br/>";

if(mysql_num_rows($q) == 0)
{
echo INBOX_IS_NOT."<br/>\n";
}

while($letter = mysql_fetch_array($q))
{
$lid = $letter['lid'];
$title = $letter['subject'];
$read = $letter['read'];
if($read == 0)
{
echo "[NEW] <a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}
else
{
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}
}

if ($all > $start + 5)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;start=".($start+5)."&amp;ver=html\">&gt;&gt;&gt;</a><br/>";
if ($all - $start > 10)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=inbox&amp;start=".($all-5)."&amp;ver=html\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'outbox':
echo OUTBOX.":<br />\n";
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."';");
$all = mysql_result($q, 0);

if(isset($_GET['start'])) $start = $_GET['start'];
else $start = 0;
if($start < 0) $start = 0;
if($start > $all) $start = 0;

$q = mysql_query("SELECT `lid`, `subject` FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."' ORDER BY `lid` DESC;");

if ($start > 10)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=0&amp;ver=html\">&lt;&lt;&lt;&lt;</a><br/>";
if ($start > 0)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($start-10)."&amp;ver=html\">&lt;&lt;&lt;</a><br/>";

if(mysql_num_rows($q) == 0)
{
echo OUTBOX_IS_NOT."<br/>\n";
}

while($letter = mysql_fetch_array($q))
{
$lid = $letter['lid'];
$title = $letter['subject'];
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=view&amp;lid=$lid\">$title</a><br/>\n";
}

if ($all > $start + 5)  print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($start + 5)."&amp;ver=html\">&gt;&gt;&gt;</a><br/>";
if ($all - $start > 10)   print "<a href=\"letters.php?id=$id&amp;password=$password&amp;mod=outbox&amp;start=".($all - 5)."&amp;ver=html\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'view':
$lid = intval($_GET['lid']);
$q = mysql_query("SELECT * FROM `chat_letters` WHERE `lid` = '".$lid."' AND `id` = '".$id."';");

if(mysql_num_rows($q) == 0)
{
echo LETTER_DOES_NOT_EXISTS."<br/>";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}

mysql_query("UPDATE `chat_letters` SET `read` = 1 WHERE `lid` = '".$lid."';");

$letter = mysql_fetch_array($q);
$lid = $letter['lid'];
$to = $letter['to'];
$from = $letter['from'];
$title = $letter['subject'];
$text = $letter['body'];
$date = $letter['date'];

if($to == $id)
{
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$from."';");
$nick = mysql_result($q, 0);
echo "<u>".LETTER_TITLE.":</u> $title<br/>\n";
echo "<u>".LETTER_FROM.":</u> $nick<br/>\n";
echo "<u>".LETTER_DATE.":</u> $date<br/>\n";
echo "<u>".LETTER_BODY.":</u> $text<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=send&amp;toid=$from&amp;nocache=$nocache\">Ответить</a><br/>\n";
}
else
{
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$to."';");
$nick = mysql_result($q, 0);
echo "<u>".LETTER_TITLE.":</u> $title<br/>\n";
echo "<u>".LETTER_TO.":</u> $nick<br/>\n";
echo "<u>".LETTER_DATE.":</u> $date<br/>\n";
echo "<u>".LETTER_BODY.":</u> $text<br/>\n";
}
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=delete&amp;lid=$lid&amp;nocache=$nocache\">Удалить</a><br/>\n";
break;

case 'send':
if(!isset($_POST['action']))
{

if(isset($_GET['toid']))
{
$toid = intval($_GET['toid']);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$toid."';");
$nick = mysql_result($q, 0);
}
else
{
$nick = "";
}

echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"letters.php?id=$id&amp;password=$password&amp;nocache=$nocache&amp;ver=html&amp;mod=send\">\n";
echo LETTER_TITLE.":<br/>\n";
echo "<input name=\"title\" type=\"text\" value=\"\" size=\"15\" maxlength=\"15\"/><br/>\n";
echo LETTER_TO.":<br/>\n";
echo "<input name=\"nick\" type=\"text\" value=\"$nick\" size=\"15\" maxlength=\"20\"/><br/>\n";
echo LETTER_BODY.":<br/>\n";
echo "<input name=\"text\" type=\"text\" value=\"\" size=\"15\" maxlength=\"300\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"multiple\" name=\"translit$nocache\">\n";
echo "<option value=\"name\">Название</option>\n";
echo "<option value=\"topic\">".LETTER_TITLE."</option>\n";
echo "</select><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"send\"/>";
echo "<input type=\"submit\" value=\"Отправить\"/></form></div><br/>\n";
}
else
{
$lat = array("Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "J", "j", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "Ж", "ж", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$nick = htmlspecialchars(mysql_escape_string(trim($_POST['nick'])));
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));

$translit = $_POST['translit'];

if(substr_count($translit, "tt") != 0)
{
$title = str_replace($lat, $rus, $title);
}

if(substr_count($translit, "nt") != 0)
{
$nick = str_replace($lat, $rus, $nick);
}

if(substr_count($translit, "text") != 0)
{
$text = str_replace($lat, $rus, $text);
}

$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nick."';");

if(mysql_affected_rows() == 0)
{
echo USER_WAS_NOT_FOUND."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}
else
{
$user_data = mysql_fetch_array($q);
$toid = $user_data['id'];
$system = $user_data['system'];
$place = $user_data['place'];
$key = $user_data['key'];
$user_pass = $user_data['password'];
$time = $user_data['time'];
$place = $user_data['place'];
}

if(empty($title))
{
echo ERROR_TITLE_IS_EMPTY."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}

if(empty($text))
{
echo ERROR_BODY_IS_EMPTY."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}

$date = date("d-m-Y H:i:s");

$q = mysql_query("SELECT * FROM `chat_letters` WHERE `subject` = '".$title."' AND `body` = '".$text."' AND `to` = '".$toid."';");

if(mysql_num_rows($q) != 0)
{
echo ERROR_SPAM."<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}

$query = mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$toid."', '".$toid."', '".$id."', '".$title."', '".$text."', '".$date."', '".time()."', 0);");
if($toid != $id)
{
$query = mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$id."', '".$toid."', '".$id."', '".$title."', '".$text."', '".$date."', '".time()."', 0);");
}

if($system == 1 && $time >= time())
{
$bot = file("bots/bots.dat");
$system_bot = trim($bot[3]);

$message = "$nick, Вам пришло новое письмо от пользователя \"".$nickname."\" с заголовком \"".$title."\".<br />\n";
$message .= "<a href=\'letters.php?id=".$toid."&amp;password=".$user_pass."&amp;mod=inbox\'>[Просмотреть]</a>\n";

mysql_query("INSERT INTO `chat".$place."` VALUES(0, '5', '".$system_bot."', '".$message."', '".$toid."', '".date("H:i:s")."', ".time().");");
}

if($query)
{
echo LETTER_SEND_SUCCESS."<br/>\n";
}
else
{
echo LETTER_SEND_ERROR."<br/>\n";
echo "<u>".mysql_error()."</u><br/>\n";
}

}
break;

case 'clear':
$q = mysql_query("DELETE FROM `chat_letters` WHERE `id` = '".$id."';");
if(mysql_affected_rows() != 0)
{
echo LETTERS_ARE_REMOVED."<br/>\n";
}
else
{
echo MAILBOX_IS_EMPTY."<br/>\n";
}
break;

case 'delete':
$lid = intval($_GET['lid']);
$q = mysql_query("DELETE FROM `chat_letters` WHERE `lid` = '".$lid."';");
if(mysql_affected_rows() != 0)
{
echo LETTER_ARE_REMOVED."<br/>\n";
}
else
{
echo LETTER_DOES_NOT_EXISTS."<br/>\n";
}
break;

default:
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."' AND `read` = 0;"); 
$newto = mysql_result($q, 0);
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `to` = '".$id."';"); 
$to = mysql_result($q, 0);
$q = mysql_query("SELECT COUNT(*) FROM `chat_letters` WHERE `id` = '".$id."' AND `from` = '".$id."';"); 
$from = mysql_result($q, 0);

echo "Письма, которые находятся в базе данных больше недели - удаляются.<br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=inbox\">".INBOX." ($newto/$to)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=outbox\">".OUTBOX." ($from)</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=send\">Написать</a><br/>\n";
echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=clear\">Удалить все письма</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"letters.php?id=$id&amp;password=$password&amp;ver=html\">Почта</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>