<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` >= ".time().";");
$online = mysql_result($sql, 0);

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` >= ".time()." AND `invisible` != 1;");
$in_public_rooms = mysql_result($sql, 0);

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card id=\"online\" title=\"Онлайн ($online)\"><p align=\"left\">\n";

$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` >= ".time()." AND `invisible` != 1 ORDER BY `level` DESC, `posts` DESC;");

if(mysql_num_rows($sql) == 0) 
{
echo "В чате никого нет.<br/>\n";
}
else
{
echo "Сейчас в чате:<br/>\n";
}

$c = 0;
while($users = mysql_fetch_array($sql))
{
$c++;
echo $users['nickname'];
if($c != $in_public_rooms) echo ", ";
}

echo "<br/><a href=\"rules.php?ver=wml&amp;action=registration\">Регистрация</a><br/>\n";
echo "<a href=\"index.php?ver=wml\">Назад</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` >= ".time().";");
$online = mysql_result($sql, 0);

$sql = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` >= ".time()." AND `invisible` != 1;");
$in_public_rooms = mysql_result($sql, 0);

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Онлайн ($online)</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";

$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` >= ".time()." AND `invisible` != 1 ORDER BY `level` DESC, `posts` DESC;");

if(mysql_num_rows($sql) == 0) 
{
echo "В чате никого нет.<br/>\n";
}
else
{
echo "Сейчас в чате:<br/>\n";
}

$c = 0;
while($users = mysql_fetch_array($sql))
{
$c++;
echo $users['nickname'];
if($c != $in_public_rooms) echo ", ";
}

echo "<br/><a href=\"rules.php?ver=html&amp;action=registration\">Регистрация</a><br/>\n";
echo "<a href=\"index.php?ver=html\">Назад</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</body></html>";
break;
}
?>