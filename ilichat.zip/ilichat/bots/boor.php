<?
//BOT FOR WICKED QUIZ

//GET TIME
$fd = fopen("bots/second_bot/insult.dat", "r");
if(!$fd) return;
$insult_time = intval(fgets($fd));
fclose($fd);

if($insult_time < time())
{
$sql = mysql_query("SELECT `insult` FROM `chat_insults` ORDER BY RAND() LIMIT 1;");
$message = mysql_result($sql, 0);

$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` >= ".time()." AND `place` = 3 AND `id` != 4 ORDER BY RAND() LIMIT 1;");
$loser = mysql_result($sql, 0);

$message = str_replace('[nick]', $loser, $message);

mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");

$fd = fopen("bots/second_bot/insult.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + 300)); //NEXT INSULT
flock($fd, LOCK_UN);
fclose($fd);
}
?>