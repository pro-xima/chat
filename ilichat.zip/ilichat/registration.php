<?php
list($msec, $sec) = explode(chr(32), microtime());
$headtime = $sec + $msec;

$configs = file("configs.dat");
$reg_status = $configs[0];
$computer = $configs[2];

if(isset($_POST['action']))
{
session_id("".$_POST['sid']."");
session_start();
}
else
{
session_start();
$number = rand(1000, 9999);
$_SESSION['code'] = $number;
}

error_reporting(0);

include("config.php");
include("./includes/constants/registration");
include("./includes/".$ver."/banned");

$nocache = rand(1000, 9999);
$mobile = strtok(getenv('HTTP_USER_AGENT'), "/");
$ip = getenv('REMOTE_ADDR');
$ua = mysql_escape_string(htmlspecialchars(getenv('HTTP_USER_AGENT')));

switch($ver)
{
case 'wml':
///////////////////////////////////////////////////////
//WML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";

if($reg_status == 0)
{
echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"error\" title=\"Error\"><p align=\"left\">\n";
echo "<small>Регистрация временно закрыта администратором чата.</small><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
exit();
}

if(((strpos($ua, "Opera") !== false) or (strpos($ua, "Mozilla") !== false) or (strpos($ua, "MSIE") !== false)  or (strpos($ua, "Netscape") !== false)) && $computer == 1)
{
echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"error\" title=\"Error\"><p align=\"left\">\n";
echo "<small>Регистрация с компьютера запрещена.</small><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
exit();
}

echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"registration\" title=\"".TITLE."\"><p align=\"left\">\n";
echo "<!-- Registration -->\n";
if(!isset($_POST['action']))
{
echo "Ник*:<br/>\n";
echo "<input type=\"text\" name=\"nickname\" maxlength=\"15\"/><br/>\n";
echo "Пароль*:<br/>\n";
echo "<input type=\"text\" name=\"password\" maxlength=\"20\"/><br/>\n";
echo "Реальное имя:<br/>\n";
echo "<input type=\"text\" name=\"name\" maxlength=\"15\"/><br/>\n";
echo "Пол:<br/>\n";
echo "<select name=\"sex\" value=\"0\">\n";
echo "<option value=\"0\">Мужской</option>\n";
echo "<option value=\"1\">Женский</option>\n";
echo "<option value=\"2\">Неизвестно :)</option>\n";
echo "</select><br/>\n";
echo "Дата рождения:<br/>";
echo "<input type=\"text\" name=\"day\" format=\"*N\" maxlength=\"2\" size=\"2\"/>-\n";
echo "<input type=\"text\" name=\"month\" format=\"*N\" maxlength=\"2\" size=\"2\"/>-\n";
echo "<input type=\"text\" name=\"year\" format=\"*N\" maxlength=\"4\" size=\"4\"/><br/>\n";
echo "Откуда:<br/>\n";
echo "<input type=\"text\" name=\"from\" maxlength=\"20\"/><br/>\n";
echo "Модель мобилы:<br/>\n";
echo "<input type=\"text\" name=\"mobile\" maxlength=\"20\" value=\"$mobile\"/><br/>\n";
echo "eMail:<br/>\n";
echo "<input type=\"text\" name=\"email\" maxlength=\"30\"/><br/>\n";
echo "Сайт:<br/>\n";
echo "<input type=\"text\" name=\"site\" maxlength=\"50\" value=\"http://\"/><br/>\n";
echo "О себе:<br/>\n";
echo "<input type=\"text\" name=\"about\" maxlength=\"250\"/><br/>\n";
echo "<anchor>[Регистрировать]<go href=\"registration.php?ver=wml&amp;nocache=$nocache\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname)\"/>\n";
echo "<postfield name=\"password\" value=\"$(password)\"/>\n";
echo "<postfield name=\"name\" value=\"$(name)\"/>\n";
echo "<postfield name=\"sex\" value=\"$(sex)\"/>\n";
echo "<postfield name=\"day\" value=\"$(day)\"/>\n";
echo "<postfield name=\"month\" value=\"$(month)\"/>\n";
echo "<postfield name=\"year\" value=\"$(year)\"/>\n";
echo "<postfield name=\"from\" value=\"$(from)\"/>\n";
echo "<postfield name=\"mobile\" value=\"$(mobile)\"/>\n";
echo "<postfield name=\"email\" value=\"$(email)\"/>\n";
echo "<postfield name=\"site\" value=\"$(site)\"/>\n";
echo "<postfield name=\"about\" value=\"$(about)\"/>\n";
echo "<postfield name=\"number\" value=\"$number\"/>\n";
echo "<postfield name=\"sid\" value=\"".session_id()."\"/>\n";
echo "<postfield name=\"action\" value=\"registration\"/>\n";
echo "</go></anchor><br/>\n";
echo "<a href=\"rules.php?ver=wml&amp;action=registration&amp;nocache=$nocache\">Правила</a><br/>\n";
echo "<a href=\"index.php?ver=wml&amp;nocache=$nocache\">Отмена</a><br/><br/>\n";
}
else
{
$nickname = trim(htmlspecialchars(mysql_escape_string($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
$password = trim(htmlspecialchars(mysql_escape_string($_POST['password'])));
$name = trim(htmlspecialchars(mysql_escape_string($_POST['name'])));
$name = str_replace('$', '$$', $name);
$sex = intval($_POST['sex']);
if($sex != 0 && $sex != 1) $sex = 2;
$day = substr(intval($_POST['day']), 0, 2);
$month = substr(intval($_POST['month']), 0, 2);
$year = substr(intval($_POST['year']), 0, 4);
$birthday = "$day-$month-$year";
$from = trim(htmlspecialchars(mysql_escape_string($_POST['from'])));
$from = str_replace('$', '$$', $from);
$mobile = trim(htmlspecialchars(mysql_escape_string($_POST['mobile'])));
$mobile = str_replace('$', '$$', $mobile);
$email = trim(htmlspecialchars(mysql_escape_string($_POST['email'])));
$email = str_replace('$', '$$', $email);
$site = strtolower(trim(htmlspecialchars(mysql_escape_string($_POST['site']))));
$site = str_replace('http://', '', $site);
$site = str_replace('$', '$$', $site);
$about = trim(htmlspecialchars(mysql_escape_string($_POST['about'])));
$about = str_replace('$', '$$', $about);
$number = intval($_POST['number']);

$error = "";

if($number != $_SESSION['code']) $error .= BAD_SID."<br/>\n";
if(empty($nickname)) $error .= "Не введен никнейм!<br/>\n";
if(empty($password)) $error .= "Не введен пароль!<br/>\n";
if(strlen($nickname) > 45) $error .= "Слишком длинный никнейм!<br/>\n";
if(strlen($password) > 20) $error .= "Пароль слишком длинный!<br/>\n";

                function replace_rus($str){
                $str = str_replace("а","|",$str);
                $str = str_replace("б","|",$str);
                $str = str_replace("в","|",$str);
                $str = str_replace("г","|",$str);
                $str = str_replace("д","|",$str);
                $str = str_replace("е","|",$str);
                $str = str_replace("ё","|",$str);
                $str = str_replace("ж","|",$str);
                $str = str_replace("з","|",$str);
                $str = str_replace("и","|",$str);
                $str = str_replace("й","|",$str);
                $str = str_replace("к","|",$str);
                $str = str_replace("л","|",$str);
                $str = str_replace("м","|",$str);
                $str = str_replace("н","|",$str);
                $str = str_replace("о","|",$str);
                $str = str_replace("п","|",$str);
                $str = str_replace("р","|",$str);
                $str = str_replace("с","|",$str);
                $str = str_replace("т","|",$str);
                $str = str_replace("у","|",$str);
                $str = str_replace("ф","|",$str);
                $str = str_replace("х","|",$str);
                $str = str_replace("ч","|",$str);
                $str = str_replace("ц","|",$str);
                $str = str_replace("ш","|",$str);
                $str = str_replace("щ","|",$str);
                $str = str_replace("ь","|",$str);
                $str = str_replace("ы","|",$str);
                $str = str_replace("ъ","|",$str);
                $str = str_replace("э","|",$str);
                $str = str_replace("ю","|",$str);
                $str = str_replace("я","|",$str);
                $str = str_replace("А","|",$str);
                $str = str_replace("Б","|",$str);
                $str = str_replace("В","|",$str);
                $str = str_replace("Г","|",$str);
                $str = str_replace("Д","|",$str);
                $str = str_replace("Е","|",$str);
                $str = str_replace("Ё","|",$str);
                $str = str_replace("Ж","|",$str);
                $str = str_replace("З","|",$str);
                $str = str_replace("п","|",$str);
                $str = str_replace("Й","|",$str);
                $str = str_replace("К","|",$str);
                $str = str_replace("Л","|",$str);
                $str = str_replace("М","|",$str);
                $str = str_replace("Н","|",$str);
                $str = str_replace("О","|",$str);
                $str = str_replace("П","|",$str);
                $str = str_replace("Р","|",$str);
                $str = str_replace("С","|",$str);
                $str = str_replace("Т","|",$str);
                $str = str_replace("У","|",$str);
                $str = str_replace("Ф","|",$str);
                $str = str_replace("Х","|",$str);
                $str = str_replace("Ч","|",$str);
                $str = str_replace("Ц","|",$str);
                $str = str_replace("Ш","|",$str);
                $str = str_replace("Щ","|",$str);
                $str = str_replace("Ь","|",$str);
                $str = str_replace("Ы","|",$str);
                $str = str_replace("Ъ","|",$str);
                $str = str_replace("Э","|",$str);
                $str = str_replace("Ю","|",$str);
                $str = str_replace("Я","|",$str);
                return $str;
                }


$bak = replace_rus($nickname);

if((preg_match("/[^A-Za-z1-9\@\*\(\)\?\!\-\~\_\[\]\=]+/",$nickname))&&(!preg_match("!^[@\\*\\)\\(\\?\\!\\-_\\]\\|\\[=~]+$!i",$bak))) $error .= "Никнейм содержит недопустимые символы!<br/>\n";

if(preg_match("/[^0-9a-zA-Z_]+/", $password)) $error .= "В пароле содержаться недопустимые символы!<br/>\n";
if(!empty($email))
{
	if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $email)) $error .= "Введите e-mail в формате mailbox@host.com!<br/>\n";
}

	if(!empty($error))
	{
	echo $error;
	echo "<a href=\"registration.php?ver=wml&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
	echo "</p></card></wml>";
	exit();
	}

$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `nickname` = '".$nickname."';");

	if(mysql_num_rows($q) != 0)
	{
	echo "К сожалению ник <b>".$nickname."</b> уже занят. Попробуйте зарегистрировать другой ник.<br/>\n";
	echo "<a href=\"registration.php?ver=wml&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
	echo "</p></card></wml>";
	exit();
	}

$q = mysql_query("SELECT * FROM `chat_banned_nicknames` WHERE `nickname` = '".$nickname."';");

	if(mysql_affected_rows() != 0)
	{
	echo "Никнейм <b>".$nickname."</b> забанен!<br/>\n";
	echo "<a href=\"registration.php?ver=wml&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
	echo "</p></card></wml>";
	exit();
	}

$registration = mysql_query("INSERT INTO `chat_users` SET `nickname` = '".$nickname."', `password` = '".$password."', `status` = 'Новичок', `name` = '".$name."', `sex` = ".$sex.", `birthday` = '".$birthday."', `from` = '".$from."', `mobile` = '".$mobile."', `email` = '".$email."', `site` = '".$site."', `about` = '".$about."', `ip` = '".$ip."', `ua` = '".$ua."', `time` = ".time().", `key` = '', `regdate` = '".date('d-m-y')."';");

	if($registration)
	{
	$id = mysql_insert_id();
	mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$id."', '".$id."', 1, '".LETTER_TITLE."', '".LETTER_BODY."', '".date("d-m-Y")."', '".time()."', 0);");
	echo REGISTRATION_SUCCESS."<br/>\n";
	echo "Ник: <u>".$nickname."</u><br/>\n";
	echo "Пароль: <u>".$password."</u><br/>\n";
	echo "<a href=\"menu.php?ver=wml&amp;id=$id&amp;password=$password&amp;nocache=$nocache\">[Продолжить]</a><br/><br/>\n";
	echo "<a href=\"index.php?ver=wml&amp;nocache=$nocache\">Выход</a><br/><br/>\n";
	}
	else
	{
	echo REGISTRATION_ERROR."<br/>\n";
	echo mysql_error()."<br/>\n";
	}
session_destroy();
}
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
break;

case 'html':
///////////////////////////////////////////////////////
//HTML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n";
echo "<link rel=\"shortcut icon\" href=\"$favicon\" /><title>".TITLE."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: $color; background-color: $background }\n";
echo "a:link, a:active, a:visited, a:hover { text-decoration: underline; color : $links }\n";
echo "div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }\n";
echo "div.form { background-color: $form_color }\n";
echo "</style></head>\n";
echo "<body><div style=\"text-align: left\">\n";

if($reg_status == 0)
{
echo "Регистрация временно закрыта администратором чата.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
echo "</div></body></html>";
exit();
}

if(((strpos($ua, "Opera") !== false) or (strpos($ua, "Mozilla") !== false) or (strpos($ua, "MSIE") !== false)  or (strpos($ua, "Netscape") !== false)) && $computer == 1)
{
echo "Регистрация с компьютера запрещена.<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
echo "</div></body></html>";
exit();
}

echo "<!-- Registration -->\n";
if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form action=\"registration.php?ver=html&amp;nocache=$nocache\" method=\"post\">\n";
echo "Ник*:<br/>\n";
echo "<input type=\"text\" name=\"nickname\" maxlength=\"15\"/><br/>\n";
echo "Пароль*:<br/>\n";
echo "<input type=\"text\" name=\"password\" maxlength=\"20\"/><br/>\n";
echo "Реальное имя:<br/>\n";
echo "<input type=\"text\" name=\"name\" maxlength=\"15\"/><br/>\n";
echo "Пол:<br/>\n";
echo "<select name=\"sex\">\n";
echo "<option value=\"0\" selected=\"selected\">Мужской</option>\n";
echo "<option value=\"1\">Женский</option>\n";
echo "<option value=\"2\">Неизвестно :)</option>\n";
echo "</select><br/>\n";
echo "Дата рождения:<br/>";
echo "<input type=\"text\" name=\"day\" format=\"*N\" maxlength=\"2\" size=\"2\"/>-\n";
echo "<input type=\"text\" name=\"month\" format=\"*N\" maxlength=\"2\" size=\"2\"/>-\n";
echo "<input type=\"text\" name=\"year\" format=\"*N\" maxlength=\"4\" size=\"4\"/><br/>\n";
echo "Откуда:<br/>\n";
echo "<input type=\"text\" name=\"from\" maxlength=\"20\"/><br/>\n";
echo "Модель мобилы:<br/>\n";
echo "<input type=\"text\" name=\"mobile\" maxlength=\"20\" value=\"$mobile\"/><br/>\n";
echo "eMail:<br/>\n";
echo "<input type=\"text\" name=\"email\" maxlength=\"30\"/><br/>\n";
echo "Сайт:<br/>\n";
echo "<input type=\"text\" name=\"site\" maxlength=\"50\" value=\"http://\"/><br/>\n";
echo "О себе:<br/>\n";
echo "<input type=\"text\" name=\"about\" maxlength=\"250\"/><br/>\n";
echo "<input type=\"hidden\" name=\"number\" value=\"$number\" />\n";
echo "<input type=\"hidden\" name=\"sid\" value=\"".session_id()."\" />\n";
echo "<input type=\"hidden\" name=\"action\" value=\"registration\" />\n";
echo "<input type=\"submit\" value=\"Регистрировать\" /></form></div>\n";
echo "<a href=\"rules.php?ver=html&amp;action=registration&amp;nocache=$nocache\">Правила</a><br/>\n";
echo "<a href=\"index.php?ver=html&amp;nocache=$nocache\">Отмена</a><br/><br/>\n";
}
else
{
$nickname = trim(htmlspecialchars(mysql_escape_string($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
$password = trim(htmlspecialchars(mysql_escape_string($_POST['password'])));
$name = trim(htmlspecialchars(mysql_escape_string($_POST['name'])));
$name = str_replace('$', '$$', $name);
$sex = intval($_POST['sex']);
if($sex != 0 && $sex != 1) $sex = 2;
$day = substr(intval($_POST['day']), 0, 2);
$month = substr(intval($_POST['month']), 0, 2);
$year = substr(intval($_POST['year']), 0, 4);
$birthday = "$day-$month-$year";
$from = trim(htmlspecialchars(mysql_escape_string($_POST['from'])));
$from = str_replace('$', '$$', $from);
$mobile = trim(htmlspecialchars(mysql_escape_string($_POST['mobile'])));
$mobile = str_replace('$', '$$', $mobile);
$email = trim(htmlspecialchars(mysql_escape_string($_POST['email'])));
$email = str_replace('$', '$$', $email);
$site = strtolower(trim(htmlspecialchars(mysql_escape_string($_POST['site']))));
$site = str_replace('http://', '', $site);
$site = str_replace('$', '$$', $site);
$about = trim(htmlspecialchars(mysql_escape_string($_POST['about'])));
$about = str_replace('$', '$$', $about);
$number = intval($_POST['number']);

$error = "";

if($number != $_SESSION['code']) $error .= BAD_SID."<br/>\n";
if(empty($nickname)) $error .= "Не введен никнейм!<br/>\n";
if(empty($password)) $error .= "Не введен пароль!<br/>\n";
if(strlen($nickname) > 45) $error .= "Слишком длинный никнейм!<br/>\n";
if(strlen($password) > 20) $error .= "Пароль слишком длинный!<br/>\n";

                function replace_rus($str){
                $str = str_replace("а","|",$str);
                $str = str_replace("б","|",$str);
                $str = str_replace("в","|",$str);
                $str = str_replace("г","|",$str);
                $str = str_replace("д","|",$str);
                $str = str_replace("е","|",$str);
                $str = str_replace("ё","|",$str);
                $str = str_replace("ж","|",$str);
                $str = str_replace("з","|",$str);
                $str = str_replace("и","|",$str);
                $str = str_replace("й","|",$str);
                $str = str_replace("к","|",$str);
                $str = str_replace("л","|",$str);
                $str = str_replace("м","|",$str);
                $str = str_replace("н","|",$str);
                $str = str_replace("о","|",$str);
                $str = str_replace("п","|",$str);
                $str = str_replace("р","|",$str);
                $str = str_replace("с","|",$str);
                $str = str_replace("т","|",$str);
                $str = str_replace("у","|",$str);
                $str = str_replace("ф","|",$str);
                $str = str_replace("х","|",$str);
                $str = str_replace("ч","|",$str);
                $str = str_replace("ц","|",$str);
                $str = str_replace("ш","|",$str);
                $str = str_replace("щ","|",$str);
                $str = str_replace("ь","|",$str);
                $str = str_replace("ы","|",$str);
                $str = str_replace("ъ","|",$str);
                $str = str_replace("э","|",$str);
                $str = str_replace("ю","|",$str);
                $str = str_replace("я","|",$str);
                $str = str_replace("А","|",$str);
                $str = str_replace("Б","|",$str);
                $str = str_replace("В","|",$str);
                $str = str_replace("Г","|",$str);
                $str = str_replace("Д","|",$str);
                $str = str_replace("Е","|",$str);
                $str = str_replace("Ё","|",$str);
                $str = str_replace("Ж","|",$str);
                $str = str_replace("З","|",$str);
                $str = str_replace("п","|",$str);
                $str = str_replace("Й","|",$str);
                $str = str_replace("К","|",$str);
                $str = str_replace("Л","|",$str);
                $str = str_replace("М","|",$str);
                $str = str_replace("Н","|",$str);
                $str = str_replace("О","|",$str);
                $str = str_replace("П","|",$str);
                $str = str_replace("Р","|",$str);
                $str = str_replace("С","|",$str);
                $str = str_replace("Т","|",$str);
                $str = str_replace("У","|",$str);
                $str = str_replace("Ф","|",$str);
                $str = str_replace("Х","|",$str);
                $str = str_replace("Ч","|",$str);
                $str = str_replace("Ц","|",$str);
                $str = str_replace("Ш","|",$str);
                $str = str_replace("Щ","|",$str);
                $str = str_replace("Ь","|",$str);
                $str = str_replace("Ы","|",$str);
                $str = str_replace("Ъ","|",$str);
                $str = str_replace("Э","|",$str);
                $str = str_replace("Ю","|",$str);
                $str = str_replace("Я","|",$str);
                return $str;
                }


$bak = replace_rus($nickname);

if((preg_match("/[^A-Za-z1-9\@\*\(\)\?\!\-\~\_\[\]\=]+/",$nickname))&&(!preg_match("!^[@\\*\\)\\(\\?\\!\\-_\\]\\|\\[=~]+$!i",$bak))) $error .= "Никнейм содержит недопустимые символы!<br/>\n";

if(preg_match("/[^0-9a-zA-Z_]+/",$password)) $error .= "В пароле содержаться недопустимые символы!<br/>\n";
if(!empty($email))
{
	if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $email)) $error .= "Введите e-mail в формате mailbox@host.com!<br/>\n";
}

	if(!empty($error))
	{
	echo $error;
	echo "<a href=\"registration.php?ver=html&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
	echo "</div></body></html>";
	exit();
	}

$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `nickname` = '".$nickname."';");

	if(mysql_num_rows($q) != 0)
	{
	echo "К сожалению ник <b>".$nickname."</b> уже занят. Попробуйте зарегистрировать другой ник.<br/>\n";
	echo "<a href=\"registration.php?ver=html&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
	echo "</div></body></html>";
	exit();
	}

$q = mysql_query("SELECT * FROM `chat_banned_nicknames` WHERE `nickname` = '".$nickname."';");

	if(mysql_affected_rows() != 0)
	{
	echo "Никнейм <b>".$nickname."</b> забанен!<br/>\n";
	echo "<a href=\"registration.php?ver=html&amp;nocache=$nocache\">Назад</a><br/><br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
	echo "</div></body></html>";
	exit();
	}

$registration = mysql_query("INSERT INTO `chat_users` SET `nickname` = '".$nickname."', `password` = '".$password."', `status` = 'Новичок', `name` = '".$name."', `sex` = ".$sex.", `birthday` = '".$birthday."', `from` = '".$from."', `mobile` = '".$mobile."', `email` = '".$email."', `site` = '".$site."', `about` = '".$about."', `ip` = '".$ip."', `ua` = '".$ua."', `time` = ".time().", `key` = '', `regdate` = '".date('d-m-y')."';");

	if($registration)
	{
	$id = mysql_insert_id();
	mysql_query("INSERT INTO `chat_letters` VALUES(0, '".$id."', '".$id."', 1, '".LETTER_TITLE."', '".LETTER_BODY."', '".date("d-m-Y")."', '".time()."', 0);");
	echo REGISTRATION_SUCCESS."<br/>\n";
	echo "Ник: <u>".$nickname."</u><br/>\n";
	echo "Пароль: <u>".$password."</u><br/>\n";
	echo "<a href=\"menu.php?ver=html&amp;id=$id&amp;password=$password&amp;nocache=$nocache\">[Продолжить]</a><br/><br/>\n";
	echo "<a href=\"index.php?ver=html&amp;nocache=$nocache\">Выход</a><br/><br/>\n";
	}
	else
	{
	echo REGISTRATION_ERROR."<br/>\n";
	echo mysql_error()."<br/>\n";
	}
session_destroy();
}
echo "</div></body></html>";
break;
}
?>