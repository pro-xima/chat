<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"FAQ\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'govenment':
echo "<b>Администраторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 4 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($admin = mysql_fetch_array($q))
{
echo $admin['nickname']." (".$admin['posts'].")<br/>\n";
}

echo "<b>Супер-Модераторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 3 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($smoder = mysql_fetch_array($q))
{
echo $smoder['nickname']." (".$smoder['posts'].")<br/>\n";
}

echo "<b>Модераторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 2 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($moder = mysql_fetch_array($q))
{
echo $moder['nickname']." (".$moder['posts'].")<br/>\n";
}

echo "<b>V.I.P.:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 1 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($vip = mysql_fetch_array($q))
{
echo $vip['nickname']." (".$vip['posts'].")<br/>\n";
}
break;

case 'status':
echo "<b>Уровни пользователей:</b><br/>\n";
echo "<u>Новичок</u> - самый первый статус, присваивается сразу при регистрации.<br/>\n";
echo "Новички не могут пользоваться функцией \"приват\" пока не наберут хотя бы 100 постов.<br/>\n";
echo "<u>Пользователь</u> - этот статус присваивается, когда Вы набираете более 500 постов.<br/>\n";
echo "<u>Продвинутый</u> - этот статус присваивается, когда Вы набираете более 1000 постов.<br/>\n";
echo "<u>Чаттер</u> - этот статус присваивается, когда Вы набираете более 3000 постов.<br/>\n";
echo "<u>Тусовщик</u> - этот статус присваивается, когда Вы набираете более 5000 постов.<br/>\n";
echo "<u>Настоящий чатланин</u> - этот статус присваивается, когда Вы набираете более 10000 постов.<br/>\n";
echo "При наборе 7000 постов участник чата имеет право попросить администрацию о присвоении личного статуса.<br/>\n";
break;


case 'bots':
$bots = file("bots/bots.dat");
if(!empty($bots[0]) && !empty($bots[1]) && !empty($bots[2]) && !empty($bots[3]))
{
$bots[0] = trim($bots[0]);
$bots[1] = trim($bots[1]);
$bots[2] = trim($bots[2]);
$bots[3] = trim($bots[3]);
echo "В чате есть несколько ботов - программ, которые выполняют заложенные в них действия.<br/>\n";
echo "<b>".$bots[0]."</b> задает вопросы в \"Викторине\". Также принимает ответы и дает подсказки.<br/>\n";
echo "Еще этот бот может повторить вопрос, узнать о статусе участника чата в Викторине или сказать сколько времени осталось до объявления ответа, если ему дать специальную команду.<br/>\n";
echo "<b>".$bots[2]."</b> тоже задает вопросы, но в \"Злой викторине\".<br/>\n";
echo "Данный бот отличается от обычного тем, что он оскорбляет участников чата. Если вы хотите узнать, кто больше знает матерных слов, то вам туда :)<br/>\n";
echo "<b>".$bots[1]."</b> рассказывает шутки и анекдоты в чате. Пользователь по своему усмотрению может включать/отключать показ сообщений от этого бота из настроек.<br/>\n";
echo "<b>".$bots[3]."</b> делает специальные оповещения. Например, о присвоении статуса Модератора какому-нибудь участнику чата или о несакционированном доступе к Вашему нику.<br/>\n";
echo $bots[3]." также оповещает пользователя о получении нового письма, если он находится в чате. Отключить это можно в \"Настройках\".<br/>\n";
echo "Писать на ники ботов бесполезно. Вы не получите ответа.<br/><br/>\n";
echo "Команды для ботов \"Викторины\":<br/>\n";
echo "<u>stats Ник_пользователя</u> - показать статистику пользователя в \"Викторине\".<br/>\n";
echo "<u>!question</u> или <u>!вопрос</u> - повторить вопрос.<br/>\n";
if($level == 4) echo "<u>fas Ник_пользователя</u> - напасть на пользователя.<br/>\n";
}
else
{
echo "Поврежден конфигурационный файл. Корректный просмотр страницы невозможен.<br/>\n";
}
break;

case 'translit':
echo "Правила транслита в чате:<br/><br/>
А a - A a<br/>
Б б - B b<br/>
В в - V v<br/>
Г г - G g<br/>
Д д - D d<br/>
Е е - E e<br/>
Ё ё - YO yo<br/>
Ж - J j<br/>
З - Z z<br/>
И - I i<br/>
Й - Y y<br/>
К - K k<br/>
Л - L l<br/>
М - M m<br/>
Н - N n<br/>
О - O o<br/>
П - P p<br/>
Р - R r<br/>
С - S s<br/>
Т - T t<br/>
У - U u<br/>
Ф - F f<br/>
Х - H h<br/>
Ц - C c<br/>
Ч - CH ch<br/>
Ш - W w<br/>
Щ - SC sc<br/>
Ъ - \"\" \"<br/>
Ы - X x<br/>
Ь - '' '<br/>
Э - YE ye<br/>
Ю - YU yu<br/>
Я - YA ya<br/>\n";
break;

case 'smiles':
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=0&amp;ver=wml\">1-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 10)."&amp;ver=wml\">2-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 20)."&amp;ver=wml\">3-я страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 30)."&amp;ver=wml\">4-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 40)."&amp;ver=wml\">5-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 50)."&amp;ver=wml\">6-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 60)."&amp;ver=wml\">7-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 70)."&amp;ver=wml\">8-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 80)."&amp;ver=wml\">9-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 90)."&amp;ver=wml\">10-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 100)."&amp;ver=wml\">11-ая страница</a><br/>";
/*
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 110)."&amp;ver=wml\">12-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 120)."&amp;ver=wml\">13-ая страница</a><br/>";
*/
break;

case 'showsmiles':
echo "Смайлы:<br/>";
$smiles = array();

$smiles[] = "<img src=\"smiles/001.gif\" alt=\".smile.\"/><br/>.smile.<br/>";
$smiles[] = "<img src=\"smiles/002.gif\" alt=\".oops.\"/><br/>.oops.<br/>";
$smiles[] = "<img src=\"smiles/003.gif\" alt=\".xexe.\"/><br/>.xexe.<br/>";
$smiles[] = "<img src=\"smiles/004.gif\" alt=\".grief.\"/><br/>.grief.<br/>";
$smiles[] = "<img src=\"smiles/005.gif\" alt=\".cool.\"/><br/>.cool.<br/>";
$smiles[] = "<img src=\"smiles/006.gif\" alt=\".lol.\"/><br/>.lol.<br/>";
$smiles[] = "<img src=\"smiles/007.gif\" alt=\".be.\"/><br/>.be.<br/>";
$smiles[] = "<img src=\"smiles/008.gif\" alt=\".unsure.\"/><br/>.unsure.<br/>";
$smiles[] = "<img src=\"smiles/009.gif\" alt=\".ok.\"/><br/>.ok.<br/>";
$smiles[] = "<img src=\"smiles/010.gif\" alt=\".fuck.\"/><br/>.fuck.<br/>";
$smiles[] = "<img src=\"smiles/011.gif\" alt=\".inlove.\"/><br/>.inlove.<br/>";
$smiles[] = "<img src=\"smiles/012.gif\" alt=\".love.\"/><br/>.love.<br/>";
$smiles[] = "<img src=\"smiles/013.gif\" alt=\".lips.\"/><br/>.lips.<br/>";
$smiles[] = "<img src=\"smiles/014.gif\" alt=\".love2.\"/><br/>.love2.<br/>";
$smiles[] = "<img src=\"smiles/015.gif\" alt=\".fanat.\"/><br/>.fanat.<br/>";
$smiles[] = "<img src=\"smiles/016.gif\" alt=\".fanat2.\"/><br/>.fanat2.<br/>";
$smiles[] = "<img src=\"smiles/017.gif\" alt=\".fanats.\"/><br/>.fanats.<br/>";
$smiles[] = "<img src=\"smiles/018.gif\" alt=\".bublegum.\"/><br/>.bublegum.<br/>";
$smiles[] = "<img src=\"smiles/019.gif\" alt=\".joker.\"/><br/>.joker.<br/>";
$smiles[] = "<img src=\"smiles/020.gif\" alt=\".music.\"/><br/>.music.<br/>";
$smiles[] = "<img src=\"smiles/021.gif\" alt=\".no.\"/><br/>.no.<br/>";
$smiles[] = "<img src=\"smiles/022.gif\" alt=\".spider.\"/><br/>.spider.<br/>";
$smiles[] = "<img src=\"smiles/023.gif\" alt=\".strong.\"/><br/>.strong.<br/>";
$smiles[] = "<img src=\"smiles/024.gif\" alt=\".strong2.\"/><br/>.strong2.<br/>";
$smiles[] = "<img src=\"smiles/025.gif\" alt=\".welcome.\"/><br/>.welcome.<br/>";
$smiles[] = "<img src=\"smiles/026.gif\" alt=\".wizard.\"/><br/>.wizard.<br/>";
$smiles[] = "<img src=\"smiles/027.gif\" alt=\".zzz.\"/><br/>.zzz.<br/>";
$smiles[] = "<img src=\"smiles/028.gif\" alt=\".happy.\"/><br/>.happy.<br/>";
$smiles[] = "<img src=\"smiles/029.gif\" alt=\".deadmoroz.\"/><br/>.deadmoroz.<br/>";
$smiles[] = "<img src=\"smiles/030.gif\" alt=\".santa.\"/><br/>.santa.<br/>";
$smiles[] = "<img src=\"smiles/031.gif\" alt=\".santa2.\"/><br/>.santa2.<br/>";
$smiles[] = "<img src=\"smiles/032.gif\" alt=\".bebe.\"/><br/>.bebe.<br/>";
$smiles[] = "<img src=\"smiles/033.gif\" alt=\".newyear.\"/><br/>.newyear.<br/>";
$smiles[] = "<img src=\"smiles/034.gif\" alt=\".guns.\"/><br/>.guns.<br/>";
$smiles[] = "<img src=\"smiles/035.gif\" alt=\".guns2.\"/><br/>.guns2.<br/>";
$smiles[] = "<img src=\"smiles/036.gif\" alt=\".jason.\"/><br/>.jason.<br/>";
$smiles[] = "<img src=\"smiles/037.gif\" alt=\".dead.\"/><br/>.dead.<br/>";
$smiles[] = "<img src=\"smiles/038.gif\" alt=\".guns3.\"/><br/>.guns3.<br/>";
$smiles[] = "<img src=\"smiles/039.gif\" alt=\".terrors.\"/><br/>.terrors.<br/>";
$smiles[] = "<img src=\"smiles/040.gif\" alt=\".roulette.\"/><br/>.roulette.<br/>";
$smiles[] = "<img src=\"smiles/041.gif\" alt=\".suicid.\"/><br/>.suicid.<br/>";
$smiles[] = "<img src=\"smiles/042.gif\" alt=\".suicid2.\"/><br/>.suicid2.<br/>";
$smiles[] = "<img src=\"smiles/043.gif\" alt=\".noonchaks.\"/><br/>.noonchaks.<br/>";
$smiles[] = "<img src=\"smiles/044.gif\" alt=\".paladin.\"/><br/>.paladin.<br/>";
$smiles[] = "<img src=\"smiles/045.gif\" alt=\".barbarian.\"/><br/>.barbarian.<br/>";
$smiles[] = "<img src=\"smiles/046.gif\" alt=\".xex.\"/><br/>.xex.<br/>";
$smiles[] = "<img src=\"smiles/047.gif\" alt=\".nono.\"/><br/>.nono.<br/>";
$smiles[] = "<img src=\"smiles/048.gif\" alt=\".ooo.\"/><br/>.ooo.<br/>";
$smiles[] = "<img src=\"smiles/049.gif\" alt=\".stop.\"/><br/>.stop.<br/>";
$smiles[] = "<img src=\"smiles/050.gif\" alt=\".suicid3.\"/><br/>.suicid3.<br/>";
$smiles[] = "<img src=\"smiles/051.gif\" alt=\".itshe.\"/><br/>.itshe.<br/>";
$smiles[] = "<img src=\"smiles/052.gif\" alt=\".victory.\"/><br/>.victory.<br/>";
$smiles[] = "<img src=\"smiles/053.gif\" alt=\".yahoo.\"/><br/>.yahoo.<br/>";
$smiles[] = "<img src=\"smiles/054.gif\" alt=\".cry.\"/><br/>.cry.<br/>";
$smiles[] = "<img src=\"smiles/055.gif\" alt=\".bebe2.\"/><br/>.bebe2.<br/>";
$smiles[] = "<img src=\"smiles/056.gif\" alt=\".beee.\"/><br/>.beee.<br/>";
$smiles[] = "<img src=\"smiles/057.gif\" alt=\".yes.\"/><br/>.yes.<br/>";
$smiles[] = "<img src=\"smiles/058.gif\" alt=\".hi.\"/><br/>.hi.<br/>";
$smiles[] = "<img src=\"smiles/059.gif\" alt=\".search.\"/><br/>.search.<br/>";
$smiles[] = "<img src=\"smiles/060.gif\" alt=\".alcans.\"/><br/>.alcans.<br/>";
$smiles[] = "<img src=\"smiles/061.gif\" alt=\".trans.\"/><br/>.trans.<br/>";
$smiles[] = "<img src=\"smiles/062.gif\" alt=\".superman.\"/><br/>.superman.<br/>";
$smiles[] = "<img src=\"smiles/063.gif\" alt=\".death.\"/><br/>.death.<br/>";
$smiles[] = "<img src=\"smiles/064.gif\" alt=\".censored.\"/><br/>.censored.<br/>";
$smiles[] = "<img src=\"smiles/065.gif\" alt=\".unkind.\"/><br/>.unkind.<br/>";
$smiles[] = "<img src=\"smiles/066.gif\" alt=\".kong.\"/><br/>.kong.<br/>";
$smiles[] = "<img src=\"smiles/067.gif\" alt=\".pleased.\"/><br/>.pleased.<br/>";
$smiles[] = "<img src=\"smiles/068.gif\" alt=\".rain.\"/><br/>.rain.<br/>";
$smiles[] = "<img src=\"smiles/069.gif\" alt=\".bebe3.\"/><br/>.bebe3.<br/>";
$smiles[] = "<img src=\"smiles/070.gif\" alt=\".friends.\"/><br/>.friends.<br/>";
$smiles[] = "<img src=\"smiles/071.gif\" alt=\".girl.\"/><br/>.girl.<br/>";
$smiles[] = "<img src=\"smiles/072.gif\" alt=\".fool.\"/><br/>.fool.<br/>";
$smiles[] = "<img src=\"smiles/073.gif\" alt=\".photo.\"/><br/>.photo.<br/>";
$smiles[] = "<img src=\"smiles/074.gif\" alt=\".hm.\"/><br/>.hm.<br/>";
$smiles[] = "<img src=\"smiles/075.gif\" alt=\".unnormal.\"/><br/>.unnormal.<br/>";
$smiles[] = "<img src=\"smiles/076.gif\" alt=\".idea.\"/><br/>.idea.<br/>";
$smiles[] = "<img src=\"smiles/077.gif\" alt=\".deadman.\"/><br/>.deadman.<br/>";
$smiles[] = "<img src=\"smiles/078.gif\" alt=\".king.\"/><br/>.king.<br/>";
$smiles[] = "<img src=\"smiles/079.gif\" alt=\".idiot.\"/><br/>.idiot.<br/>";
$smiles[] = "<img src=\"smiles/080.gif\" alt=\".beer.\"/><br/>.beer.<br/>";
$smiles[] = "<img src=\"smiles/081.gif\" alt=\".kuku.\"/><br/>.kuku.<br/>";
$smiles[] = "<img src=\"smiles/082.gif\" alt=\".smoke.\"/><br/>.smoke.<br/>";
$smiles[] = "<img src=\"smiles/083.gif\" alt=\".cool2.\"/><br/>.cool2.<br/>";
$smiles[] = "<img src=\"smiles/084.gif\" alt=\".ok2.\"/><br/>.ok2.<br/>";
$smiles[] = "<img src=\"smiles/085.gif\" alt=\".clapping.\"/><br/>.clapping.<br/>";
$smiles[] = "<img src=\"smiles/086.gif\" alt=\".heat.\"/><br/>.heat.<br/>";
$smiles[] = "<img src=\"smiles/087.gif\" alt=\".mad.\"/><br/>.mad.<br/>";
$smiles[] = "<img src=\"smiles/088.gif\" alt=\".postal.\"/><br/>.postal.<br/>";
$smiles[] = "<img src=\"smiles/089.gif\" alt=\".child.\"/><br/>.child.<br/>";
$smiles[] = "<img src=\"smiles/090.gif\" alt=\".mp3.\"/><br/>.mp3.<br/>";
$smiles[] = "<img src=\"smiles/091.gif\" alt=\".narik.\"/><br/>.narik.<br/>";
$smiles[] = "<img src=\"smiles/092.gif\" alt=\".blabla.\"/><br/>.blabla.<br/>";
$smiles[] = "<img src=\"smiles/093.gif\" alt=\".hi2.\"/><br/>.hi2.<br/>";
$smiles[] = "<img src=\"smiles/094.gif\" alt=\".ok3.\"/><br/>.ok3.<br/>";
$smiles[] = "<img src=\"smiles/095.gif\" alt=\".ok4.\"/><br/>.ok4.<br/>";
$smiles[] = "<img src=\"smiles/096.gif\" alt=\".punk.\"/><br/>.punk.<br/>";
$smiles[] = "<img src=\"smiles/097.gif\" alt=\".thanks.\"/><br/>.thanks.<br/>";
$smiles[] = "<img src=\"smiles/098.gif\" alt=\".bad.\"/><br/>.bad.<br/>";
$smiles[] = "<img src=\"smiles/099.gif\" alt=\".popcorn.\"/><br/>.popcorn.<br/>";
$smiles[] = "<img src=\"smiles/100.gif\" alt=\".preved.\"/><br/>.preved.<br/>";
$smiles[] = "<img src=\"smiles/101.gif\" alt=\".blush.\"/><br/>.blush.<br/>";
$smiles[] = "<img src=\"smiles/102.gif\" alt=\".party.\"/><br/>.party.<br/>";
$smiles[] = "<img src=\"smiles/103.gif\" alt=\".lol2.\"/><br/>.lol2.<br/>";
$smiles[] = "<img src=\"smiles/104.gif\" alt=\".grief2.\"/><br/>.grief2.<br/>";
$smiles[] = "<img src=\"smiles/105.gif\" alt=\".bugaga.\"/><br/>.bugaga.<br/>";
$smiles[] = "<img src=\"smiles/106.gif\" alt=\".smile2.\"/><br/>.smile2.<br/>";
$smiles[] = "<img src=\"smiles/107.gif\" alt=\".smoke2.\"/><br/>.smoke2.<br/>";
$smiles[] = "<img src=\"smiles/108.gif\" alt=\".punish.\"/><br/>.punish.<br/>";
$smiles[] = "<img src=\"smiles/109.gif\" alt=\".pcix.\"/><br/>.pcix.<br/>";
$smiles[] = "<img src=\"smiles/110.gif\" alt=\".pcix2.\"/><br/>.pcix2.<br/>";

$start = $_GET['start'];
$all = count($smiles);
$count = $all;
if(empty($start)) $start=0;
$start = intval($start);
if($start < 0)
$start=0;
if($count > $start + 10) $count = $start + 10;
for($i = $start;$i < $count;$i++)
{
print $smiles["$i"];
}
if($start!=0)
{
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start-10)."&amp;ver=wml\">".htmlspecialchars("<<<")."</a><br/>";
}
if($all > $start + 10)
{
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start+10)."&amp;ver=wml\">".htmlspecialchars(">>>")."</a><br/>";
}
break;

case 'photo':
echo "В WML-версии Вы можете загрузить фотографию только по URL, то есть по её адресу.<br />\n";
echo "В HTML также доступна загрузка через HTML-форму (не все телефоны её поддерживают).<br />\n";
echo "Вес фотографии не должен превышать 500Kb, должен быть в одном из трех форматов: GIF, PNG или JPEG.<br />\n";
echo "Размер не больше 800x600.<br />\n";
break;

default:
if($level == 3) echo "<a href=\"rules/smoder_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила С-Модеров</a><br/>\n";
if($level == 2) echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила Модеров</a><br/>\n";
if($level == 1) echo "<a href=\"rules/vip_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила VIP</a><br/>\n";
echo "<a href=\"rules/user_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила чата</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=govenment\">Администрация и Модераторы</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml\">Статистика</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=status\">Статусы</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=bots\">Боты</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=photo\">Фотография</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=smiles\">Смайлы</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=translit\">Транслит</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=wml\">FAQ</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>FAQ</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'govenment':
echo "<b>Администраторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 4 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($admin = mysql_fetch_array($q))
{
echo $admin['nickname']." (".$admin['posts'].")<br/>\n";
}

echo "<b>Супер-Модераторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 3 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($smoder = mysql_fetch_array($q))
{
echo $smoder['nickname']." (".$smoder['posts'].")<br/>\n";
}

echo "<b>Модераторы:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 2 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($moder = mysql_fetch_array($q))
{
echo $moder['nickname']." (".$moder['posts'].")<br/>\n";
}

echo "<b>V.I.P.:</b><br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` WHERE `level` = 1 AND `hidden` = 0 ORDER BY `posts` DESC;");
while($vip = mysql_fetch_array($q))
{
echo $vip['nickname']." (".$vip['posts'].")<br/>\n";
}
break;

case 'status':
echo "<b>Уровни пользователей:</b><br/>\n";
echo "<u>Новичок</u> - самый первый статус, присваивается сразу при регистрации.<br/>\n";
echo "Новички не могут пользоваться функцией \"приват\" пока не наберут хотя бы 100 постов.<br/>\n";
echo "<u>Пользователь</u> - этот статус присваивается, когда Вы набираете более 500 постов.<br/>\n";
echo "<u>Продвинутый</u> - этот статус присваивается, когда Вы набираете более 1000 постов.<br/>\n";
echo "<u>Чаттер</u> - этот статус присваивается, когда Вы набираете более 3000 постов.<br/>\n";
echo "<u>Тусовщик</u> - этот статус присваивается, когда Вы набираете более 5000 постов.<br/>\n";
echo "<u>Настоящий чатланин</u> - этот статус присваивается, когда Вы набираете более 10000 постов.<br/>\n";
echo "При наборе 7000 постов участник чата имеет право попросить администрацию о присвоении личного статуса.<br/>\n";
break;


case 'bots':
$bots = file("bots/bots.dat");
if(!empty($bots[0]) && !empty($bots[1]) && !empty($bots[2]) && !empty($bots[3]))
{
$bots[0] = trim($bots[0]);
$bots[1] = trim($bots[1]);
$bots[2] = trim($bots[2]);
$bots[3] = trim($bots[3]);
echo "В чате есть несколько ботов - программ, которые выполняют заложенные в них действия.<br/>\n";
echo "<b>".$bots[0]."</b> задает вопросы в \"Викторине\". Также принимает ответы и дает подсказки.<br/>\n";
echo "Еще этот бот может повторить вопрос, узнать о статусе участника чата в Викторине или сказать сколько времени осталось до объявления ответа, если ему дать специальную команду.<br/>\n";
echo "<b>".$bots[2]."</b> тоже задает вопросы, но в \"Злой викторине\".<br/>\n";
echo "Данный бот отличается от обычного тем, что он оскорбляет участников чата. Если вы хотите узнать, кто больше знает матерных слов, то вам туда :)<br/>\n";
echo "<b>".$bots[1]."</b> рассказывает шутки и анекдоты в чате. Пользователь по своему усмотрению может включать/отключать показ сообщений от этого бота из настроек.<br/>\n";
echo "<b>".$bots[3]."</b> делает специальные оповещения. Например, о присвоении статуса Модератора какому-нибудь участнику чата или о несакционированном доступе к Вашему нику.<br/>\n";
echo $bots[3]." также оповещает пользователя о получении нового письма, если он находится в чате. Отключить это можно в \"Настройках\".<br/>\n";
echo "Писать на ники ботов бесполезно. Вы не получите ответа.<br/>\n";
echo "Команды для ботов \"Викторины\":<br/>\n";
echo "<u>stats Ник_пользователя</u> - показать статистику пользователя в \"Викторине\".<br/>\n";
echo "<u>!question</u> или <u>!вопрос</u> - повторить вопрос.<br/>\n";
if($level == 4) echo "<u>fas Ник_пользователя</u> - напасть на пользователя.<br/>\n";
}
else
{
echo "Поврежден конфигурационный файл. Корректный просмотр страницы невозможен.<br/>\n";
}
break;

case 'translit':
echo "Правила транслита в чате:<br/><br/>
А a - A a<br/>
Б б - B b<br/>
В в - V v<br/>
Г г - G g<br/>
Д д - D d<br/>
Е е - E e<br/>
Ё ё - YO yo<br/>
Ж - J j<br/>
З - Z z<br/>
И - I i<br/>
Й - Y y<br/>
К - K k<br/>
Л - L l<br/>
М - M m<br/>
Н - N n<br/>
О - O o<br/>
П - P p<br/>
Р - R r<br/>
С - S s<br/>
Т - T t<br/>
У - U u<br/>
Ф - F f<br/>
Х - H h<br/>
Ц - C c<br/>
Ч - CH ch<br/>
Ш - W w<br/>
Щ - SC sc<br/>
Ъ - \"\" \"<br/>
Ы - X x<br/>
Ь - '' '<br/>
Э - YE ye<br/>
Ю - YU yu<br/>
Я - YA ya<br/>\n";
break;

case 'smiles':
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=0&amp;ver=html\">1-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 10)."&amp;ver=html\">2-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 20)."&amp;ver=html\">3-я страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 30)."&amp;ver=html\">4-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 40)."&amp;ver=html\">5-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 50)."&amp;ver=html\">6-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 60)."&amp;ver=html\">7-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 70)."&amp;ver=html\">8-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 80)."&amp;ver=html\">9-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 90)."&amp;ver=html\">10-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 100)."&amp;ver=html\">11-ая страница</a><br/>";
/*
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 110)."&amp;ver=html\">12-ая страница</a><br/>";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start + 120)."&amp;ver=html\">13-ая страница</a><br/>";
*/
break;

case 'showsmiles':
echo "Смайлы:<br/>";
$smiles = array();

$smiles[] = "<img src=\"smiles/001.gif\" alt=\".smile.\"/><br/>.smile.<br/>";
$smiles[] = "<img src=\"smiles/002.gif\" alt=\".oops.\"/><br/>.oops.<br/>";
$smiles[] = "<img src=\"smiles/003.gif\" alt=\".xexe.\"/><br/>.xexe.<br/>";
$smiles[] = "<img src=\"smiles/004.gif\" alt=\".grief.\"/><br/>.grief.<br/>";
$smiles[] = "<img src=\"smiles/005.gif\" alt=\".cool.\"/><br/>.cool.<br/>";
$smiles[] = "<img src=\"smiles/006.gif\" alt=\".lol.\"/><br/>.lol.<br/>";
$smiles[] = "<img src=\"smiles/007.gif\" alt=\".be.\"/><br/>.be.<br/>";
$smiles[] = "<img src=\"smiles/008.gif\" alt=\".unsure.\"/><br/>.unsure.<br/>";
$smiles[] = "<img src=\"smiles/009.gif\" alt=\".ok.\"/><br/>.ok.<br/>";
$smiles[] = "<img src=\"smiles/010.gif\" alt=\".fuck.\"/><br/>.fuck.<br/>";
$smiles[] = "<img src=\"smiles/011.gif\" alt=\".inlove.\"/><br/>.inlove.<br/>";
$smiles[] = "<img src=\"smiles/012.gif\" alt=\".love.\"/><br/>.love.<br/>";
$smiles[] = "<img src=\"smiles/013.gif\" alt=\".lips.\"/><br/>.lips.<br/>";
$smiles[] = "<img src=\"smiles/014.gif\" alt=\".love2.\"/><br/>.love2.<br/>";
$smiles[] = "<img src=\"smiles/015.gif\" alt=\".fanat.\"/><br/>.fanat.<br/>";
$smiles[] = "<img src=\"smiles/016.gif\" alt=\".fanat2.\"/><br/>.fanat2.<br/>";
$smiles[] = "<img src=\"smiles/017.gif\" alt=\".fanats.\"/><br/>.fanats.<br/>";
$smiles[] = "<img src=\"smiles/018.gif\" alt=\".bublegum.\"/><br/>.bublegum.<br/>";
$smiles[] = "<img src=\"smiles/019.gif\" alt=\".joker.\"/><br/>.joker.<br/>";
$smiles[] = "<img src=\"smiles/020.gif\" alt=\".music.\"/><br/>.music.<br/>";
$smiles[] = "<img src=\"smiles/021.gif\" alt=\".no.\"/><br/>.no.<br/>";
$smiles[] = "<img src=\"smiles/022.gif\" alt=\".spider.\"/><br/>.spider.<br/>";
$smiles[] = "<img src=\"smiles/023.gif\" alt=\".strong.\"/><br/>.strong.<br/>";
$smiles[] = "<img src=\"smiles/024.gif\" alt=\".strong2.\"/><br/>.strong2.<br/>";
$smiles[] = "<img src=\"smiles/025.gif\" alt=\".welcome.\"/><br/>.welcome.<br/>";
$smiles[] = "<img src=\"smiles/026.gif\" alt=\".wizard.\"/><br/>.wizard.<br/>";
$smiles[] = "<img src=\"smiles/027.gif\" alt=\".zzz.\"/><br/>.zzz.<br/>";
$smiles[] = "<img src=\"smiles/028.gif\" alt=\".happy.\"/><br/>.happy.<br/>";
$smiles[] = "<img src=\"smiles/029.gif\" alt=\".deadmoroz.\"/><br/>.deadmoroz.<br/>";
$smiles[] = "<img src=\"smiles/030.gif\" alt=\".santa.\"/><br/>.santa.<br/>";
$smiles[] = "<img src=\"smiles/031.gif\" alt=\".santa2.\"/><br/>.santa2.<br/>";
$smiles[] = "<img src=\"smiles/032.gif\" alt=\".bebe.\"/><br/>.bebe.<br/>";
$smiles[] = "<img src=\"smiles/033.gif\" alt=\".newyear.\"/><br/>.newyear.<br/>";
$smiles[] = "<img src=\"smiles/034.gif\" alt=\".guns.\"/><br/>.guns.<br/>";
$smiles[] = "<img src=\"smiles/035.gif\" alt=\".guns2.\"/><br/>.guns2.<br/>";
$smiles[] = "<img src=\"smiles/036.gif\" alt=\".jason.\"/><br/>.jason.<br/>";
$smiles[] = "<img src=\"smiles/037.gif\" alt=\".dead.\"/><br/>.dead.<br/>";
$smiles[] = "<img src=\"smiles/038.gif\" alt=\".guns3.\"/><br/>.guns3.<br/>";
$smiles[] = "<img src=\"smiles/039.gif\" alt=\".terrors.\"/><br/>.terrors.<br/>";
$smiles[] = "<img src=\"smiles/040.gif\" alt=\".roulette.\"/><br/>.roulette.<br/>";
$smiles[] = "<img src=\"smiles/041.gif\" alt=\".suicid.\"/><br/>.suicid.<br/>";
$smiles[] = "<img src=\"smiles/042.gif\" alt=\".suicid2.\"/><br/>.suicid2.<br/>";
$smiles[] = "<img src=\"smiles/043.gif\" alt=\".noonchaks.\"/><br/>.noonchaks.<br/>";
$smiles[] = "<img src=\"smiles/044.gif\" alt=\".paladin.\"/><br/>.paladin.<br/>";
$smiles[] = "<img src=\"smiles/045.gif\" alt=\".barbarian.\"/><br/>.barbarian.<br/>";
$smiles[] = "<img src=\"smiles/046.gif\" alt=\".xex.\"/><br/>.xex.<br/>";
$smiles[] = "<img src=\"smiles/047.gif\" alt=\".nono.\"/><br/>.nono.<br/>";
$smiles[] = "<img src=\"smiles/048.gif\" alt=\".ooo.\"/><br/>.ooo.<br/>";
$smiles[] = "<img src=\"smiles/049.gif\" alt=\".stop.\"/><br/>.stop.<br/>";
$smiles[] = "<img src=\"smiles/050.gif\" alt=\".suicid3.\"/><br/>.suicid3.<br/>";
$smiles[] = "<img src=\"smiles/051.gif\" alt=\".itshe.\"/><br/>.itshe.<br/>";
$smiles[] = "<img src=\"smiles/052.gif\" alt=\".victory.\"/><br/>.victory.<br/>";
$smiles[] = "<img src=\"smiles/053.gif\" alt=\".yahoo.\"/><br/>.yahoo.<br/>";
$smiles[] = "<img src=\"smiles/054.gif\" alt=\".cry.\"/><br/>.cry.<br/>";
$smiles[] = "<img src=\"smiles/055.gif\" alt=\".bebe2.\"/><br/>.bebe2.<br/>";
$smiles[] = "<img src=\"smiles/056.gif\" alt=\".beee.\"/><br/>.beee.<br/>";
$smiles[] = "<img src=\"smiles/057.gif\" alt=\".yes.\"/><br/>.yes.<br/>";
$smiles[] = "<img src=\"smiles/058.gif\" alt=\".hi.\"/><br/>.hi.<br/>";
$smiles[] = "<img src=\"smiles/059.gif\" alt=\".search.\"/><br/>.search.<br/>";
$smiles[] = "<img src=\"smiles/060.gif\" alt=\".alcans.\"/><br/>.alcans.<br/>";
$smiles[] = "<img src=\"smiles/061.gif\" alt=\".trans.\"/><br/>.trans.<br/>";
$smiles[] = "<img src=\"smiles/062.gif\" alt=\".superman.\"/><br/>.superman.<br/>";
$smiles[] = "<img src=\"smiles/063.gif\" alt=\".death.\"/><br/>.death.<br/>";
$smiles[] = "<img src=\"smiles/064.gif\" alt=\".censored.\"/><br/>.censored.<br/>";
$smiles[] = "<img src=\"smiles/065.gif\" alt=\".unkind.\"/><br/>.unkind.<br/>";
$smiles[] = "<img src=\"smiles/066.gif\" alt=\".kong.\"/><br/>.kong.<br/>";
$smiles[] = "<img src=\"smiles/067.gif\" alt=\".pleased.\"/><br/>.pleased.<br/>";
$smiles[] = "<img src=\"smiles/068.gif\" alt=\".rain.\"/><br/>.rain.<br/>";
$smiles[] = "<img src=\"smiles/069.gif\" alt=\".bebe3.\"/><br/>.bebe3.<br/>";
$smiles[] = "<img src=\"smiles/070.gif\" alt=\".friends.\"/><br/>.friends.<br/>";
$smiles[] = "<img src=\"smiles/071.gif\" alt=\".girl.\"/><br/>.girl.<br/>";
$smiles[] = "<img src=\"smiles/072.gif\" alt=\".fool.\"/><br/>.fool.<br/>";
$smiles[] = "<img src=\"smiles/073.gif\" alt=\".photo.\"/><br/>.photo.<br/>";
$smiles[] = "<img src=\"smiles/074.gif\" alt=\".hm.\"/><br/>.hm.<br/>";
$smiles[] = "<img src=\"smiles/075.gif\" alt=\".unnormal.\"/><br/>.unnormal.<br/>";
$smiles[] = "<img src=\"smiles/076.gif\" alt=\".idea.\"/><br/>.idea.<br/>";
$smiles[] = "<img src=\"smiles/077.gif\" alt=\".deadman.\"/><br/>.deadman.<br/>";
$smiles[] = "<img src=\"smiles/078.gif\" alt=\".king.\"/><br/>.king.<br/>";
$smiles[] = "<img src=\"smiles/079.gif\" alt=\".idiot.\"/><br/>.idiot.<br/>";
$smiles[] = "<img src=\"smiles/080.gif\" alt=\".beer.\"/><br/>.beer.<br/>";
$smiles[] = "<img src=\"smiles/081.gif\" alt=\".kuku.\"/><br/>.kuku.<br/>";
$smiles[] = "<img src=\"smiles/082.gif\" alt=\".smoke.\"/><br/>.smoke.<br/>";
$smiles[] = "<img src=\"smiles/083.gif\" alt=\".cool2.\"/><br/>.cool2.<br/>";
$smiles[] = "<img src=\"smiles/084.gif\" alt=\".ok2.\"/><br/>.ok2.<br/>";
$smiles[] = "<img src=\"smiles/085.gif\" alt=\".clapping.\"/><br/>.clapping.<br/>";
$smiles[] = "<img src=\"smiles/086.gif\" alt=\".heat.\"/><br/>.heat.<br/>";
$smiles[] = "<img src=\"smiles/087.gif\" alt=\".mad.\"/><br/>.mad.<br/>";
$smiles[] = "<img src=\"smiles/088.gif\" alt=\".postal.\"/><br/>.postal.<br/>";
$smiles[] = "<img src=\"smiles/089.gif\" alt=\".child.\"/><br/>.child.<br/>";
$smiles[] = "<img src=\"smiles/090.gif\" alt=\".mp3.\"/><br/>.mp3.<br/>";
$smiles[] = "<img src=\"smiles/091.gif\" alt=\".narik.\"/><br/>.narik.<br/>";
$smiles[] = "<img src=\"smiles/092.gif\" alt=\".blabla.\"/><br/>.blabla.<br/>";
$smiles[] = "<img src=\"smiles/093.gif\" alt=\".hi2.\"/><br/>.hi2.<br/>";
$smiles[] = "<img src=\"smiles/094.gif\" alt=\".ok3.\"/><br/>.ok3.<br/>";
$smiles[] = "<img src=\"smiles/095.gif\" alt=\".ok4.\"/><br/>.ok4.<br/>";
$smiles[] = "<img src=\"smiles/096.gif\" alt=\".punk.\"/><br/>.punk.<br/>";
$smiles[] = "<img src=\"smiles/097.gif\" alt=\".thanks.\"/><br/>.thanks.<br/>";
$smiles[] = "<img src=\"smiles/098.gif\" alt=\".bad.\"/><br/>.bad.<br/>";
$smiles[] = "<img src=\"smiles/099.gif\" alt=\".popcorn.\"/><br/>.popcorn.<br/>";
$smiles[] = "<img src=\"smiles/100.gif\" alt=\".preved.\"/><br/>.preved.<br/>";
$smiles[] = "<img src=\"smiles/101.gif\" alt=\".blush.\"/><br/>.blush.<br/>";
$smiles[] = "<img src=\"smiles/102.gif\" alt=\".party.\"/><br/>.party.<br/>";
$smiles[] = "<img src=\"smiles/103.gif\" alt=\".lol2.\"/><br/>.lol2.<br/>";
$smiles[] = "<img src=\"smiles/104.gif\" alt=\".grief2.\"/><br/>.grief2.<br/>";
$smiles[] = "<img src=\"smiles/105.gif\" alt=\".bugaga.\"/><br/>.bugaga.<br/>";
$smiles[] = "<img src=\"smiles/106.gif\" alt=\".smile2.\"/><br/>.smile2.<br/>";
$smiles[] = "<img src=\"smiles/107.gif\" alt=\".smoke2.\"/><br/>.smoke2.<br/>";
$smiles[] = "<img src=\"smiles/108.gif\" alt=\".punish.\"/><br/>.punish.<br/>";
$smiles[] = "<img src=\"smiles/109.gif\" alt=\".pcix.\"/><br/>.pcix.<br/>";
$smiles[] = "<img src=\"smiles/110.gif\" alt=\".pcix2.\"/><br/>.pcix2.<br/>";

$start = $_GET['start'];
$all = count($smiles);
$count = $all;
if(empty($start)) $start=0;
$start = intval($start);
if($start < 0)
$start=0;
if($count > $start + 10) $count = $start + 10;
for($i = $start;$i < $count;$i++)
{
print $smiles["$i"];
}
if($start!=0)
{
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start-10)."&amp;ver=html\">".htmlspecialchars("<<<")."</a><br/>";
}
if($all > $start + 10)
{
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;mod=showsmiles&amp;start=".($start+10)."&amp;ver=html\">".htmlspecialchars(">>>")."</a><br/>";
}
break;

case 'photo':
echo "В WML-версии Вы можете загрузить фотографию только по URL, то есть по её адресу.<br />\n";
echo "В HTML также доступна загрузка через HTML-форму (не все телефоны её поддерживают).<br />\n";
echo "Вес фотографии не должен превышать 500Kb, должен быть в одном из трех форматов: GIF, PNG или JPEG.<br />\n";
echo "Размер не больше 800x600.<br />\n";
break;

default:
if($level == 3) echo "<a href=\"rules/smoder_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила С-Модеров</a><br/>\n";
if($level == 2) echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила Модеров</a><br/>\n";
if($level == 1) echo "<a href=\"rules/vip_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила VIP</a><br/>\n";
echo "<a href=\"rules/user_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила чата</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=govenment\">Администрация и Модераторы</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html\">Статистика</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=status\">Статусы</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=bots\">Боты</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=photo\">Фотография</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=smiles\">Смайлы</a><br/>\n";
echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=translit\">Транслит</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"faq.php?id=$id&amp;password=$password&amp;ver=html\">FAQ</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>