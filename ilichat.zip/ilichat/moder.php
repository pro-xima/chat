<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$nocache = rand(10000, 99999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

if($level != 2)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?ver=wml&amp;id=$id&amp;password=$password\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Доступ запрещен<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Модерка\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'edit':
$nickname = trim(mysql_escape_string(htmlspecialchars($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
	if($_POST['translit'] == "yes")
	{
	$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
	$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
	$nickname = str_replace($lat, $rus, $nickname);
	}
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."';");

if(mysql_affected_rows() == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
break;
}

$user = mysql_fetch_array($q);
$uid = $user['id'];
$pass = $user['password'];
$posts = $user['posts'];
$lev = $user['level'];
$status = $user['status'];

if($lev > 1 && $uid != $id)
{
echo "Модераторы не имеют права редактировать профили другим Модераторов и Администраторов.<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password\">Правила Модераторов</a><br/>\n";
break;
}

echo "Статус:<br/>\n";
echo "<input name=\"status$nocache\" value=\"$status\" maxlength=\"20\"/><br/>\n";
echo "<anchor>[Сохранить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=edit\" method=\"post\">\n";
echo "<postfield name=\"uid\" value=\"$uid\"/>\n";
echo "<postfield name=\"status\" value=\"$(status$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"save\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$uid = intval($_POST['uid']);
$status = htmlspecialchars(mysql_escape_string(trim($_POST['status'])));
$status = str_replace('$', '$$', $status);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$uid."' AND `id` != '".$id."';");
$lev = mysql_result($q, 0);

	if($lev > 1 && $uid != $id)
	{
	echo "Модераторы не имеют права редактировать профили другим Модераторов и Администраторов.<br/>\n";
	echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password\">Правила С-Модераторов</a><br/>\n";
	break;
	}

$query = mysql_query("UPDATE `chat_users` SET  `status` = '".$status."' WHERE `id` = '".$uid."';");
	if($query)
	{
	echo "Данные успешно сохранены!<br/>\n";
	}
	else
	{
	echo "При сохранении произошла ошибка!<br/>\n";
	echo mysql_error()."<br/>\n";
	}
}
break;

case 'kick':
$nickname = trim(mysql_escape_string(htmlspecialchars($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
$reason = trim(mysql_escape_string(htmlspecialchars($_POST['reason'])));
$reason = str_replace('$', '$$', $reason);
$kick = intval($_POST['time']);

if($kick != 60 && $kick != 90 && $kick != 300 && $kick != 43200 && $kick != 86400 && $kick != 172800)
{
echo "Вы попытались выбрать некорретное значение переключателя \"Время пинка\"!<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила модераторов</a><br/>\n";
break;
}
	if($_POST['translit'] == "yes")
	{
	$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
	$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
	$nickname = str_replace($lat, $rus, $nickname);
	}

$q = mysql_query("SELECT `level`, `id` FROM `chat_users` WHERE `nickname` = '".$nickname."';");
if(mysql_num_rows($q) == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
break;
}

$uid = mysql_result($q, 0, 'id');
$lev = mysql_result($q, 0, 'level');

if($lev > 1 && $uid != $id)
{
echo "Модераторы не имеют права изменять статусы других Модераторов.<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password\">Правила Модераторов</a><br/>\n";
break;
}

if($kick == 0)
{
echo "Нельзя выкидывать из чата на 0 секунд!<br/>\n";
break;
}

if(empty($reason))
{
echo "Вы не указали причину пинка!<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($q, 0);
$q = mysql_query("UPDATE `chat_users` SET `kick` = '".($kick + time())."', `reason` = '".$reason."', `moder` = '".$moder."' WHERE `nickname` = '".$nickname."';");
echo "$nickname успешно выпнут(а) на $kick секунд!<br/>\n";

$date = date("d-m-y H:i:s");
$query = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($query, 0);
$q = mysql_query("INSERT INTO `chat_logs` VALUES(0, '".$moder."', 1, '".$nickname."', '".$reason."', '".$date."', ".time().");"); 
break;

case 'search':
if(!isset($_POST['action']))
{
echo "ID:<br/>\n";
echo "<input name=\"uid$nocache\" format=\"*N\" size=\"4\" maxlength=\"6\"/><br/>\n";
echo "<anchor>[Искать]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=search\" method=\"post\">\n";
echo "<postfield name=\"uid\" value=\"$(uid$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"search\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$uid = intval($_POST['uid']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$uid."';");

if(mysql_num_rows($q) == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=search\">Поиск</a><br/><br/>\n";
}
else
{
$user = mysql_fetch_array($q);
$nick = $user['nickname'];
$pass = $user['password'];
$ip = $user['ip'];
$ua = $user['ua'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$city = $user['city'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$about = $user['about'];
$posts = $user['posts'];
$level = $user['level'];
$answers = $user['answers'];
$gbalans = $user['gbalans'];
$status = $user['status'];
$regdate = $user['regdate'];
$place = $user['place'];
$time = $user['time'];

echo "Ник: ".$nick."<br/>\n";
echo "Имя: $name<br/>\n";
if($sex == 0)
{
echo "Пол: мужской<br/>\n";
}
else
{
echo "Пол: женский<br/>\n";
}
echo "Дата рождения: $birthday<br/>\n";
echo "Статус: $status<br/>\n";
echo "Количество постов: $posts<br/>\n";
echo "Ответов в викторине: $answers<br/>\n";
echo "Игровой баланс: $gbalans<br/>\n";
echo "Город: $city<br/>\n";
echo "Модель мобильного телефона: $mobile<br/>\n";
echo "Сайт: <a href=\"http://$site\">$site</a><br/>\n";
echo "Email: $email<br/>\n";
echo "О себе: $about<br/>\n";
echo "Дата регистрации: $regdate<br/>\n";
$ltime = time() - ($time - 60);
if($ltime < 60 && $ltime >= 0)
{
$var = "sec.";
}
elseif($ltime < 3600 && $ltime > 60)
{
$new = $ltime;
$ltime = $new/60;
$var = "min.";
}
elseif($ltime < 86400 && $ltime > 3600)
{
$new = $ltime;
$ltime = $new/3600;
$var = "hours";
}
elseif($ltime > 86400)
{
$new = $ltime;
$ltime = $new/86400;
$var = "days";
}
$ltime = round($ltime, 2);
if($ltime != 0)
{
echo "Время с последнего захода в чат: $ltime $var<br/>\n";
}
else
{
echo "Онлайн.<br/>\n";
}
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=search\">Поиск</a><br/><br/>\n";
}
}
break;

case 'allusers':
$query = @mysql_query("SELECT COUNT(*) FROM `chat_users`;");
$all = @mysql_result($query, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;
$c = $s + 1;

if ($s > 20)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers&amp;s=0\">&lt;&lt;&lt;&lt;</a><br/>";
if ($s > 0)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers&amp;s=".($s-10)."\">&lt;&lt;&lt;</a><br/>";

$query = @mysql_query("SELECT `id`, `nickname`, `posts` FROM `chat_users` ORDER BY `posts` DESC LIMIT $s, 10;");

while($user = mysql_fetch_array($query))
{
$uid = $user['id'];
$nick = $user['nickname'];
$posts = $user['posts'];
echo "$c. $nick, ID=$uid - $posts<br/>\n";
$c++;
}

if ($all > $s + 10)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers&amp;s=".($s+10)."\">&gt;&gt;&gt;</a><br/>";
if (($all > $s + 10) && ($all - $s > 20))  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers&amp;s=".($all-10)."\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'kicklist':
$query = @mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `kick` > ".time().";");
$all = @mysql_result($query, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;
$c = $s + 1;

if ($s > 20)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist&amp;s=0\">&lt;&lt;&lt;&lt;</a><br/>";
if ($s > 0)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist&amp;s=".($s-10)."\">&lt;&lt;&lt;</a><br/>";

$query = @mysql_query("SELECT `id`, `nickname`, `kick`, `moder`, `reason` FROM `chat_users` WHERE `kick` > ".time().";");

if(mysql_num_rows($query) == 0)
{
echo "Бан-лист пуст.<br/>\n";
}

while($kick = mysql_fetch_array($query))
{
$nickname = $kick['nickname'];
$uid = $kick['id'];
$time = $kick['kick'] - time();
$moder = $kick['moder'];
$reason = $kick['reason'];
echo "$c. $nickname, ID=$uid.<br/>\n";
echo "Разбан через <u>$time</u> сек., выпнут модератором <u>$moder</u>, причина:<br/>\n";
echo "<u>$reason</u><br/>\n";
$c++;
}

if ($all > $s + 10)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist&amp;s=".($s+10)."\">&gt;&gt;&gt;</a><br/>";
if (($all > $s + 10) && ($all - $s > 20))  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist&amp;s=".($all-10)."\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'editroom':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `name` FROM `chat_rooms`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Нет ни одной комнаты.<br/>\n";
	}
	else
	{
	echo "<select multiple=\"false\" name=\"room$nocache\">\n";
		while($room = mysql_fetch_array($q))
		{
		$name = $room['name'];
		$rid = $room['id'];
		echo "<option value=\"$rid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<anchor>[Изменить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=editroom\" method=\"post\">\n";
	echo "<postfield name=\"room\" value=\"$(room$nocache)\"/>\n";
	echo "<postfield name=\"action\" value=\"remove\"/>\n";
	echo "</go></anchor><br/>\n";
	}
}
else
{
$room = intval($_POST['room']);
$q = mysql_query("SELECT `topic` FROM `chat_rooms` WHERE `id` = '".$room."';");

if(mysql_num_rows($q) == 0)
{
echo "Такой комнаты не существует.<br/>\n";
break;
}

$topic = mysql_result($q, 0);

echo "Заголовок:<br/>\n";
echo "<input name=\"topic$nocache\" maxlength=\"20\" value=\"$topic\" title=\"topic\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select name=\"translit$nocache\" value=\"false\">\n";
echo "<option value=\"false\">Нет</option></select><br/>\n";
echo "<option value=\"true\">Да</option>\n";
echo "<anchor>[Сохранить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=uproom\" method=\"post\">\n";
echo "<postfield name=\"room\" value=\"$room\"/>\n";
echo "<postfield name=\"topic\" value=\"$(topic$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
}
break;

case 'uproom':
$room = intval($_POST['room']);
$q = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `id` = '".$room."';");
if(mysql_num_rows($q) == 0)
{
echo "Такой комнаты не существует.<br/>\n";
break;
}
$topic = trim(mysql_escape_string(htmlspecialchars($_POST['topic'])));
$topic = str_replace('$', '$$', $topic);

if($_POST['translit'] == "true")
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$topic = str_replace($lat, $rus, $topic);
}

$q = mysql_query("UPDATE `chat_rooms` SET `topic` = '".$topic."' WHERE `id` = '".$room."';");
echo "Топик комнаты изменен!<br/>\n";
break;

case 'clear':
$q = mysql_query("TRUNCATE TABLE `chat`;");
echo "Все комнаты успешно очищены!<br/>\n";
break;

case 'addnews':
if(!isset($_POST['action']))
{
echo "Заголовок:<br/>\n";
echo "<input name=\"title$nocache\" maxlength=\"20\" value=\"\" title=\"title\"/><br/>\n";
echo "Текст:<br/>\n";
echo "<input name=\"text$nocache\" maxlength=\"300\" value=\"\" title=\"text\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"true\" name=\"translit$nocache\">\n";
echo "<option value=\"title\">Заголовок</option>\n";
echo "<option value=\"text\">Текст</option></select><br/>\n";
echo "<anchor>[Добавить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=addnews\" method=\"post\">\n";
echo "<postfield name=\"title\" value=\"$(title$nocache)\"/>\n";
echo "<postfield name=\"text\" value=\"$(text$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"add\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$title = str_replace('$', '$$', $title);
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));
$text = str_replace('$', '$$', $text);
$translit = $_POST['translit'];

if(substr_count($translit, "title") != 0)
{
$title = str_replace($lat, $rus, $title);
}

if(substr_count($translit, "text") != 0)
{
$text = str_replace($lat, $rus, $text);
}

if(empty($title))
{
echo "Вы не ввели заголовок новости!<br/>\n";
break;
}

if(empty($text))
{
echo "Вы не ввели текст новости!<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `name` = '".$title."' AND `text` = '".$text."';");
$nickname = mysql_result($q, 0);

if(mysql_affected_rows($q) != 0)
{
echo "Новость уже была добавлена.<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$nickname = mysql_result($q, 0);
$date = date("d-m-Y");

$sql = mysql_query("INSERT INTO `chat_news` VALUES(0, '".$title."', '".$nickname."', '".$text."', '".$date."', ".time().");");

if($sql)
{
echo "Новость успешно добавлена!<br/>\n";
}
else
{
echo "Новость не добавлена, произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}
}
break;

case 'delnews':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `name` FROM `chat_news`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Новостей нет.<br/>\n";
	}
	else
	{
	echo "<select multiple=\"false\" name=\"nid$nocache\">\n";
		while($news = mysql_fetch_array($q))
		{
		$name = $news['name'];
		$nid = $news['id'];
		echo "<option value=\"$nid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<anchor>[Удалить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=delnews\" method=\"post\">\n";
	echo "<postfield name=\"nid\" value=\"$(nid$nocache)\"/>\n";
	echo "<postfield name=\"action\" value=\"remove\"/>\n";
	echo "</go></anchor><br/>\n";
	}
}
else
{
$nid = intval($_POST['nid']);
$q = mysql_query("DELETE FROM `chat_news` WHERE `id` = '".$nid."';");
	if(mysql_affected_rows() != 0)
	{
	echo "Новость успешно удалена!<br/>\n";
	}
	else
	{
	echo "Новость не найдена.<br/>\n";
	}
}
break;

case 'addmeet':
if(!isset($_POST['action']))
{
echo "Заголовок:<br/>\n";
echo "<input name=\"title$nocache\" maxlength=\"20\" value=\"\" title=\"title\"/><br/>\n";
echo "Текст встречи:<br/>\n";
echo "<input name=\"text$nocache\" maxlength=\"300\" value=\"\" title=\"text\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"true\" name=\"translit$nocache\">\n";
echo "<option value=\"title\">Заголовок</option>\n";
echo "<option value=\"text\">Текст встречи</option></select><br/>\n";
echo "<anchor>[Добавить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=addmeet\" method=\"post\">\n";
echo "<postfield name=\"title\" value=\"$(title$nocache)\"/>\n";
echo "<postfield name=\"text\" value=\"$(text$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"add\"/>\n";
echo "</go></anchor><br/>\n";
}
else
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$title = str_replace('$', '$$', $title);
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));
$text = str_replace('$', '$$', $text);
$translit = $_POST['translit'];

if(substr_count($translit, "title") != 0)
{
$title = str_replace($lat, $rus, $title);
}

if(substr_count($translit, "text") != 0)
{
$text = str_replace($lat, $rus, $text);
}

if(empty($title))
{
echo "Вы не ввели заголовок встречи!<br/>\n";
break;
}

if(empty($text))
{
echo "Вы не ввели текст встречи!<br/>\n";
break;
}

$sql = mysql_query("SELECT `id` FROM `chat_meets` WHERE `title` = '".$title."' AND `body` = '".$text."';");

if(mysql_num_rows($sql) != 0)
{
echo "Встреча уже была добавлена.<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$nickname = mysql_result($q, 0);
$date = date("d-m-Y");

$sql = mysql_query("INSERT INTO `chat_meets` VALUES(0, '".$nickname."', '".$title."', '".$text."', '".$date."', ".time().");");

if($sql)
{
echo "Встреча успешно добавлена!<br/>\n";
}
else
{
echo "При добавлении произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}
}
break;

case 'delmeet':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `title` FROM `chat_meets`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Встреч нет.<br/>\n";
	}
	else
	{
	echo "<select multiple=\"false\" name=\"mid$nocache\">\n";
		while($meets = mysql_fetch_array($q))
		{
		$name = $meets['title'];
		$mid = $meets['id'];
		echo "<option value=\"$mid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<anchor>[Удалить]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=delmeet\" method=\"post\">\n";
	echo "<postfield name=\"mid\" value=\"$(mid$nocache)\"/>\n";
	echo "<postfield name=\"action\" value=\"remove\"/>\n";
	echo "</go></anchor><br/>\n";
	}
}
else
{
$mid = intval($_POST['mid']);
$q = mysql_query("DELETE FROM `chat_meets` WHERE `id` = '".$mid."';");
	if(mysql_affected_rows() != 0)
	{
	echo "Встреча успешно удалена!<br/>\n";
	}
	else
	{
	echo "Встреча не найдена.<br/>\n";
	}
}
break;

default:
echo "[Пользователи]<br/>\n";
echo "Никнейм:<br/>\n";
echo "<input name=\"nickname$nocache\" maxlength=\"20\" title=\"nickname\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"false\" name=\"translit$nocache\" value=\"no\">\n";
echo "<option value=\"no\">Нет</option>\n";
echo "<option value=\"yes\">Да</option></select><br/>\n";
echo "<anchor>[Сменить статус]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=edit\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "Время пинка (сек):<br/>\n";
echo "<select name=\"time$nocache\" value=\"60\">\n";
echo "<option value=\"60\">60</option>\n";
echo "<option value=\"90\">90</option>\n";
echo "<option value=\"300\">300</option>\n";
echo "<option value=\"43200\">43200</option>\n";
echo "<option value=\"86400\">86400</option>\n";
echo "<option value=\"172800\">172800</option>\n";
echo "</select><br/>\n";
echo "Причина:<br/>\n";
echo "<input name=\"reason$nocache\" maxlength=\"200\" title=\"reason\"/><br/>\n";
echo "<anchor>[Пнуть]<go href=\"moder.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=kick\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"reason\" value=\"$(reason$nocache)\"/>\n";
echo "<postfield name=\"time\" value=\"$(time$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
//echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=search&amp;nocache=$nocache\">Поиск по ID</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers\">Все пользователи</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist\">Список \"выпнутых\"</a><br/>\n";
echo "---<br/>\n";
echo "[Комнаты]<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=editroom&amp;nocache=$nocache\">Изменить топик</a><br/>\n";
//echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=clear\">Очистить комнаты</a><br/>\n";
echo "---<br/>\n";
echo "[Прочее]<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addnews&amp;nocache=$nocache\">Добавить новость</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=delnews&amp;nocache=$nocache\">Удалить новость</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addmeet&amp;nocache=$nocache\">Добавить встречу</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=delmeet&amp;nocache=$nocache\">Удалить встречу</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=wml\">Модерка</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0 WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body><div style=\"text-align: left\">\n";

$level = mysql_result($q, 0);

if($level != 2)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body><div style=\"text-align: left\">\n";
echo "Доступ запрещен<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</div></body></html>";
exit();
}

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

if(isset($_GET['handler']))
{
$action = intval($_POST['mod']);

	switch($action)
	{
	case 0:
	$mod = "edit";
	break;

	case 1:
	$mod = "kick";
	break;

	case 2:
	$mod = "ban";
	break;

	case 3:
	$mod = "ipua";
	break;
	}
}

switch($mod)
{
case 'edit':
$nickname = trim(mysql_escape_string(htmlspecialchars($_POST['nickname'])));
	if($_POST['translit'] == "yes")
	{
	$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
	$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
	$nickname = str_replace($lat, $rus, $nickname);
	}
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."';");

if(mysql_affected_rows() == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
break;
}

$user = mysql_fetch_array($q);
$uid = $user['id'];
//$posts = $user['posts'];
$status = $user['status'];
$lev = $user['level'];
if($lev > 1)
{
echo "Модераторы не имеют права изменять статусы других Модераторов.<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила Модераторов</a><br/>\n";
break;
}

echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=edit\">\n";
echo "Статус:<br/>\n";
echo "<input name=\"status\" value=\"$status\" maxlength=\"20\"/><br/>\n";
echo "<input type=\"hidden\" name=\"uid\" value=\"$uid\"/>";
echo "<input type=\"hidden\" name=\"action\" value=\"save\"/>";
echo "<input type=\"submit\" value=\"Сохранить\"/></form></div><br/>\n";
}
else
{
$uid = intval($_POST['uid']);
$status = htmlspecialchars(mysql_escape_string(trim($_POST['status'])));
$status = str_replace('$', '$$', $status);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `nickname` = '".$nickname."' AND `id` != '".$uid."';");
	if(mysql_num_rows($q) != 0)
	{
	echo "Пользователь с таким ником уже существует.<br/>\n";
	break;
	}
	else
	{
	$lev = mysql_result($q, 0);
	}
	if($lev > 1)
	{
	echo "Модераторы не имеют права изменять статусы других Модераторов.<br/>\n";
	echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password\">Правила Модераторов</a><br/>\n";
	break;
	}
$query = mysql_query("UPDATE `chat_users` SET `status` = '".$status."' WHERE `id` = '".$uid."';");
	if($query)
	{
	echo "Данные успешно сохранены!<br/>\n";
	}
	else
	{
	echo "При сохранении произошла ошибка!<br/>\n";
	echo mysql_error()."<br/>\n";
	}
}
break;

case 'kick':
$nickname = trim(mysql_escape_string(htmlspecialchars($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
$reason = trim(mysql_escape_string(htmlspecialchars($_POST['reason'])));
$reason = str_replace('$', '$$', $reason);
$kick = intval($_POST['time']);

if($kick != 60 && $kick != 90 && $kick != 300 && $kick != 43200 && $kick != 86400 && $kick != 172800)
{
echo "Вы попытались выбрать некорретное значение переключателя \"Время пинка\"!<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=wml\">Правила модераторов</a><br/>\n";
break;
}
	if($_POST['translit'] == "yes")
	{
	$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
	$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
	$nickname = str_replace($lat, $rus, $nickname);
	}

$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."';");

if(mysql_affected_rows() == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
break;
}
else
{
$lev = mysql_result($q, 0, 'level');
}

if($lev > 1)
{
echo "Модераторы не имеют права изменять пинать других Модераторов.<br/>\n";
echo "<a href=\"rules/moder_rules.php?id=$id&amp;password=$password&amp;ver=html\">Правила Модераторов</a><br/>\n";
break;
}

if($kick == 0)
{
echo "Нельзя выкидывать из чата на 0 секунд!<br/>\n";
break;
}

if(empty($reason))
{
echo "Вы не указали причину пинка!<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($q, 0);
$q = mysql_query("UPDATE `chat_users` SET `kick` = '".($kick + time())."', `reason` = '".$reason."', `moder` = '".$moder."' WHERE `nickname` = '".$nickname."';");
echo "$nickname успешно выпнут(а) на $kick секунд!<br/>\n";

$date = date("d-m-y H:i:s");
$query = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($query, 0);
$q = mysql_query("INSERT INTO `chat_logs` VALUES(0, '".$moder."', 1, '".$nickname."', '".$reason."', '".$date."', ".time().");"); 
break;

case 'ban':
$nickname = trim(mysql_escape_string(htmlspecialchars($_POST['nickname'])));
$nickname = str_replace('$', '$$', $nickname);
	if($_POST['translit'] == "yes")
	{
	$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
	$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
	$nickname = str_replace($lat, $rus, $nickname);
	}
$q = mysql_query("SELECT * FROM `chat_users` WHERE `nickname` = '".$nickname."';");
if(mysql_affected_rows() == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
break;
}
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($q, 0);
$q = mysql_query("UPDATE `chat_users` SET `ban` = 1 WHERE `nickname` = '".$nickname."';");
echo "$nickname забанен!<br/>\n";

$date = date("d-m-y H:i:s");
$query = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$moder = mysql_result($query, 0);
mysql_query("INSERT INTO `chat_logs` VALUES(0, '".$moder."', 2, '".$nickname."', '', '".$date."', ".time().");"); 
break;

case 'search':
if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=search\">\n";
echo "ID:<br/>\n";
echo "<input name=\"uid\" size=\"4\" maxlength=\"6\"/><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"search\"/>";
echo "<input type=\"submit\" value=\"Искать\"/></form></div><br/>\n";
}
else
{
$uid = intval($_POST['uid']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$uid."';");

if(mysql_num_rows($q) == 0)
{
echo "Пользователь не найден в базе данных.<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=search\">Поиск</a><br/><br/>\n";
}
else
{
$user = mysql_fetch_array($q);
$nick = $user['nickname'];
$pass = $user['password'];
$ip = $user['ip'];
$ua = $user['ua'];
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$name = $user['name'];
$site = $user['site'];
$sex = $user['sex'];
$city = $user['city'];
$mobile = $user['mobile'];
$email = $user['email'];
$birthday = $user['birthday'];
$about = $user['about'];
$posts = $user['posts'];
$level = $user['level'];
$answers = $user['answers'];
$gbalans = $user['gbalans'];
$status = $user['status'];
$regdate = $user['regdate'];
$place = $user['place'];
$time = $user['time'];

echo "Ник: ".$nick."<br/>\n";
if($level == 4) echo "Пароль: ".$pass."<br/>\n";
	if($level > 2)
	{
	echo "IP: <u>".$ip."</u><br/>\n";
	echo "UserAgent: <u>".$ua."</u><br/>\n";
	}
	if($level == 4)
	{
		if(time() < $kick)
		{
		$tkick = $kick - time();
		if($tkick < 60 && $tkick > 0)
		{
		$var = "sec.";
		}
		elseif($tkick < 3600 && $tkick > 60)
		{
		$new = $tkick;
		$tkick = $new/60;
		$var = "min.";
		}
		elseif($tkick < 86400 && $tkick > 3600)
		{
		$new = $tkick;
		$tkick = $new/3600;
		$var = "hours";
		}
		elseif($tkick > 86400)
		{
		$new = $tkick;
		$tkick = $new/86400;
		$var = "days";
		}
		$tkick = round($tkick, 2);
		echo "Выпнут модератором <u>".$moder."</u>.<br/>\n";
		echo "Разбан через <u>".$tkick." $var</u><br/>\n";
		echo "Причина: <u>".$reason."</u><br/>\n";
		}
	}
echo "Имя: $name<br/>\n";
if($sex == 0)
{
echo "Пол: мужской<br/>\n";
}
else
{
echo "Пол: женский<br/>\n";
}
echo "Дата рождения: $birthday<br/>\n";
echo "Статус: $status<br/>\n";
echo "Количество постов: $posts<br/>\n";
echo "Ответов в викторине: $answers<br/>\n";
echo "Игровой баланс: $gbalans<br/>\n";
echo "Город: $city<br/>\n";
echo "Модель мобильного телефона: $mobile<br/>\n";
echo "Сайт: <a href=\"http://$site\">$site</a><br/>\n";
echo "Email: $email<br/>\n";
echo "О себе: $about<br/>\n";
echo "Дата регистрации: $regdate<br/>\n";
$ltime = time() - ($time - 60);
if($ltime < 60 && $ltime >= 0)
{
$var = "sec.";
}
elseif($ltime < 3600 && $ltime > 60)
{
$new = $ltime;
$ltime = $new/60;
$var = "min.";
}
elseif($ltime < 86400 && $ltime > 3600)
{
$new = $ltime;
$ltime = $new/3600;
$var = "hours";
}
elseif($ltime > 86400)
{
$new = $ltime;
$ltime = $new/86400;
$var = "days";
}
$ltime = round($ltime, 2);
if($ltime != 0)
{
echo "Время с последнего захода в чат: $ltime $var<br/>\n";
}
else
{
echo "Онлайн.<br/>\n";
}
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=search\">Поиск</a><br/><br/>\n";
}
}
break;

case 'allusers':
$query = @mysql_query("SELECT COUNT(*) FROM `chat_users`;");
$all = @mysql_result($query, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;
$c = $s + 1;

if ($s > 20)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers&amp;s=0\">&lt;&lt;&lt;&lt;</a><br/>";
if ($s > 0)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers&amp;s=".($s-10)."\">&lt;&lt;&lt;</a><br/>";

$query = @mysql_query("SELECT `id`, `nickname`, `posts` FROM `chat_users` ORDER BY `posts` DESC LIMIT $s, 10;");

while($user = mysql_fetch_array($query))
{
$uid = $user['id'];
$nick = $user['nickname'];
$posts = $user['posts'];
echo "$c. $nick, ID=$uid - $posts<br/>\n";
$c++;
}

if ($all > $s + 10)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers&amp;s=".($s+10)."\">&gt;&gt;&gt;</a><br/>";
if (($all > $s + 10) && ($all - $s > 20))  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers&amp;s=".($all-10)."\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'kicklist':
$query = @mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `kick` > ".time().";");
$all = @mysql_result($query, 0);

if(isset($_GET['s'])) $s = intval($_GET['s']);
else $s = 0;
if($s < 0) $s = 0;
if($s > $all) $s = 0;
$c = $s + 1;

if ($s > 20)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist&amp;s=0\">&lt;&lt;&lt;&lt;</a><br/>";
if ($s > 0)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist&amp;s=".($s-10)."\">&lt;&lt;&lt;</a><br/>";

$query = @mysql_query("SELECT `id`, `nickname`, `kick`, `moder`, `reason` FROM `chat_users` WHERE `kick` > ".time().";");

if(mysql_num_rows($query) == 0)
{
echo "Бан-лист пуст.<br/>\n";
}

while($kick = mysql_fetch_array($query))
{
$nickname = $kick['nickname'];
$uid = $kick['id'];
$time = $kick['kick'] - time();
$moder = $kick['moder'];
$reason = $kick['reason'];
echo "$c. $nickname, ID=$uid.<br/>\n";
echo "Разбан через <u>$time</u> сек., выпнут модератором <u>$moder</u>, причина:<br/>\n";
echo "<u>$reason</u><br/>\n";
$c++;
}

if ($all > $s + 10)  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist&amp;s=".($s+10)."\">&gt;&gt;&gt;</a><br/>";
if (($all > $s + 10) && ($all - $s > 20))  print "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist&amp;s=".($all-10)."\">&gt;&gt;&gt;&gt;</a><br/>";
break;

case 'editroom':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `name` FROM `chat_rooms`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Нет ни одной комнаты.<br/>\n";
	}
	else
	{
	echo "<div class=\"form\">\n";
	echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=editroom\">\n";
	echo "<select name=\"room\">\n";
		while($room = mysql_fetch_array($q))
		{
		$name = $room['name'];
		$rid = $room['id'];
		echo "<option value=\"$rid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<input type=\"hidden\" name=\"action\" value=\"edit\"/>\n";
	echo "<input type=\"submit\" value=\"Изменить\"/></form></div><br/>\n";
	}
}
else
{
$room = intval($_POST['room']);
$q = mysql_query("SELECT `topic` FROM `chat_rooms` WHERE `id` = '".$room."';");

if(mysql_num_rows($q) == 0)
{
echo "Такой комнаты не существует.<br/>\n";
break;
}

$topic = mysql_result($q, 0);

echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=uproom\">\n";
echo "Заголовок:<br/>\n";
echo "<input name=\"topic\" maxlength=\"20\" value=\"$topic\" title=\"topic\"/><br/>\n";
echo "Транслитировать: <input type=\"checkbox\" name=\"translit\" value=\"true\"/><br/>\n";
echo "<input type=\"hidden\" name=\"room\" value=\"".$_POST['room']."\"/>\n";
echo "<input type=\"submit\" value=\"Сохранить\"/></form></div><br/>\n";
}
break;

case 'uproom':
$room = intval($_POST['room']);
$q = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `id` = '".$room."';");
if(mysql_num_rows($q) == 0)
{
echo "Такой комнаты не существует.<br/>\n";
break;
}
$topic = trim(mysql_escape_string(htmlspecialchars($_POST['topic'])));
$topic = str_replace('$', '$$', $topic);

if($_POST['translit'] == "true")
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$topic = str_replace($lat, $rus, $topic);
}

if(empty($topic))
{
echo "Вы не ввели топик!<br/>\n";
break;
}

$q = mysql_query("UPDATE `chat_rooms` SET `topic` = '".$topic."' WHERE `id` = '".$room."';");
echo "Настройки комнаты сохранены!<br/>\n";
break;

case 'clear':
$q = mysql_query("TRUNCATE TABLE `chat`;");
echo "Все комнаты успешно очищены!<br/>\n";
break;

case 'addnews':
if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=addnews\">\n";
echo "Заголовок:<br/>\n";
echo "<input name=\"title\" maxlength=\"20\" value=\"\" title=\"title\"/><br/>\n";
echo "Транслитировать: <input type=\"checkbox\" name=\"tt\" value=\"true\"/><br/>\n";
echo "Текст:<br/>\n";
echo "<input name=\"text\" maxlength=\"300\" value=\"\" title=\"text\"/><br/>\n";
echo "Транслитировать: <input type=\"checkbox\" name=\"ta\" value=\"true\"/><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"add\"/>";
echo "<input type=\"submit\" value=\"Добавить\"/></form></div><br/>\n";
}
else
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$title = str_replace('$', '$$', $title);
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));
$text = str_replace('$', '$$', $text);
$tt = $_POST['tt'];
$ta = $_POST['ta'];

if($tt == "true")
{
$title = str_replace($lat, $rus, $title);
}

if($ta == "true")
{
$text = str_replace($lat, $rus, $text);
}

if(empty($title))
{
echo "Вы не ввели заголовок новости!<br/>\n";
break;
}

if(empty($text))
{
echo "Вы не ввели текст новости!<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `name` = '".$title."' AND `text` = '".$text."';");
$nickname = mysql_result($q, 0);

if(mysql_affected_rows($q) != 0)
{
echo "Новость уже была добавлена.<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$nickname = mysql_result($q, 0);
$date = date("d-m-Y");

$sql = mysql_query("INSERT INTO `chat_news` VALUES(0, '".$title."', '".$nickname."', '".$text."', '".$date."', ".time().");");

if($sql)
{
echo "Новость успешно добавлена!<br/>\n";
}
else
{
echo "Новость не добавлена, произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}
}
break;

case 'delnews':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `name` FROM `chat_news`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Новостей нет.<br/>\n";
	}
	else
	{
	echo "<div class=\"form\">\n";
	echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=delnews\">\n";
	echo "<select multiple=\"false\" name=\"nid\">\n";
		while($news = mysql_fetch_array($q))
		{
		$name = $news['name'];
		$nid = $news['id'];
		echo "<option value=\"$nid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<input type=\"hidden\" name=\"action\" value=\"delete\"/>";
	echo "<input type=\"submit\" value=\"Удалить\"/></form></div><br/>\n";
	}
}
else
{
$nid = intval($_POST['nid']);
$q = mysql_query("DELETE FROM `chat_news` WHERE `id` = '".$nid."';");
	if(mysql_affected_rows() != 0)
	{
	echo "Новость успешно удалена!<br/>\n";
	}
	else
	{
	echo "Новость не найдена.<br/>\n";
	}
}
break;

case 'addmeet':
if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=addmeet\">\n";
echo "Заголовок:<br/>\n";
echo "<input name=\"title\" maxlength=\"20\" value=\"\" title=\"title\"/><br/>\n";
echo "Транслитировать: <input type=\"checkbox\" name=\"tt\" value=\"true\"/><br/>\n";
echo "Текст встречи:<br/>\n";
echo "<input name=\"text\" maxlength=\"300\" value=\"\" title=\"text\"/><br/>\n";
echo "Транслитировать: <input type=\"checkbox\" name=\"ta\" value=\"true\"/><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"add\"/>";
echo "<input type=\"submit\" value=\"Добавить\"/></form></div><br/>\n";
}
else
{
$lat = array("J", "j", "Zh", "zh", "Ch", "ch", "Ye", "ye", "Yu", "yu", "Ya", "ya", "Shc", "shc", "Sh", "sh", "Yo", "yo", "Q", "q", "'", "A", "a", "B", "b", "C", "c", "D", "d", "E", "e", "F", "f", "G", "g", "H", "h", "I", "i", "K", "k", "L", "l", "M", "m", "N", "n", "O", "o", "P", "p", "R", "r", "S", "s", "T", "t", "U", "u", "V", "v", "X", "x", "Z", "z");
$rus = array("Й", "й", "Ж", "ж", "Ч", "ч", "Э", "э", "Ю", "ю", "Я", "я", "Щ", "щ", "Ш", "ш", "Ё", "ё", "Ь", "ь", "ъ", "А", "а", "Б", "б", "Ц", "ц", "Д", "д", "Е", "е", "Ф", "ф", "Г", "г", "Х", "х", "И", "и", "К", "к", "Л", "л", "М", "м", "Н", "н", "О", "о", "П", "п", "Р", "р", "С", "с", "Т", "т", "У", "у", "В", "в", "Х", "х", "З", "з");
$title = htmlspecialchars(mysql_escape_string(trim($_POST['title'])));
$title = str_replace('$', '$$', $title);
$text = htmlspecialchars(mysql_escape_string(trim($_POST['text'])));
$text = str_replace('$', '$$', $text);
$tt = $_POST['tt'];
$ta = $_POST['ta'];

if($tt == "true")
{
$title = str_replace($lat, $rus, $title);
}

if($ta == "true")
{
$text = str_replace($lat, $rus, $text);
}

if(empty($title))
{
echo "Вы не ввели заголовок встречи!<br/>\n";
break;
}

if(empty($text))
{
echo "Вы не ввели текст встречи!<br/>\n";
break;
}

$sql = mysql_query("SELECT `id` FROM `chat_meets` WHERE `title` = '".$title."' AND `body` = '".$text."';");

if(mysql_num_rows($sql) != 0)
{
echo "Встреча уже была добавлена.<br/>\n";
break;
}

$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `id` = '".$id."';");
$nickname = mysql_result($q, 0);
$date = date("d-m-Y");

$sql = mysql_query("INSERT INTO `chat_meets` VALUES(0, '".$nickname."', '".$title."', '".$text."', '".$date."', ".time().");");

if($sql)
{
echo "Встреча успешно добавлена!<br/>\n";
}
else
{
echo "При добавлении произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}
}
break;

case 'delmeet':
if(!isset($_POST['action']))
{
$q = mysql_query("SELECT `id`, `title` FROM `chat_meets`;");
	if(mysql_num_rows($q) == 0)
	{
	echo "Встреч нет.<br/>\n";
	}
	else
	{
	echo "<div class=\"form\">\n";
	echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;mod=delmeet\">\n";
	echo "<select multiple=\"false\" name=\"mid\">\n";
		while($meets = mysql_fetch_array($q))
		{
		$name = $meets['title'];
		$mid = $meets['id'];
		echo "<option value=\"$mid\">$name</option>\n";
		}
	echo "</select><br/>\n";
	echo "<input type=\"hidden\" name=\"action\" value=\"delete\"/>";
	echo "<input type=\"submit\" value=\"Удалить\"/></form></div><br/>\n";
	}
}
else
{
$mid = intval($_POST['mid']);
$q = mysql_query("DELETE FROM `chat_meets` WHERE `id` = '".$mid."';");
	if(mysql_affected_rows() != 0)
	{
	echo "Встреча успешно удалена!<br/>\n";
	}
	else
	{
	echo "Встреча не найдена.<br/>\n";
	}
}
break;

default:
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"moder.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;handler\">\n";
echo "[Пользователи]<br/>\n";
echo "Никнейм:<br/>\n";
echo "<input name=\"nickname\" maxlength=\"20\" title=\"nickname\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select name=\"translit\">\n";
echo "<option value=\"no\">Нет</option>\n";
echo "<option value=\"yes\">Да</option></select><br/>\n";
echo "Время пинка (сек):<br/>\n";
echo "<select name=\"time\">\n";
echo "<option value=\"60\" selected=\"selected\">60</option>\n";
echo "<option value=\"90\">90</option>\n";
echo "<option value=\"300\">300</option>\n";
echo "<option value=\"43200\">43200</option>\n";
echo "<option value=\"86400\">86400</option>\n";
echo "<option value=\"172800\">172800</option>\n";
echo "</select><br/>\n";
echo "Причина:<br/>\n";
echo "<input name=\"reason\" maxlength=\"200\" title=\"reason\"/><br/>\n";
echo "Действие:<br/>\n";
echo "<select name=\"mod\">\n";
echo "<option value=\"0\" selected=\"selected\">Сменить статус</option>\n";
echo "<option value=\"1\">Пинок</option>\n";
echo "</select><br/>\n";
echo "<input type=\"submit\" value=\"OK\"/></form></div><br/>\n";
//echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=search\">Поиск по ID</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers\">Все пользователи</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist\">Список \"выпнутых\"</a><br/>\n";
echo "---<br/>\n";
echo "[Комнаты]<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=editroom\">Изменить топик</a><br/>\n";
//echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=clear\">Очистить комнаты</a><br/>\n";
echo "---<br/>\n";
echo "[Прочее]<br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addnews\">Добавить новость</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=delnews\">Удалить новость</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addmeet\">Добавить встречу</a><br/>\n";
echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=delmeet\">Удалить встречу</a><br/>\n";
break;
}
if(!empty($mod)) echo "<a href=\"moder.php?id=$id&amp;password=$password&amp;ver=html\">Модерка</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</div></body></html>";
break;
}
?>