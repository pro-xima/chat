<?php
error_reporting(0);

include("../config.php");
include("../includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `posts`, `gbalans` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$posts = mysql_result($q, 0, 'posts');
$gbalans = mysql_result($q, 0, 'gbalans');

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Кости\"><p align=\"left\">\n";

if($posts < 50)
{
echo "Чтобы попасть в данную игру, Вам необходимо набрать минимум 50 постов в чате.<br/>\n";
echo "<br/><a href=\"../menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
exit();
}

if(isset($_GET['case']))
{
$case = $_GET['case'];
}
else
{
$case = "";
}

switch($case)
{
case 'rules':
echo <<< END
<b>Правила</b><br/>
Чтобы участвовать в игре, вам необходимо набрать минимум 50 постов в чате.<br/>
Вам нужно ввести ставку и нажать "Бросить".<br/>
Ставка не должна быть больше количества постов, которое у вас есть.<br/>
Если за бросок Вы заработаете очков больше, чем бот, то сумма ставки прибавится к вашему количеству постов, в противном случае посты наоборот отнимутся.<br/>
END;
break;

case 'top':
$sql = mysql_query("SELECT `nickname`, `gbalans` FROM `chat_users` ORDER BY `gbalans` DESC LIMIT 10;");
echo "<b>TOP ".mysql_num_rows($sql)." азартных пользователей</b><br/>\n";

$c = 1;

while($user = mysql_fetch_array($sql))
{
echo "$c. ".$user['nickname']." - ".$user['gbalans']."<br/>";
$c++;
}
break;

case 'game':
$rate = intval($_POST['rate']);

	if($rate == 0)
	{
	echo "Играть можно минимум на 1 пост.<br/>\n";
	break;
	}

	if($rate > $posts)
	{
	echo "Вы не можете ставить постов больше, чем у Вас на самом деле есть.<br/>\n";
	break;
	}

	if($rate < 0)
	{
	echo "Ставка не может быть меньше нуля!<br/>\n";
	break;
	}

	if($rate > 5000)
	{
	echo "Извините, но ставки выше 5000 постов не принимаются.<br/>\n";
	break;
	}

$bot = array(rand(2, 12), rand(2, 12));
$player = array(rand(2, 12), rand(2, 12));

if(array_sum($bot) < array_sum($player))
{
echo "Поздравляем!<br/>\n";
echo "Вы выиграли ".$rate." постов.<br/>\n";
echo "Бот бросил <u>".$bot[0]."</u> и <u>".$bot[1]."</u>.<br/>\n";
echo "А Вы бросили <u>".$player[0]."</u> и <u>".$player[1]."</u><br/>\n";
echo "Ваши посты: <u>".($posts + $rate)."</u><br/>\n";
echo "Игровой баланс: <u>".($gbalans + $rate)."</u><br/>\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate$ref\" value=\"".$rate."\" format=\"*N\" size=\"5\"/><br/>";
echo "<anchor>[Бросить]<go href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml&amp;case=game\" method=\"post\">\n";
echo "<postfield name=\"rate\" value=\"$(rate$ref)\"/>\n";
echo "</go></anchor><br/>\n";
mysql_query("UPDATE `chat_users` SET `posts` = ".$posts." + '".$rate."', `gbalans` = ".$gbalans." + '".$rate."' WHERE `id` = '".$id."';");
}
else
{
echo "Проигрыш.<br/>\n";
echo "Вы проиграли ".$rate." постов.<br/>\n";
echo "Бот бросил <u>".$bot[0]."</u> и <u>".$bot[1]."</u>.<br/>\n";
echo "А Вы бросили <u>".$player[0]."</u> и <u>".$player[1]."</u><br/>\n";
echo "Ваши посты: <u>".($posts - $rate)."</u><br/>\n";
echo "Игровой баланс: <u>".($gbalans - $rate)."</u><br/>\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate$ref\" value=\"".$rate."\" format=\"*N\" size=\"5\"/><br/>";
echo "<anchor>[Бросить]<go href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml&amp;case=game\" method=\"post\">\n";
echo "<postfield name=\"rate\" value=\"$(rate$ref)\"/>\n";
echo "</go></anchor><br/>\n";
mysql_query("UPDATE `chat_users` SET `posts` = ".$posts." - '".$rate."', `gbalans` = ".$gbalans." - '".$rate."' WHERE `id` = '".$id."';");
}
break;

default:
echo "Ваши посты: <u>".$posts."</u><br/>\n";
echo "Игровой баланс: <u>".$gbalans."</u><br/>\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate$ref\" value=\"5\" format=\"*N\" size=\"5\"/><br/>";
echo "<anchor>[Бросить]<go href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml&amp;case=game\" method=\"post\">\n";
echo "<postfield name=\"rate\" value=\"$(rate$ref)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml&amp;case=rules\">Правила</a><br/>\n";
echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml&amp;case=top\">Самые азатные</a><br/>\n";
break;
}

if(!empty($case)) echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=wml\">Кости</a><br/>\n";
echo "<br/><a href=\"../menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `posts`, `gbalans` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

$posts = mysql_result($q, 0, 'posts');
$gbalans = mysql_result($q, 0, 'gbalans');

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Кости</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }\n";
echo "div.form { background-color: $form_color }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

if($posts < 50)
{
echo "Чтобы попасть в данную игру, Вам необходимо набрать минимум 50 постов в чате.<br/>\n";
echo "<br/><a href=\"../menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
exit();
}

if(isset($_GET['case']))
{
$case = $_GET['case'];
}
else
{
$case = "";
}

switch($case)
{
case 'rules':
echo <<< END
<b>Правила</b><br/>
Чтобы участвовать в игре, вам необходимо набрать минимум 50 постов в чате.<br/>
Вам нужно ввести ставку и нажать "Бросить".<br/>
Ставка не должна быть больше количества постов, которое у вас есть.<br/>
Если за бросок Вы заработаете очков больше, чем бот, то сумма ставки прибавится к вашему количеству постов, в противном случае посты наоборот отнимутся.<br/>
END;
break;

case 'top':
$sql = mysql_query("SELECT `nickname`, `gbalans` FROM `chat_users` ORDER BY `gbalans` DESC LIMIT 10;");
echo "<b>TOP ".mysql_num_rows($sql)." азартных пользователей</b><br/>\n";

$c = 1;

while($user = mysql_fetch_array($sql))
{
echo "$c. ".$user['nickname']." - ".$user['gbalans']."<br/>";
$c++;
}
break;

case 'game':
$rate = intval($_POST['rate']);

	if($rate == 0)
	{
	echo "Играть можно минимум на 1 пост.<br/>\n";
	break;
	}

	if($rate > $posts)
	{
	echo "Вы не можете ставить постов больше, чем у Вас на самом деле есть.<br/>\n";
	break;
	}

	if($rate < 0)
	{
	echo "Ставка не может быть меньше нуля!<br/>\n";
	break;
	}

	if($rate > 5000)
	{
	echo "Извините, но ставки выше 5000 постов не принимаются.<br/>\n";
	break;
	}

$bot = array(rand(2, 12), rand(2, 12));
$player = array(rand(2, 12), rand(2, 12));
if(array_sum($bot) < array_sum($player))
{
echo "Поздравляем!<br/>\n";
echo "Вы выиграли ".$rate." постов.<br/>\n";
echo "Бот бросил <u>".$bot[0]."</u> и <u>".$bot[1]."</u>.<br/>\n";
echo "А Вы бросили <u>".$player[0]."</u> и <u>".$player[1]."</u><br/>\n";
echo "Ваши посты: <u>".($posts + $rate)."</u><br/>\n";
echo "Игровой баланс: <u>".($gbalans + $rate)."</u><br/>\n";
echo "<div class=\"form\">\n";
echo "<form action=\"dice.php?id=$id&amp;password=$password&amp;ver=html&amp;case=game\" method=\"post\">\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate\" value=\"".$rate."\" size=\"5\"/><br/>";
echo "<input type=\"submit\" value=\"Бросить\" /></form></div>\n";
mysql_query("UPDATE `chat_users` SET `posts` = ".$posts." + '".$rate."', `gbalans` = ".$gbalans." + '".$rate."' WHERE `id` = '".$id."';");
}
else
{
echo "Проигрыш.<br/>\n";
echo "Вы проиграли ".$rate." постов.<br/>\n";
echo "Бот бросил <u>".$bot[0]."</u> и <u>".$bot[1]."</u>.<br/>\n";
echo "А Вы бросили <u>".$player[0]."</u> и <u>".$player[1]."</u><br/>\n";
echo "Ваши посты: <u>".($posts - $rate)."</u><br/>\n";
echo "Игровой баланс: <u>".($gbalans - $rate)."</u><br/>\n";
echo "<div class=\"form\">\n";
echo "<form action=\"dice.php?id=$id&amp;password=$password&amp;ver=html&amp;case=game\" method=\"post\">\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate\" value=\"".$rate."\" size=\"5\"/><br/>";
echo "<input type=\"submit\" value=\"Бросить\" /></form></div>\n";
mysql_query("UPDATE `chat_users` SET `posts` = ".$posts." - '".$rate."', `gbalans` = ".$gbalans." - '".$rate."' WHERE `id` = '".$id."';");
}
break;

default:
echo "Ваши посты: <u>".$posts."</u><br/>\n";
echo "Игровой баланс: <u>".$gbalans."</u><br/>\n";
echo "<div class=\"form\">\n";
echo "<form action=\"dice.php?id=$id&amp;password=$password&amp;ver=html&amp;case=game\" method=\"post\">\n";
echo "Ваша ставка:<br/>\n";
echo "<input name=\"rate\" value=\"".$rate."\" size=\"5\"/><br/>";
echo "<input type=\"submit\" value=\"Бросить\" /></form></div>\n";
echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=html&amp;case=rules\">Правила</a><br/>\n";
echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=html&amp;case=top\">Самые азатные</a><br/>\n";
break;
}

if(!empty($case)) echo "<a href=\"dice.php?id=$id&amp;password=$password&amp;ver=html\">Кости</a><br/>\n";
echo "<br/><a href=\"../menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>