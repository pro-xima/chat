<?
//BOT FOR WICKED QUIZ

//GET TIME
$fd = fopen("bots/second_bot/time.dat", "r");
if(!$fd) return;
$buff_time = intval(fgets($fd));
fclose($fd);

//GET ACTION
$fd = fopen("bots/second_bot/action.dat", "r");
if(!$fd) $buff_action = "unknown";
else $buff_action = fgets($fd);
fclose($fd);

if($buff_time < time() && $buff_action != 0)
{
if($buff_action != 0) $action = 3;
}
else
{
if($buff_action == 0 && ($buff_time - time() < 0)) $action = 0;
if($buff_action == 1 && ($buff_time - time() < 135)) $action = 1;
if($buff_action == 2 && ($buff_time - time() < 75)) $action = 2;
if($buff_action == 3 && ($buff_time - time() < 15)) $action = 3;
}

//FIRST START
if($buff_time == 0) $action = 0;

switch($action)
{
//NEW QUESTION
case '0':
$sql = mysql_query("SELECT * FROM `chat_questions` ORDER BY RAND() LIMIT 1;");
$ques_arr = mysql_fetch_array($sql);
$question = $ques_arr['question'];
$answer = $ques_arr['answer'];
$tran_answer = $ques_arr['translit'];
$answer = iconv('utf-8', 'windows-1251', $answer);
$length = strlen($answer);
$answer = iconv('windows-1251', 'utf-8', $answer);

$question = "$question (".($length + 2)." букв, да не, напиздил $length букв или ".rand(2, 8).", не помню)";

mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$question."', '0', '".date("H:i:s")."', ".time().");");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");

$fd = fopen("bots/second_bot/question.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, $question);
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/answer.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, $answer);
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/translit.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, $tran_answer);
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/action.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, "1");
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/time.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + 180 + $intervals[1])); //TIME FOR ANSWER
flock($fd, LOCK_UN);
fclose($fd);
break;

//FIRST HELP
case '1':
$fd = fopen("bots/second_bot/answer.dat", "r");
$answer = fgets($fd);
fclose($fd);

$answer = iconv('utf-8', 'windows-1251', $answer);
$help = substr($answer, 0, 1);
$answer = iconv('windows-1251', 'utf-8', $answer);
$help = iconv('windows-1251', 'utf-8', $help);
$help = "Подсказка, дебилы: $help...";

mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$help."', '0', '".date("H:i:s")."', ".time().");");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");

$fd = fopen("bots/second_bot/action.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, "2");
flock($fd, LOCK_UN);
fclose($fd);
break;

//SECOND HELP
case '2':
$fd = fopen("bots/second_bot/answer.dat", "r");
$answer = fgets($fd);
fclose($fd);

$answer = iconv('utf-8', 'windows-1251', $answer);
$help = substr($answer, 0, 2);
$answer = iconv('windows-1251', 'utf-8', $answer);
$help = iconv('windows-1251', 'utf-8', $help);
$help = "Подсказка нах: $help...";

mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$help."', '0', '".date("H:i:s")."', ".time().");");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");

$fd = fopen("bots/second_bot/action.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, "3");
flock($fd, LOCK_UN);
fclose($fd);
break;

//THE ANSWER WAS NOT
case '3':
$fd = fopen("bots/second_bot/answer.dat", "r");
$answer = fgets($fd);
fclose($fd);
$message = "Время истекло, кретины! А нужно было сказать: <b>$answer</b>. Идиоты, задам следующий вопрос через ".$intervals[1]." секунд!";
mysql_query("INSERT INTO `chat".$rid."` VALUES(0, '4', '".$bots[2]."', '".$message."', '0', '".date("H:i:s")."', ".time().");");
mysql_query("UPDATE `chat_users` SET `posts` = `posts` + 1 WHERE `id` = 2;");

$fd = fopen("bots/second_bot/time.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + $intervals[1])); //NEXT QUESTION
flock($fd, LOCK_UN);
fclose($fd);

$fd = fopen("bots/second_bot/action.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, "0");
flock($fd, LOCK_UN);
fclose($fd);
break;
}
?>