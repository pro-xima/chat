<?php
define("MYSQLHOST", "localhost");
define("DBNAME", "");
define("DBUSER", "");
define("DBPASS", "");

//PROTECTION
if(strpos($_SERVER['HTTP_USER_AGENT'], "'") !== false) die();
if(substr($_SERVER['HTTP_USER_AGENT'], 0 , 7) == "SamSunf") die();
if(preg_match("'Nokia(\d{3})/'", $_SERVER['HTTP_USER_AGENT'])) die();

$dbcnx = mysql_connect(MYSQLHOST, DBUSER, DBPASS);

if (!$dbcnx)
{
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

$mysql_error = mysql_error();

echo <<< END
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.3//EN" "http://www.wapforum.org/DTD/wml13.dtd">
<wml>
<card id="error" title="Error">
<p align="left">
&#x418;&#x437;&#x432;&#x438;&#x43D;&#x438;&#x442;&#x435;, &#x43D;&#x43E; &#x432; &#x434;&#x430;&#x43D;&#x43D;&#x44B;&#x439; &#x43C;&#x43E;&#x43C;&#x435;&#x43D;&#x442; &#x431;&#x430;&#x437;&#x430; &#x434;&#x430;&#x43D;&#x43D;&#x44B;&#x445; &#x43D;&#x435;&#x434;&#x43E;&#x441;&#x442;&#x443;&#x43F;&#x43D;&#x430;!<br/>
<a href="http://ili.wab.ru">ili.wab.ru</a><br/>
</p>
</card>
</wml>
END;
exit();
}

if (!mysql_select_db(DBNAME, $dbcnx))
{
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

$mysql_error = mysql_error();

echo <<< END
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.3//EN" "http://www.wapforum.org/DTD/wml13.dtd">
<wml>
<card id="error" title="Error">
<p align="left">
&#x418;&#x437;&#x432;&#x438;&#x43D;&#x438;&#x442;&#x435;, &#x43D;&#x43E; &#x432; &#x434;&#x430;&#x43D;&#x43D;&#x44B;&#x439; &#x43C;&#x43E;&#x43C;&#x435;&#x43D;&#x442; &#x431;&#x430;&#x437;&#x430; &#x434;&#x430;&#x43D;&#x43D;&#x44B;&#x445; &#x43D;&#x435;&#x434;&#x43E;&#x441;&#x442;&#x443;&#x43F;&#x43D;&#x430;!<br/>
<a href="http://ili.wab.ru">ili.wab.ru</a><br/>
</p>
</card>
</wml>
END;
exit();
}

//SWITCH VERSION
if(isset($_GET['ver']))
{
$ver = $_GET['ver'];
}
else
{
$ver = "";
}

if($ver != "wml" && $ver != "html")
{
$ver = "wml";
}

//COLORS FOR HTML VERSION
if($_GET['ver'] == "html")
{
        if(!isset($_COOKIE['theme']))
        {
        $font = "sans-serif";
        $color = "#000000";
        $background = "#FFF68F";
        $links = "blue";
        $form_color = "#FFC125";
        }
        else
        {
        include("themes_switch.php");
        }


$favicon = "favicon.ico";
}

if(!function_exists('iconv'))
{
include("./includes/functions/iconv.function");
}

//UNLIM ROOMS
$wicked_quiz = 3;
$unlim = 4;

// GZip Include
include("./includes/functions/gzip.function");

?>