<?php
error_reporting(0);

include("config.php");
include("./includes/constants/add");
include("./includes/".$ver."/banned");

$bots = file("bots/bots.dat");

$nocache = rand(10000, 99999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `kick`, `moder`, `reason`, `ban` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
else
{
$user = mysql_fetch_array($q);
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$ban = $user['ban'];
}
//END AUTH

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>".VERSION_ERROR."<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `kick`, `moder`, `reason`, `ban`, `level`, `translit`, `fsize` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
else
{
$user = mysql_fetch_array($q);
$kick = $user['kick'];
$moder = $user['moder'];
$reason = $user['reason'];
$ban = $user['ban'];
$level = $user['level'];
$translit = $user['translit'];
$fsize = $user['fsize'];
}
//END AUTH

$key = trim(mysql_escape_string($_GET['key']));

if(empty($key)) $key = public;

if($kick > time())
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Вы временно заблокированы модератором <u>$moder</u> на <u>".($kick - time())."</u> сек.<br/>\n";
echo "Причина: $reason<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `intim` = '".$online."', `key` = '".$key."', `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Сказать</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: ".$fsize."; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color." }
</style></head><body>";

if($fsize == 0)
{
$fsize = "small";
}
if($fsize == 1)
{
$fsize = "normal";
}
if($fsize == 2)
{
$fsize = "large";
}

echo "<div class=\"form\">\n";
echo "<form action=\"intim.php?id=$id&amp;password=$password&amp;ver=html&amp;key=$key&amp;nocache=$nocache\" method=\"post\">\n";
echo "Сообщение:<br/>\n";
echo "<input type=\"text\" name=\"msg\" maxlength=\"300\" value=\"\"/><br/>\n";
if($translit == 1)
{
echo "Транслитировать:\n";
echo "<input type=\"checkbox\" name=\"translit\" value=\"true\" checked=\"checked\" /><br/>\n";
}
if($level > 0)
{
echo "Аттрибуты:<br/>\n";
echo "<select name=\"attributs\" multiple=\"multiple\">\n";
if($level > 2) echo "<option value=\"bold\">Жирный</option>\n";
echo "<option value=\"underline\">Подчеркнутый</option>\n";
if($level == 4)echo "<option value=\"italic\">Курсив</option>\n";
echo "</select><br/>\n";
}
if($level == 4)
{
echo "Размер:<br/>\n";
echo "<select name=\"fsize\">\n";
echo "<option value=\"0\">Маленький</option>\n";
echo "<option value=\"1\" selected=\"selected\">Нормальный</option>\n";
echo "<option value=\"2\">Большой</option>\n";
echo "</select><br/>\n";
}
echo "<input type=\"submit\" value=\"Сказать\" /></form></div>\n";
echo "<a href=\"intim.php?id=$id&amp;password=$password&amp;ver=html&amp;key=$key&amp;nocache=$nocache\">Назад</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html&amp;nocache=$nocache\">Меню чата</a><br/>\n";

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</body></html>";
break;
}
?>