<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$nocache = rand(10000, 99999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"error\" title=\"Ошибка\" ontimer=\"menu.php?id=".$id."&amp;password=".$password."\">\n";
echo "<timer value=\"15\" />\n";
echo "<p align=\"left\">\n";
echo "<small>Данное меню предназначено только для HTML-версии.</small><br/>";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;nocache=$nocache\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec) - $headtime, 5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$favicon \" /><title>Загрузка фото</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color." }
</style></head><body>";

if(isset($_GET['case'])) $case = $_GET['case'];
else $case = "";

switch($case)
{
case 'add':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(file_exists("photos/".$id.".$photo_type"))
{
echo "Удалите сначала текущую фотографию.<br/>\n";
break;
}

if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form action=\"upload.php?id=".$id."&amp;password=".$password."&amp;case=add&amp;ver=html&amp;nocache=$nocache\" method=\"post\" enctype=\"multipart/form-data\">\n";
echo "<input type=\"file\" name=\"photo\" /><br />\n";
echo "<input type=\"hidden\" name=\"action\" value=\"upload\" />\n";
echo "<input type=\"submit\" value=\"Загрузить\" /><br /></form></div>\n";
}
else
{
	if(!is_uploaded_file($_FILES['photo']['tmp_name']))
	{
	echo "Ошибка при загрузке фотографии.<br />\n";
	break;
	}
	
	$propr = getimagesize($_FILES['photo']['tmp_name']);
	if(($propr[2] !== 1) && ($propr[2] !== 2) && ($propr[2] !== 3))
	{
	echo "Разрешены к закачке только GIF, JPEG или PNG фотографии.<br />\n";
	break;
	}
	
	if(filesize($_FILES['photo']['tmp_name']) > 1024 * 500)
	{
	echo "Размер фотографии превышает 500Kb.<br />\n";
	break;
	}


	if($propr[0] > 800 || $propr[1] > 800)
	{
	echo "Допускаются фотографии, размер которых не превышает 800x800.<br />\n";
	break;
	}

$photo_type = substr($_FILES['photo']['type'], 6);

$sql = mysql_query("UPDATE `chat_users` SET `photo` = '".$photo_type."' WHERE `id` = '".$id."';");
	if(copy($_FILES['photo']['tmp_name'], "photos/".$id.".".$photo_type.""))
	{
	echo "Фотография успешно загружена!<br/>\n";
	echo "<img src='photos/".$id.".".$photo_type."?".rand(1000000, 9999999)."' alt='photo' /><br />\n";
	}
	else
	{
	echo "При сохранении фотографии произошла ошибка.<br />\n";
	}
}
break;

case 'del':
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

if(!file_exists("photos/".$id.".$photo_type"))
{
echo "Фотографии не существует.<br/>\n";
break;
}

if(!isset($_GET['accept']))
{
echo "Вы уверены, что хотите удалить текущую фотографию?<br/>\n";
echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html&amp;case=del&amp;accept\">[Да]</a> <a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html\">[Нет]</a><br/>\n";
}
else
{
	if(unlink("photos/".$id.".$photo_type"))
	{
	echo "Фотография успешно удалена!<br/>\n";
	}
	else
	{
	echo "При удалении произошла ошибка...<br/>\n";
	}

}
break;

default:
$sql = mysql_query("SELECT `photo` FROM `chat_users` WHERE `id` = '".$id."';");
$photo_type = mysql_result($sql, 0);

echo "Загрузка фотографии через HTML-форму:<br/>\n";

	if(file_exists("photos/".$id.".$photo_type"))
	{
	echo "Для загрузки новой фотографии удалите текущую.<br/>\n";
	echo "Текущая фотография:<br/>\n";
	echo "<img src=\"photos/".$id.".$photo_type?".rand(10000, 99999)."\" alt=\"photo\" /><br/>\n";
	echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html&amp;case=del\">[Удалить]</a><br/>\n";
	}
	else
	{
	echo "Фотографии нет.<br/>\n";
	echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html&amp;case=add\">[Добавить]</a><br/>\n";
	}

echo "<a href=\"photo.php?id=$id&amp;password=$password&amp;ver=html\">[Загрузка по URL]</a><br/>\n";
break;
}

if(!empty($_GET['case'])) echo "<a href=\"upload.php?id=$id&amp;password=$password&amp;ver=html&amp;nocache=$nocache\">Фотография</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html&amp;nocache=$nocache\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</body></html>";
break;
}
?>