<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(0, 999999999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//USER DATA
$user = mysql_fetch_array($q);
$level = $user['level'];
$status = $user['status'];
$posts = $user['posts'];
$fsize = $user['fsize'];
//END USER DATA

if($fsize == 0)
{
$open_tag = "<small>";
$close_tag = "</small>";
}
if($fsize == 1)
{
$open_tag = "";
$close_tag = "";
}
if($fsize == 2)
{
$open_tag = "<big>";
$close_tag = "</big>";
}

/*
//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE
*/

//ONLINE IN CHAT
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time().";");
$online = mysql_result($query, 0);
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Онлайн ($online)\"><p align=\"left\">\n";

echo $open_tag;

//PUBLIC ROOMS
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 0 ORDER BY `position` ASC, `id` DESC;");

$in_embassies = 0;

$sql = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `type` = 2;");

while($array = mysql_fetch_array($sql))
{
$rid = $array['id'];

$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time()." AND `place` = '".$rid."';");
$in_embassies = $in_embassies + mysql_result($query, 0);
}

echo "<a href=\"embassies.php?id=$id&amp;password=$password&amp;ver=wml\">Посольства (".$in_embassies.")</a><br/>";

while($room = mysql_fetch_array($q))
{
$c = 0;
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` > ".time().";");
$inroom = mysql_result($query, 0);
	if($rid == $wicked_quiz or $rid == $unlim)
	{
	echo "<a href=\"unlim.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
	else
	{
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
$sql = mysql_query("SELECT `nickname`, `invisible` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = ".$rid.";");
	while($nick = mysql_fetch_array($sql))
	{
	if($level == 0 && $nick['invisible'] == 1) echo " ";
	else echo $nick['nickname'];
	if($level == 4 && $nick['invisible'] == 1) echo " (невидимый)";
	$c++;
		if($c != $inroom)
		{
		echo ", ";
		}
		else
		{
		echo "<br/>\n";
		}
	}
}
//END ROOMS

if(mysql_num_rows($q) == 0)
{
echo "[Пусто]<br/>\n";
}

echo "---<br/>\n";

//ROOMS FOR MODERATORS
if($level != 0)
{
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 1 ORDER BY `position` ASC;");

while($room = mysql_fetch_array($q))
{
$c = 0;
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid.";");
$inroom = mysql_result($query, 0);
	if($rid == $wicked_quiz or $rid == $unlim)
	{
	echo "<a href=\"unlim.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
	else
	{
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=wml\">".$rname." (".$inroom.")</a><br/>\n";
	}
$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = ".$rid.";");
	while($nick = mysql_fetch_array($sql))
	{
	echo $nick['nickname'];
	$c++;
		if($c != $inroom)
		{
		echo ", ";
		}
		else
		{
		echo "<br/>\n";
		}
	}
}
	if(mysql_num_rows($q) != 0)
	{
	echo "---<br/>\n";
	}
}
//END ROOMS

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");
$inmenu = mysql_result($q, 0);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");

echo "В меню: ".$inmenu."<br/>\n";
$c = 0;
while($nick = mysql_fetch_array($q))
{
echo $nick['nickname'];
$c++;
if($c != $inmenu)
{
echo ", ";
}
else
{
echo "<br/>\n";
}
}

echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Прихожая</a><br/>\n";

echo $close_tag;

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
	if(mysql_num_rows($q) == 0)
	{
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
	echo "<html><head>\n";
	echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
	echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
	echo "<style type=\"text/css\">\n";
	echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
	echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
	echo "</style></head><body>";
	echo "Ошибка авторизации!<br/>\n";
	list($msec, $sec) = explode(chr(32), microtime());
	echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
	echo "</body></html>";
	exit();
	}
//END AUTH

//USER DATA
$user = mysql_fetch_array($q);
$level = $user['level'];
$status = $user['status'];
$posts = $user['posts'];
$fsize = $user['fsize'];
//END USER DATA

if($fsize == 0)
{
$fsize = "small";
}
if($fsize == 1)
{
$fsize = "normal";
}
if($fsize == 2)
{
$fsize = "large";
}

/*
//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE
*/

//ONLINE IN CHAT
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time().";");
$online = mysql_result($query, 0);
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Онлайн ($online)</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: ".$fsize."; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

//PUBLIC ROOMS
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 0 ORDER BY `position` ASC, `id` DESC;");

$in_embassies = 0;

$sql = mysql_query("SELECT `id` FROM `chat_rooms` WHERE `type` = 2;");

while($array = mysql_fetch_array($sql))
{
$rid = $array['id'];

$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > ".time()." AND `place` = '".$rid."';");
$in_embassies = $in_embassies + mysql_result($query, 0);
}

echo "<a href=\"embassies.php?id=$id&amp;password=$password&amp;ver=html\">Посольства (".$in_embassies.")</a><br/>";

while($room = mysql_fetch_array($q))
{
$c = 0;
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid." AND `time` > ".time().";");
$inroom = mysql_result($query, 0);
	if($rid == $wicked_quiz or $rid == $unlim)
	{
	echo "<a href=\"unlim.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html\">".$rname." (".$inroom.")</a><br/>\n";
	}
	else
	{
	echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html\">".$rname." (".$inroom.")</a><br/>\n";
	}
$sql = mysql_query("SELECT `nickname`, `invisible` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = ".$rid.";");
	while($nick = mysql_fetch_array($sql))
	{
	if($level == 0 && $nick['invisible'] == 1) echo " ";
	else echo $nick['nickname'];
	if($level == 4 && $nick['invisible'] == 1) echo " (невидимый)";
	$c++;
		if($c != $inroom)
		{
		echo ", ";
		}
		else
		{
		echo "<br/>\n";
		}
	}
}
//END ROOMS

if(mysql_num_rows($q) == 0)
{
echo "[Пусто]<br/>\n";
}

echo "---<br/>\n";

//ROOMS FOR MODERATORS
if($level != 0)
{
$q = mysql_query("SELECT * FROM `chat_rooms` WHERE `type` = 1 ORDER BY `position` ASC;");

$count_rooms = 0;

while($room = mysql_fetch_array($q))
{
$c = 0;
$rid = $room['id'];
$rname = $room['name'];
$query = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `place` = ".$rid.";");
$inroom = mysql_result($query, 0);
echo "<a href=\"room.php?id=$id&amp;password=$password&amp;rid=$rid&amp;ver=html&amp;ref=$ref\">".$rname." (".$inroom.")</a><br/>\n";
$sql = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = ".$rid.";");
	while($nick = mysql_fetch_array($sql))
	{
	echo $nick['nickname'];
	$c++;
		if($c != $inroom)
		{
		echo ", ";
		}
		else
		{
		echo "<br/>\n";
		}
	}
$count_rooms++;
if(mysql_num_rows($sql) != 0) echo "<br/>\n";
}

	if($count_rooms != 0)
	{
	echo "---<br/>\n";
	}
}
//END ROOMS

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");
$inmenu = mysql_result($q, 0);
$q = mysql_query("SELECT `nickname` FROM `chat_users` WHERE `time` > '".time()."' AND `place` = 0;");

echo "В меню: ".$inmenu."<br/>\n";
$c = 0;
while($nick = mysql_fetch_array($q))
{
echo $nick['nickname'];
$c++;
	if($c != $inmenu)
	{
	echo ", ";
	}
	else
	{
	echo "<br/>\n";
	}
}

echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Прихожая</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>