<?php
//Opredelenie podderjki html
if(!array_key_exists('HTTP_ACCEPT', $_SERVER) || empty($_SERVER['HTTP_ACCEPT'])){ 
$_GET['ver'] = 'html';
} else {
if(preg_match('/(application|text)\/(vnd\.wap\.wml|vnd\.wap\.wmlc|vnd\.wap\.wmlscript|vnd\.wap\.wmlscriptc|vnd\.wap\.wbxml)/i', $_SERVER['HTTP_ACCEPT']) && !isset($_GET['ver'])) $_GET['ver'] = 'wml';
elseif (preg_match('/(application|text)\/(html|xhtml|xml|xhtml\+xml|xslt\+xml)/i', $_SERVER['HTTP_ACCEPT']) && !isset($_GET['ver'])) $_GET['ver'] = 'html';
elseif(!isset($_GET['ver'])) $_GET['ver'] = 'html';
}
//konec opr. html
list($msec, $sec) = explode(chr(32), microtime());
$headtime = $sec + $msec;

error_reporting(0);

include("config.php");
include("./includes/constants/index");
include("./includes/".$ver."/banned");

$nocache = rand(1000, 9999);

switch($ver)
{
case 'wml':
///////////////////////////////////////////////////////
//WML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\">\n<wml>\n";

$chat = file("chat.dat");
$logo = trim($chat[0]);
$message = trim($chat[1]);

$q = mysql_query("SELECT COUNT(`id`) FROM `chat_users` WHERE `time` >= ".time().";");
$online = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(`id`) FROM `chat_users`;");
$users = mysql_result($q, 0);

echo "<head><meta http-equiv=\"Cache-Control\" content=\"no-cache\" forua=\"true\"/></head>\n";
echo "<card id=\"index\" title=\"".TITLE."\"><p align=\"center\">\n";
echo "<!-- Developed by ILI -->\n";
if(!empty($logo)) echo "<img src=\"http://$logo\" alt=\"\" /><br/>\n";
if(!empty($message)) echo "$message<br/>\n";
echo "Ник:<br/>\n";
echo "<input type=\"text\" name=\"nickname$nocache\" maxlength=\"15\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select name=\"translit$nocache\">\n";
echo "<option value=\"false\">Нет</option>\n";
echo "<option value=\"true\">Да</option>\n";
echo "</select><br/>\n";
echo "Пароль:<br/>\n";
echo "<input type=\"password\" name=\"password$nocache\" maxlength=\"20\"/><br/>\n";
echo "<anchor>[Вход]<go href=\"menu.php?ver=wml&amp;nocache=$nocache\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"password\" value=\"$(password$nocache)\"/>\n";
echo "<postfield name=\"action\" value=\"auth\"/>\n";
echo "</go></anchor><br/>\n";
echo ONLINE.": <a href=\"inchat.php?ver=wml\">$online</a><br/>\n";
echo REG_USERS.": ".$users."<br/>\n";
echo "<a href=\"rules.php?ver=wml\">Правила</a><br/>\n";
echo "<a href=\"rules.php?ver=wml&amp;action=registration\">Регистрация</a><br/>\n";
echo "<a href=\"./?ver=html\">HTML</a> | WML<br/>\n";
echo "<a href=\"go.php\">".MAIN."</a><br/>\n";
echo "<br />\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<small>[".round(($sec + $msec) - $headtime, 5)."]</small><br/>\n";
echo "</p></card></wml>";
break;

case 'html':
///////////////////////////////////////////////////////
//HTML VERSION
///////////////////////////////////////////////////////

header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n";
echo "<link rel=\"shortcut icon\" href=\"$favicon\" /><title>".TITLE."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: $color; background-color: $background }\n";
echo "a:link, a:active, a:visited { text-decoration: underline; color : ".$links." }\n";
echo "div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }\n";
echo "div.form { background-color: $form_color }\n";
echo "</style></head>\n";
echo "<body><div style=\"text-align: center\">\n";

$chat = file("chat.dat");
$logo = trim($chat[0]);
$message = trim($chat[1]);

$q = mysql_query("SELECT COUNT(`id`) FROM `chat_users` WHERE `time` >= ".time().";");
$online = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(`id`) FROM `chat_users`;");
$users = mysql_result($q, 0);

if(!empty($logo)) echo "<img src=\"http://$logo\" alt=\"\" /><br/>\n";
if(!empty($message)) echo "$message<br/>\n";
echo "<div class=\"form\">\n";
echo "<form action=\"menu.php?ver=html&amp;nocache=$nocache\" method=\"post\">\n";
echo "Ник:<br/>\n";
echo "<input type=\"text\" name=\"nickname\" maxlength=\"15\" /><br/>\n";
echo "Транслитировать:\n";
echo "<input type=\"checkbox\" name=\"translit\" value=\"yes\" /><br/>\n";
echo "Пароль:<br/>\n";
echo "<input type=\"password\" name=\"password\" maxlength=\"20\" /><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"auth\" />\n";
echo "<input type=\"submit\" value=\"Вход\" /></form></div>\n";
echo ONLINE.": <a href=\"inchat.php?ver=html\">$online</a><br/>\n";
echo REG_USERS.": ".$users."<br/>\n";
echo "<a href=\"rules.php?ver=html\">Правила</a><br/>\n";
echo "<a href=\"rules.php?ver=html&amp;action=registration\">Регистрация</a><br/>\n";
echo "<a href=\"./?ver=wml\">WML</a> | HTML<br/>\n";
echo "<a href=\"go.php?ver=html\">".MAIN."</a><br/>\n";
echo "<br />\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<span style=\"font-size: small\">[".round(($sec + $msec) - $headtime, 5)."]</span><br/>\n";
echo "</div></body></html>";
break;
}
?>