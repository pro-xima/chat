<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$ref = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header ("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Error\" ontimer=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\"><timer value=\"15\" /><p align=\"left\">\n";
echo "Данное меню предназначено только для HTML-версии.<br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
//INSTALL THEME
if(isset($_GET['theme']))
{
setcookie ("theme", $_GET['theme'], time() + 3600 * 12 * 30, "/", "", 0);
header("Location: ".$_SERVER['PHP_SELF']."?id=".$_GET['id']."&password=".$_GET['password']."&ver=html");
die();
}

header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Темы</title>\n";
echo "<style type=\"text/css\">\n";
echo "body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }\n";
echo "a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }\n";
echo "</style></head><body><div style=\"text-align: left\">\n";

if(isset($_COOKIE['theme']))
{
if(!isset($_GET['theme'])) $theme = $_COOKIE['theme'];
$themes_array = array("blue", "violet", "gray", "black-and-white", "gold", "green", "red", "matrix");
$themes_names = array("Синяя", "Фиолетовая", "Серая", "Черно-белая", "Золото", "Зеленая", "Красная", "Матрица");
$theme = str_replace($themes_array, $themes_names, $theme);
if(empty($theme)) $theme = "Пользовательская";
echo "Текущая тема: <u>".$theme."</u><br/>\n";
}

echo "Выберите тему оформления:<br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=standart\">Стандартно</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=blue\">Синяя</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=violet\">Фиолетовая</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=gray\">Серая</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=black-and-white\">Черно-белая</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=gold\">Золото</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=green\">Зеленая</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=red\">Красная</a><br/>\n";
echo "<a href=\"themes.php?id=$id&amp;password=$password&amp;ver=html&amp;theme=matrix\">Матрица</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><span style=\"font-size: small\">[".round(($sec+$msec)-$headtime,5)."] sec</span><br/>\n";
echo "</div></body></html>";
break;
}
?>