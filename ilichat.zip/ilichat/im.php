<?
 header("Content-type:image/jpeg");
 $pic = $_GET["pic"];
 if(substr($pic,0,1)!=".")
  {
 if(preg_match("/\.gif$/i", $pic)) $old = imageCreateFromGif("$pic");
 if(preg_match("/\.jpg$|\.jpeg$|\.jpe$/i", $pic)) $old = imageCreateFromJpeg("$pic");
 if(preg_match("/\.png$/i", $pic)) $old = imageCreateFromPng("$pic");
  {
    $w = imageSX($old);
    $h = imageSY($old);
    $w_new=round(80); // ������ ��������
    $h_new=round(80); // ������ ��������
    $new = imageCreateTrueColor($w_new, $h_new);
    imageCopyResized($new, $old, 0, 0, 0, 0, $w_new, $h_new, $w, $h);
    imageJpeg($new,"","100");
  }
  }
?>