<?php
include("xml.php");
$cardid = "index";
$n = $_GET['n'];
function allfiles($path)
	{
	  return count(glob($path."/*")); 
	}


$path="photos/";
$o=opendir($path) or die("Запрещено! ".$path.$px);
while($f=readdir($o))
	{
	  if($f!="." and $f!="..")
		{
		  if(strpos($f,"jpg") or strpos($f,"gif"))$sk="<img src='im.php?pic=".$path."/".$f."' alt='..'/>";$link[]=$sk."<a href='".$path.$f."'>".substr($f,0,-4)."</a>[".round(filesize($path."/".$f)/1024)."kb]<br/>";$sk="";
		}
	}
echo $put."<br/>::::::<br/>Обьектов: ".count($link)."<br/>:::::::<br/>";
if($n=="")$n=0;
for($i=1; $i<=10; $i++)
	{
	  if(isset($link[$n])) echo $link[$n]; 
	  $n++;
	}
$off=$n-20; 
echo "<br/>[<a href='gallery.php?n=$off&amp;id=".$_GET['id']."&amp;password=".$_GET['password']."'>Назад</a>][<a href='gallery.php?n=$n&amp;id=".$_GET['id']."&amp;password=".$_GET['password']."'>Далее</a>]<br/>"; 
echo '[<a href="upload.php?id='.$_GET['id'].'&amp;password='.$_GET['password'].'&amp;ver=html&amp;case=add">Добавить</a>]<br/>';
echo '[<a href="menu.php?id='.$_GET['id'].'&amp;password='.$_GET['password'].'&amp;ver=wml">Меню чата</a>]'; 
echo $px; 
?>
