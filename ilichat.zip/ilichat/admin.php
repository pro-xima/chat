<?php
error_reporting(0);

include("config.php");
include("./includes/constants/admin");
include("./includes/".$ver."/banned");

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

$nocache = rand(10000, 99999);

$bots = file("bots/bots.dat");

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `level` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

$level = mysql_result($q, 0);

if($level != 4)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"menu.php?ver=wml&amp;id=$id&amp;password=$password\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Доступ запрещен<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"".TITLE."\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'edit':
case 'kick':
case 'ban':
case 'ipua':
case 'ip':
case 'deluser':
case 'search':
case 'allusers':
case 'bannedip':
case 'bannedipua':
case 'banned':
case 'kicklist':
case 'addroom':
case 'removeroom':
case 'editroom':
case 'uproom':
case 'clear':
case 'addnews':
case 'delnews':
case 'addmeet':
case 'delmeet':
case 'addjoke':
case 'addquestion':
case 'announcement':
case 'settings':
case 'renamebots':
case 'main_page':
case 'logs':
case 'antiban':
case 'addinsult':
case 'add_bad_answer':
case 'bots_intervals':
include("./includes/".$ver."/admin/".$mod);
break;

default:
echo "[Пользователи]<br/>\n";
echo "Никнейм:<br/>\n";
echo "<input name=\"nickname$nocache\" maxlength=\"20\" title=\"nickname\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select multiple=\"false\" name=\"translit$nocache\" value=\"no\">\n";
echo "<option value=\"no\">Нет</option>\n";
echo "<option value=\"yes\">Да</option></select><br/>\n";
echo "<anchor>[Редактировать]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=edit\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "Время пинка (сек):<br/>\n";
echo "<input name=\"time$nocache\" format=\"*N\" size=\"6\" maxlength=\"8\" title=\"time\"/><br/>\n";
echo "Причина:<br/>\n";
echo "<input name=\"reason$nocache\" maxlength=\"200\" title=\"reason\"/><br/>\n";
echo "<anchor>[Пнуть]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=kick\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "<postfield name=\"reason\" value=\"$(reason$nocache)\"/>\n";
echo "<postfield name=\"time\" value=\"$(time$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<anchor>[Забанить]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=ban\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<anchor>[Бан IP+UA]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=ipua\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<anchor>[Бан IP]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=ip\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<anchor>[Удалить]<go href=\"admin.php?nocache=$nocache&amp;ver=wml&amp;id=$id&amp;password=$password&amp;mod=deluser\" method=\"post\">\n";
echo "<postfield name=\"nickname\" value=\"$(nickname$nocache)\"/>\n";
echo "<postfield name=\"translit\" value=\"$(translit$nocache)\"/>\n";
echo "</go></anchor><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=search&amp;nocache=$nocache\">Поиск по ID</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=allusers\">Все пользователи</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=bannedip\">Список забаненных по IP</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=bannedipua\">Список забаненных по IP+UA</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=banned\">Список забаненных по нику</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=kicklist\">Список \"выпнутых\"</a><br/>\n";
echo "---<br/>\n";
echo "[Комнаты]<br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addroom&amp;nocache=$nocache\">Создать</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=removeroom&amp;nocache=$nocache\">Удалить</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=editroom&amp;nocache=$nocache\">Изменить</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=clear\">Очистить комнаты</a><br/>\n";
echo "---<br/>\n";
echo "[Прочее]<br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addnews&amp;nocache=$nocache\">Добавить новость</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=delnews&amp;nocache=$nocache\">Удалить новость</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addmeet&amp;nocache=$nocache\">Добавить встречу</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=delmeet&amp;nocache=$nocache\">Удалить встречу</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addjoke&amp;nocache=$nocache\">Добавить анекдот</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addquestion&amp;nocache=$nocache\">Добавить вопрос</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=addinsult&amp;nocache=$nocache\">Добавить оскорбление</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=add_bad_answer\">Добавить ответ бота</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=announcement&amp;nocache=$nocache\">Объявление в чат</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=settings&amp;nocache=$nocache\">Дополнительные настройки</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=main_page\">Логотип/Сообщение при входе</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=renamebots&amp;nocache=$nocache\">Ники ботов</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=bots_intervals&amp;nocache=$nocache\">Время постов ботов</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=logs&amp;nocache=$nocache\">Логи</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=wml\">Админка</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>\n";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//USER DATA
$user = mysql_fetch_array($q);
$id = $user['id'];
$nickname = $user['nickname'];
$level = $user['level'];
$status = $user['status'];
$time = $user['time'];
$fsize = $user['fsize'];
//END USER DATA

if($fsize == 0)
{
$fsize = "small";
}
if($fsize == 1)
{
$fsize = "normal";
}
if($fsize == 2)
{
$fsize = "large";
}

if($level != 4)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body><div style=\"text-align: left\">\n";
echo "Доступ запрещен<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</div></body></html>";
exit();
}

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0 WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: ".$fsize."; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body><div style=\"text-align: left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

if(isset($_GET['handler']))
{
$action = intval($_POST['mod']);

	switch($action)
	{
	case 0:
	$mod = "edit";
	break;

	case 1:
	$mod = "kick";
	break;

	case 2:
	$mod = "ban";
	break;

	case 3:
	$mod = "ipua";
	break;

	case 4:
	$mod = "ip";
	break;

	case 5:
	$mod = "deluser";
	break;
	}
}

switch($mod)
{
case 'edit':
case 'kick':
case 'ban':
case 'ipua':
case 'ip':
case 'deluser':
case 'search':
case 'allusers':
case 'bannedip':
case 'bannedipua':
case 'banned':
case 'kicklist':
case 'addroom':
case 'removeroom':
case 'editroom':
case 'uproom':
case 'clear':
case 'addnews':
case 'delnews':
case 'addmeet':
case 'delmeet':
case 'addjoke':
case 'addquestion':
case 'announcement':
case 'settings':
case 'renamebots':
case 'main_page':
case 'logs':
case 'antiban':
case 'addinsult':
case 'add_bad_answer':
case 'bots_intervals':
include("./includes/".$ver."/admin/".$mod);
break;

default:
echo "<div class=\"form\">\n";
echo "<form method=\"post\" action=\"admin.php?nocache=$nocache&amp;ver=html&amp;id=$id&amp;password=$password&amp;handler\">\n";
echo "[Пользователи]<br/>\n";
echo "Никнейм:<br/>\n";
echo "<input name=\"nickname\" maxlength=\"20\" title=\"nickname\"/><br/>\n";
echo "Транслитировать:<br/>\n";
echo "<select name=\"translit\">\n";
echo "<option value=\"no\">Нет</option>\n";
echo "<option value=\"yes\">Да</option></select><br/>\n";
echo "Время пинка (сек):<br/>\n";
echo "<input name=\"time\" size=\"6\" maxlength=\"8\" title=\"time\"/><br/>\n";
echo "Причина:<br/>\n";
echo "<input name=\"reason\" maxlength=\"200\" title=\"reason\"/><br/>\n";
echo "Действие:<br/>\n";
echo "<select name=\"mod\">\n";
echo "<option value=\"0\" selected=\"selected\">Редактировать</option>\n";
echo "<option value=\"1\">Пинок</option>\n";
echo "<option value=\"2\">Забанить</option>\n";
echo "<option value=\"3\">Забанить IP+UA</option>\n";
echo "<option value=\"4\">Забанить IP</option>\n";
echo "<option value=\"5\">Удалить</option></select><br/>\n";
echo "<input type=\"submit\" value=\"OK\"/></form></div><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=search\">Поиск по ID</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=allusers\">Все пользователи</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=bannedip\">Список забаненных по IP</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=bannedipua\">Список забаненных по IP+UA</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=banned\">Список забаненных по нику</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=kicklist\">Список \"выпнутых\"</a><br/>\n";
echo "---<br/>\n";
echo "[Комнаты]<br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addroom\">Создать</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=removeroom\">Удалить</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=editroom\">Изменить</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=clear\">Очистить комнаты</a><br/>\n";
echo "---<br/>\n";
echo "[Прочее]<br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addnews\">Добавить новость</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=delnews\">Удалить новость</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addmeet\">Добавить встречу</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=delmeet\">Удалить встречу</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addjoke\">Добавить анекдот</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addquestion\">Добавить вопрос</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=addinsult\">Добавить оскорбление</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=add_bad_answer\">Добавить ответ бота</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=announcement\">Объявление в чат</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=settings\">Дополнительные настройки</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=main_page\">Логотип/Сообщение при входе</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=renamebots\">Ники ботов</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=bots_intervals&amp;nocache=$nocache\">Время постов ботов</a><br/>\n";
echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=logs\">Логи</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"admin.php?id=$id&amp;password=$password&amp;ver=html\">Админка</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime,5)."] sec</small><br/>\n";
echo "</div></body></html>";
break;
}
?>