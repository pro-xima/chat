<?
//BOT "JOKER"

//GET TIME
$fd = fopen("bots/jtime.dat", "r");
if(!$fd) return;
$joke_time = intval(fgets($fd));
fclose($fd);

if($joke_time < time() && $joke_time != 0)
{
$sql = mysql_query("SELECT `joke` FROM `chat_jokes` ORDER BY RAND() LIMIT 1;");
$joke = mysql_result($sql, 0);

$sql = mysql_query("SELECT `id` FROM `chat_rooms`;");

while($room_id = mysql_fetch_array($sql))
{
mysql_query("INSERT INTO `chat".$room_id['id']."` VALUES(0, '3', '".$bots[1]."', '".$joke."', '0', '".date("H:i:s")."',".time().");");
}

$fd = fopen("bots/jtime.dat", "w");
flock($fd, LOCK_EX);
$puts = fputs($fd, (time() + $intervals[2])); //NEXT JOKE
flock($fd, LOCK_UN);
fclose($fd);
}
?>