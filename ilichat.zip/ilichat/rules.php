<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$nocache = rand(1000, 9999);

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type: text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

if(isset($_GET['action']))
{
$action = $_GET['action'];
}
else
{
$action = "";
}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Правила\"><p align=\"left\"><small>\n";
echo "<b>Запрещено:</b><br/>\n";
echo "1. Оскорбление участников чата, модераторов и создателей чата.<br/>
2. Употребление ненормативной лексики в любом контексте.<br/>
3. Запрещен плагиат ников.<br/>
4. Пропагандирование насилия, националистических и политических лозунгов, разжигание межнациональной розни, преднамеренного создания кофликтных ситуаций.<br/>
5. Флудить.<br/>
6. Рекламирование других ресурсов без согласования с Администрацией чата.<br/>
<br/>
При нарушении правил модераторы имеют право блокировать Вас.<br/>\n";
if($action == "registration")
{
echo "<a href=\"registration.php?ver=wml&amp;ref=$nocache\">Согласен</a><br/>
<a href=\"index.php?ver=wml\">Не согласен</a><br/>\n";
}
else
{
echo "<a href=\"index.php?ver=wml\">Назад</a><br/>\n";
}
echo "</small></p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

if(isset($_GET['action']))
{
$action = $_GET['action'];
}
else
{
$action = "";
}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Правила</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body><div style=\"text-align: left\">";
echo "<b>Запрещено:</b><br/>\n";
echo "1. Оскорбление участников чата, модераторов и создателей чата.<br/>
2. Употребление ненормативной лексики в любом контексте.<br/>
3. Запрещен плагиат ников.<br/>
4. Пропагандирование насилия, националистических и политических лозунгов, разжигание межнациональной розни, преднамеренного создания кофликтных ситуаций.<br/>
5. Флудить.<br/>
6. Рекламирование других ресурсов без согласования с Администрацией чата.<br/>
<br/>
При нарушении правил модераторы имеют право блокировать Вас.<br/>\n";
if($action == "registration")
{
echo "<a href=\"registration.php?ver=html&amp;ref=$nocache\">Согласен</a><br/>
<a href=\"index.php?ver=html\">Не согласен</a><br/>\n";
}
else
{
echo "<a href=\"index.php?ver=html\">Назад</a><br/>\n";
}
echo "</div></body></html>";
break;
}
?>