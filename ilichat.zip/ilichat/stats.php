<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$ref = rand(1000, 9999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Статистика\"><p align=\"left\">\n";

if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'top':
echo "10-ка лучших:<br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` ORDER BY `posts` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$posts = $user['posts'];
echo "$c. $nickname - $posts<br/>\n";
$c++;
}
break;

case 'clevers':
echo "Самые умные:<br/>\n";
$q = mysql_query("SELECT `nickname`, `answers` FROM `chat_users` ORDER BY `answers` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$answers = $user['answers'];
echo "$c. $nickname - $answers<br/>\n";
$c++;
}
break;

case 'players':
echo "Самые азартные:<br/>\n";
$q = mysql_query("SELECT `nickname`, `gbalans` FROM `chat_users` ORDER BY `gbalans` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$gbalans = $user['gbalans'];
echo "$c. $nickname - $gbalans<br/>\n";
$c++;
}
break;

case 'stats':
$q = mysql_query("SELECT COUNT(*) FROM `chat_users`;");
$users = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat`;");
$posts = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `kick` > ".time().";");
$kicks = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_banned`;");
$banned = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 0;");
$small_fsize = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 1;");
$medium_fsize = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 2;");
$big_fsize = mysql_result($q, 0);

$small_fsize = sprintf("%01.1f%s", $small_fsize/$users * 100, "%");
$medium_fsize = sprintf("%01.1f%s", $medium_fsize/$users * 100, "%");
$big_fsize = sprintf("%01.1f%s", $big_fsize/$users * 100, "%");

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `security` = 0;");
$off_security = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `security` = 1;");
$on_security = mysql_result($q, 0);

$off_security = sprintf("%01.1f%s", $off_security/$users * 100, "%");
$on_security = sprintf("%01.1f%s", $on_security/$users * 100, "%");

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `smiles` = 0;");
$smiles_on = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `smiles` != 0;");
$smiles_off = mysql_result($q, 0);

$smiles_on = sprintf("%01.1f%s", $smiles_on/$users * 100, "%");
$smiles_off = sprintf("%01.1f%s", $smiles_off/$users * 100, "%");

echo "В чате зарегистрировано <b>$users</b> пользователей";
if($kicks != 0) echo ", <b>$kicks</b> из которых выпнуто";
if($banned != 0) echo " и <b>$banned</b> из них забанено";
echo ".\n<br/>";
echo "<b>$small_fsize</b> используют маленький шрифт, <b>$medium_fsize</b> - средний, а большой <b>$big_fsize</b>.<br/>\n";
echo "<b>$on_security</b> включили систему безопастности, а <b>$off_security</b> выключили.<br/>\n";
echo "У <b>$smiles_on</b> участников чата включены смайлы, а у <b>$smiles_off</b> выключены.<br/>\n";
break;

default:
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=top\">10 лучших!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=clevers\">10 самых умных!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=players\">10 самых азартных!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml&amp;mod=stats\">Общая статистика чата</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=wml\">Статистика</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime, 5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT `id` FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");
if(mysql_num_rows($q) == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Статистика</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";


if(isset($_GET['mod']))
{
$mod = $_GET['mod'];
}
else
{
$mod = "";
}

switch($mod)
{
case 'top':
echo "10-ка лучших:<br/>\n";
$q = mysql_query("SELECT `nickname`, `posts` FROM `chat_users` ORDER BY `posts` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$posts = $user['posts'];
echo "$c. $nickname - $posts<br/>\n";
$c++;
}
break;

case 'clevers':
echo "Самые умные:<br/>\n";
$q = mysql_query("SELECT `nickname`, `answers` FROM `chat_users` ORDER BY `answers` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$answers = $user['answers'];
echo "$c. $nickname - $answers<br/>\n";
$c++;
}
break;

case 'players':
echo "Самые азартные:<br/>\n";
$q = mysql_query("SELECT `nickname`, `gbalans` FROM `chat_users` ORDER BY `gbalans` DESC LIMIT 10;");

$c = 1;

while($user = mysql_fetch_array($q))
{
$nickname = $user['nickname'];
$gbalans = $user['gbalans'];
echo "$c. $nickname - $gbalans<br/>\n";
$c++;
}
break;

case 'stats':
$q = mysql_query("SELECT COUNT(*) FROM `chat_users`;");
$users = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat`;");
$posts = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `kick` > ".time().";");
$kicks = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_banned`;");
$banned = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 0;");
$small_fsize = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 1;");
$medium_fsize = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `fsize` = 2;");
$big_fsize = mysql_result($q, 0);

$small_fsize = sprintf("%01.1f%s", $small_fsize/$users * 100, "%");
$medium_fsize = sprintf("%01.1f%s", $medium_fsize/$users * 100, "%");
$big_fsize = sprintf("%01.1f%s", $big_fsize/$users * 100, "%");

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `security` = 0;");
$off_security = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `security` = 1;");
$on_security = mysql_result($q, 0);

$off_security = sprintf("%01.1f%s", $off_security/$users * 100, "%");
$on_security = sprintf("%01.1f%s", $on_security/$users * 100, "%");

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `smiles` = 0;");
$smiles_on = mysql_result($q, 0);

$q = mysql_query("SELECT COUNT(*) FROM `chat_users` WHERE `smiles` != 0;");
$smiles_off = mysql_result($q, 0);

$smiles_on = sprintf("%01.1f%s", $smiles_on/$users * 100, "%");
$smiles_off = sprintf("%01.1f%s", $smiles_off/$users * 100, "%");

echo "В чате зарегистрировано <b>$users</b> пользователей";
if($kicks != 0) echo ", <b>$kicks</b> из которых выпнуто";
if($banned != 0) echo " и <b>$banned</b> из них забанено";
echo ".\n<br/>";
echo "<b>$small_fsize</b> используют маленький шрифт, <b>$medium_fsize</b> - средний, а большой <b>$big_fsize</b>.<br/>\n";
echo "<b>$on_security</b> включили систему безопастности, а <b>$off_security</b> выключили.<br/>\n";
echo "У <b>$smiles_on</b> участников чата включены смайлы, а у <b>$smiles_off</b> выключены.<br/>\n";
break;

default:
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=top\">10 лучших!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=clevers\">10 самых умных!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=players\">10 самых азартных!</a><br/>\n";
echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html&amp;mod=stats\">Общая статистика чата</a><br/>\n";
break;
}

if(!empty($mod)) echo "<a href=\"stats.php?id=$id&amp;password=$password&amp;ver=html\">Статистика</a><br/>\n";
echo "<br/><a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
break;
}
?>