<?php
error_reporting(0);

include("config.php");
include("./includes/".$ver."/banned");

$ref = rand(1000, 9999);

list($msec, $sec) = explode(chr(32), microtime()); 
$headtime = $sec + $msec;

switch($ver)
{
////////////////////////////////////////////////////////
//WML VERSION
////////////////////////////////////////////////////////
case 'wml':
header("Content-type:text/vnd.wap.wml; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"ERROR\" ontimer=\"index.php?ver=wml\"><timer value=\"15\"/><p align=\"left\">\n";
echo "<small>Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</small></p></card></wml>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

$user = mysql_fetch_array($q);
$smiles = $user['smiles'];
$translit  = $user['translit'];
$msgs  = $user['msgs'];
$refresh = $user['refresh'];
$fsize = $user['fsize'];
$security  = $user['security'];
$default = $user['default'];
$emotions = $user['emotions'];
$system = $user['system'];
$gzip = $user['gzip'];

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\"><wml>\n";
echo "<card title=\"Настройки\"><p align=\"left\">\n";
if(!isset($_POST['action']))
{
echo "Смайлы:<br/>
<select name=\"smiles$ref\" value=\"$smiles\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
Транслит:<br/>
<select name=\"translit$ref\" value=\"$translit\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
Кол-во сообщений на странице:<br/>
<input type=\"text\" name=\"msgs$ref\" value=\"$msgs\" format=\"*N\" maxlength=\"2\" size=\"2\"/><br/>
Время обновления:<br/>
<input type=\"text\" name=\"refresh$ref\" value=\"$refresh\" format=\"*N\" maxlength=\"3\" size=\"3\"/><br/>
Шрифт:<br/>
<select name=\"fsize$ref\" value=\"$fsize\">
<option value=\"0\">Маленький</option>
<option value=\"1\">Средний</option>
<option value=\"2\">Большой</option>
</select><br/>
Система безопастности:<br/>
<select name=\"security$ref\" value=\"$security\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
Эмоции:<br/>
<select name=\"emotions$ref\" value=\"$emotions\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
По умолчанию сказать:<br/>
<select name=\"default$ref\" value=\"$default\">
<option value=\"0\">Всем</option>
<option value=\"1\">Приват</option>
</select><br/>
Сообщения системного бота:<br/>
<select name=\"system$ref\" value=\"$system\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
GZip сжатие:<br/>
<select name=\"gzip$ref\" value=\"$gzip\">
<option value=\"0\">Выкл.</option>
<option value=\"1\">Вкл.</option>
</select><br/>
<anchor>[Сохранить]<go href=\"settings.php?id=$id&amp;password=$password&amp;ref=$ref&amp;ver=wml\" method=\"post\">
<postfield name=\"smiles\" value=\"$(smiles$ref)\"/>
<postfield name=\"translit\" value=\"$(translit$ref)\"/>
<postfield name=\"msgs\" value=\"$(msgs$ref)\"/>
<postfield name=\"refresh\" value=\"$(refresh$ref)\"/>
<postfield name=\"fsize\" value=\"$(fsize$ref)\"/>
<postfield name=\"security\" value=\"$(security$ref)\"/>
<postfield name=\"emotions\" value=\"$(emotions$ref)\"/>
<postfield name=\"default\" value=\"$(default$ref)\"/>
<postfield name=\"system\" value=\"$(system$ref)\"/>
<postfield name=\"gzip\" value=\"$(gzip$ref)\"/>
<postfield name=\"action\" value=\"save\"/>
</go></anchor><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
}
else
{
$smiles = intval($_POST['smiles']);
$translit = intval($_POST['translit']);
$msgs = intval($_POST['msgs']);
$refresh = intval($_POST['refresh']);
$fsize = intval($_POST['fsize']);
$security = intval($_POST['security']);
$default = intval($_POST['default']);
$emotions = intval($_POST['emotions']);
$system = intval($_POST['system']);
$gzip = intval($_POST['gzip']);

$error = "";

if($smiles < 0 or $smile > 1) $error .= "Некорректное значение переключателя \"Смайлы\"!<br/>\n";
if($translit < 0 or $translit > 1) $error .= "Некорректное значение переключателя \"Транслит\"!<br/>\n";
if($msgs < 1 or $msgs > 99) $error .= "Количество сообщений на одной странице не может быть меньше 1 и больше 99!<br/>\n";
if($refresh < 1 or $refresh > 99) $error .= "Обновление страницы не может быть меньше 1 сек. и больше 300 сек.!<br/>\n";
if($fsize < 0 or $fsize > 2) $error .= "Некорректное значение переключателя \"Шрифт\"!<br/>\n";
if($security < 0 or $security > 1) $error .= "Некорректное значение переключателя \"Система безопастности\"!<br/>\n";
if($default < 0 or $default > 1) $error .= "Некорректное значение переключателя \"По умолчанию сказать\"!<br/>\n";
if($system < 0 or $system > 1) $error .= "Некорректное значение переключателя \"Сообщения системного бота\"!<br/>\n";
if($gzip < 0 or $gzip > 1) $error .= "Некорректное значение переключателя \"GZip сжатие\"!<br/>\n";

if(!empty($error))
{
echo $error;
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml&amp;ref=$ref\">Назад</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</p></card></wml>";
exit();
}

$sql = mysql_query("UPDATE `chat_users` SET `smiles` = '".$smiles."', `translit` = '".$translit."', `msgs` = '".$msgs."', `refresh` = '".$refresh."', `fsize` = '".$fsize."', `security` = '".$security."', `default` = '".$default."', `emotions` = '".$emotions."', `system` = '".$system."', `gzip` = '".$gzip."'  WHERE `id` = '".$id."';");

if($sql)
{
echo "Профиль успешно сохранен!<br/>\n";
}
else
{
echo "При сохранении произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}

echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=wml\">Меню чата</a><br/>\n";
}

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/><small>[".round(($sec+$msec)-$headtime, 5)."] sec</small><br/>\n";
echo "</p></card></wml>";
break;

////////////////////////////////////////////////////////
//HTML VERSION
////////////////////////////////////////////////////////
case 'html':
header ("Content-type: text/html; charset=utf-8");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-relative");

//AUTH
$id = intval($_GET['id']);
$password = mysql_escape_string($_GET['password']);
$q = mysql_query("SELECT * FROM `chat_users` WHERE `id` = '".$id."' AND `password` = '".$password."';");

if(mysql_affected_rows() == 0)
{
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>".$title."</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
</style></head><body>";
echo "Ошибка авторизации!<br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}
//END AUTH

//ONLINE
$online = time() + 60;
$update = mysql_query("UPDATE `chat_users` SET `time` = '".$online."', `place` = 0, `ip` = '".getenv('REMOTE_ADDR')."', `ua` = '".htmlspecialchars(getenv('HTTP_USER_AGENT'))."' WHERE `id` = '".$id."';");
//END ONLINE

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n";
echo "<html><head>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"/>\n";
echo "<link rel=\"shortcut icon\" href=\"$icon\" /><title>Профиль</title>\n";
echo "<style type=\"text/css\">
body { font-weight: normal; font-size: normal; font-family: ".$font."; color: ".$color."; background-color: ".$background." }
a:link,a:active,a:visited { text-decoration: underline; color : ".$links." }
div { margin: 1px 0px 1px 0px; padding: 4px 4px 4px 4px }
div.form { background-color: ".$form_color."; text-align: left }
</style></head><body>";

$user = mysql_fetch_array($q);
$smiles = $user['smiles'];
$translit  = $user['translit'];
$msgs  = $user['msgs'];
$refresh = $user['refresh'];
$fsize = $user['fsize'];
$security  = $user['security'];
$default = $user['default'];
$emotions = $user['emotions'];
$system = $user['system'];
$gzip = $user['gzip'];

if(!isset($_POST['action']))
{
echo "<div class=\"form\">\n";
echo "<form action=\"settings.php?id=$id&amp;password=$password&amp;ver=html&amp;ref=$ref\" method=\"post\">\n";
echo "Смайлы:<br/>\n";
echo "<select name=\"smiles\">\n";

if($smiles == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "Транслит:<br/>\n";
echo "<select name=\"translit\">\n";

if($translit == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "Кол-во сообщений на странице:<br/>
<input type=\"text\" name=\"msgs\" value=\"$msgs\" maxlength=\"2\" size=\"2\"/><br/>
Время обновления:<br/>
<input type=\"text\" name=\"refresh\" value=\"$refresh\" maxlength=\"3\" size=\"3\"/><br/>
Шрифт:<br/>\n";
echo "<select name=\"fsize\">\n";

if($fsize == 0)
{
echo "<option value=\"0\" selected=\"selected\">Маленький</option>\n";
echo "<option value=\"1\">Средний</option>\n";
echo "<option value=\"2\">Большой</option>\n";
}
elseif($fsize == 1)
{
echo "<option value=\"0\">Маленький</option>\n";
echo "<option value=\"1\" selected=\"selected\">Средний</option>\n";
echo "<option value=\"2\">Большой</option>\n";
}
else
{
echo "<option value=\"0\">Маленький</option>\n";
echo "<option value=\"1\">Средний</option>\n";
echo "<option value=\"2\" selected=\"selected\">Большой</option>\n";
}

echo "</select><br/>\n";
echo "Система безопастности:<br/>\n";
echo "<select name=\"security\">\n";

if($security == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "Эмоции:<br/>\n";
echo "<select name=\"emotions\">\n";

if($emotions == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "По умолчанию сказать:<br/>\n";
echo "<select name=\"default\">\n";

if($default == 0)
{
echo "<option value=\"0\" selected=\"selected\">Всем</option>\n";
echo "<option value=\"1\">Приват</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Приват</option>\n";
echo "<option value=\"0\">Всем</option>\n";
}

echo "</select><br/>\n";
echo "Сообщения системного бота:<br/>\n";
echo "<select name=\"system\">\n";

if($system == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "GZip сжатие:<br/>\n";
echo "<select name=\"gzip\">\n";

if($gzip == 0)
{
echo "<option value=\"0\" selected=\"selected\">Выкл.</option>\n";
echo "<option value=\"1\">Вкл.</option>\n";
}
else
{
echo "<option value=\"1\" selected=\"selected\">Вкл.</option>\n";
echo "<option value=\"0\">Выкл.</option>\n";
}

echo "</select><br/>\n";
echo "<input type=\"hidden\" name=\"action\" value=\"save\" />\n";
echo "<input type=\"submit\" value=\"Сохранить\" /></form></div>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
}
else
{
$smiles = intval($_POST['smiles']);
$translit = intval($_POST['translit']);
$msgs = intval($_POST['msgs']);
$refresh = intval($_POST['refresh']);
$fsize = intval($_POST['fsize']);
$security = intval($_POST['security']);
$default = intval($_POST['default']);
$emotions = intval($_POST['emotions']);
$system = intval($_POST['system']);
$gzip = intval($_POST['gzip']);

$error = "";

if($smiles < 0 or $smile > 1) $error .= "Некорректное значение переключателя \"Смайлы\"!<br/>\n";
if($translit < 0 or $translit > 1) $error .= "Некорректное значение переключателя \"Транслит\"!<br/>\n";
if($msgs < 1 or $msgs > 99) $error .= "Количество сообщений на одной странице не может быть меньше 1 и больше 99!<br/>\n";
if($refresh < 1 or $refresh > 99) $error .= "Обновление страницы не может быть меньше 1 сек. и больше 300 сек.!<br/>\n";
if($fsize < 0 or $fsize > 2) $error .= "Некорректное значение переключателя \"Шрифт\"!<br/>\n";
if($security < 0 or $security > 1) $error .= "Некорректное значение переключателя \"Система безопастности\"!<br/>\n";
if($default < 0 or $default > 1) $error .= "Некорректное значение переключателя \"По умолчанию сказать\"!<br/>\n";
if($system < 0 or $system > 1) $error .= "Некорректное значение переключателя \"Сообщения системного бота\"!<br/>\n";
if($gzip < 0 or $gzip > 1) $error .= "Некорректное значение переключателя \"GZip сжатие\"!<br/>\n";

if(!empty($error))
{
echo $error;
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html&amp;ref=$ref\">Назад</a><br/>\n";
echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
exit();
}

$sql = mysql_query("UPDATE `chat_users` SET `smiles` = '".$smiles."', `translit` = '".$translit."', `msgs` = '".$msgs."', `refresh` = '".$refresh."', `fsize` = '".$fsize."', `security` = '".$security."', `default` = '".$default."', `emotions` = '".$emotions."', `system` = '".$system."', `gzip` = '".$gzip."'  WHERE `id` = '".$id."';");

if($sql)
{
echo "Профиль успешно сохранен!<br/>\n";
}
else
{
echo "При сохранении произошла ошибка!<br/>\n";
echo mysql_error()."<br/>\n";
}

echo "<a href=\"menu.php?id=$id&amp;password=$password&amp;ver=html\">Меню чата</a><br/>\n";
}

list($msec, $sec) = explode(chr(32), microtime());
echo "<br/>[".round(($sec+$msec)-$headtime,5)."] sec<br/>\n";
echo "</body></html>";
break;
}
?>