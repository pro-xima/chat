<?php
error_reporting(7);



header('Cache-Control: no-cache');
header('Content-Type: text/vnd.wap.wml');

echo '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.2//EN" "http://www.wapforum.org/DTD/wml12.dtd">
<wml>
<head><meta http-equiv="Cache-Control" content="no-cache" forua="true"/></head>
<card id="'.$cardid.'" title="ili.wab.ru">
<p align="left" mode="wrap">
<a href="gallery.php">Фотки</a>-&gt;';

$px = '<br/>:::::::<br/><a href="http://ili.wab.ru">ili.wab.ru</a></p></card></wml>';
?>
